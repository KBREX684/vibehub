import { createServer } from "http";
import { readFile, stat } from "fs/promises";
import { join, extname } from "path";

const PORT = parseInt(process.env.DEPLOY_RUN_PORT || "5000", 10);
const DIST = join(import.meta.dirname, "dist");

const MIME = {
  ".html": "text/html",
  ".js":   "application/javascript",
  ".css":  "text/css",
  ".json": "application/json",
  ".png":  "image/png",
  ".jpg":  "image/jpeg",
  ".svg":  "image/svg+xml",
  ".ico":  "image/x-icon",
  ".woff": "font/woff",
  ".woff2":"font/woff2",
  ".ttf":  "font/ttf",
};

createServer(async (req, res) => {
  try {
    let path = join(DIST, new URL(req.url, "http://x").pathname);

    // Serve index.html for SPA fallback
    const s = await stat(path).catch(() => null);
    if (!s || s.isDirectory()) path = join(DIST, "index.html");

    const data = await readFile(path);
    const ext = extname(path);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(data);
  } catch {
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not Found");
  }
}).listen(PORT, () => {
  console.log(`Static server running on port ${PORT}`);
});
