
  # VibeHub v10.0 UI Design

  This is a code bundle for VibeHub v10.0 UI Design. The original project is available at https://www.figma.com/design/fmXphahxBhh7bZ3AlH1Pke/VibeHub-v10.0-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  