# VibeHub — Signal Observatory UI

## Project Overview
VibeHub v10.0 is a developer collaboration platform UI prototype. All data is mock — no real backend. The design follows the "Signal Observatory" aesthetic: deep void backgrounds with a muted teal-green (#1EB893) accent system — calibrated for geeky, stable readability.

## Tech Stack
- **Framework**: Vite + React 18 + TypeScript
- **Styling**: Tailwind CSS v4 with custom `vh-*` design tokens in `src/styles/theme.css`
- **UI Components**: shadcn/ui (Radix UI primitives) in `src/components/ui/`
- **Animations**: Framer Motion + custom CSS keyframes
- **Routing**: React Router v7
- **Fonts**: Space Grotesk (display) / DM Sans (body) / JetBrains Mono (code) via `src/styles/fonts.css`

## Design Token System
All colors and typography use the `vh-*` namespace defined in `src/styles/theme.css`:
- **Surfaces**: `vh-void` → `vh-abyss` → `vh-deep` → `vh-surface` → `vh-elevated` (darkest to lightest)
- **Signal colors**: `vh-signal` (#1EB893 muted teal-green), `vh-blue`, `vh-violet`, `vh-cyan`, `vh-orange`, `vh-red` — each with `-dim` variant
- **Text**: `vh-text`, `vh-text-muted`, `vh-text-dim`, `vh-text-dark`
- **Borders**: `vh-border`, `vh-border-strong`, `vh-border-focus`

Legacy CSS variables (`--canvas`, `--surface`, etc.) are bridged in `:root` for backward compatibility with inline styles and SVG `var()` references.

## Key Files
| Path | Purpose |
|------|---------|
| `src/styles/theme.css` | Design tokens + global effects (glow, breathe, scanlines) |
| `src/styles/fonts.css` | Google Fonts imports |
| `src/app/components/Layout.tsx` | Root layout with noise texture overlay |
| `src/app/components/TopNav.tsx` | Navigation bar with signal glow branding |
| `src/app/components/ProjectCard.tsx` | Project card with hover glow effect |
| `src/app/components/work/ConsoleShell.tsx` | Workspace page shell with system status indicator |
| `src/app/components/work/TaskCard.tsx` | Agent task card component |
| `src/app/pages/Home.tsx` | Landing page with hero glow |
| `src/app/pages/Discover.tsx` | Project discovery with waveform search |
| `src/app/pages/work/Intents.tsx` | Collaboration intents inbox with signal color bars |

## Build & Run
```bash
pnpm install       # Install dependencies
pnpm run dev       # Dev server (port 5000)
pnpm run build     # Production build
pnpm run preview   # Preview production build
```

## Code Style
- All component classes use `vh-*` Tailwind tokens
- Font classes: `font-display` for headings, `font-mono` for code/labels, `font-sans` for body
- Hover glow: add `vh-card-glow` class to cards
- Breathing indicator: add `vh-breathe` class + `style={{ color: 'var(--color-vh-signal)' }}`
- Focus states: `focus:border-vh-signal/40 focus:shadow-[0_0_20px_rgba(0,229,160,0.08)]`

## Pages Not Yet Migrated to vh-* Tokens
The following pages still use legacy design tokens and should be migrated:
- `src/app/pages/Discussions.tsx`
- `src/app/pages/Projects.tsx`
- `src/app/pages/Tasks.tsx`
- `src/app/pages/UILibrary.tsx`
