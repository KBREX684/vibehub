import React, { useState } from "react";
import { ConsoleShell } from "../../components/work/ConsoleShell";
import { User, Shield, CreditCard, Cpu, Key, Code, Bell, Lock, Download, AlertTriangle, CheckCircle2 } from "lucide-react";
import { cn } from "../../utils";

export function Settings() {
  const [activeTab, setActiveTab] = useState("订阅与账单");
  const [showConfirm, setShowConfirm] = useState(false);

  const TABS = [
    { id: "个人资料", path: "profile", icon: User },
    { id: "账户安全", path: "account", icon: Shield },
    { id: "订阅与账单", path: "subscription", icon: CreditCard },
    { divider: true, id: "d1" },
    { id: "Agent 接入", path: "agents", icon: Cpu },
    { id: "API Key", path: "api-keys", icon: Key },
    { id: "API / MCP", path: "developers", icon: Code },
    { divider: true, id: "d2" },
    { id: "通知设置", path: "notifications", icon: Bell },
    { id: "隐私与权限", path: "privacy", icon: Lock },
    { id: "数据导出", path: "data-export", icon: Download },
  ];

  const renderContent = () => {
    if (activeTab === "订阅与账单") {
      return (
        <div className="flex flex-col gap-8 max-w-[800px]">
          <div>
            <h2 className="text-xl font-bold tracking-tight text-vh-text mb-1">订阅与账单</h2>
            <p className="text-sm text-vh-text-muted">管理您的付费计划、团队扩展包及账单历史。</p>
          </div>

          {/* Current Tier */}
          <div className="flex flex-col rounded-lg border border-vh-border bg-vh-surface shadow-sm overflow-hidden">
            <div className="p-6 border-b border-vh-border bg-vh-bg">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded border border-vh-border flex items-center justify-center bg-vh-elevated">
                    <span className="text-vh-text font-bold font-mono">PRO</span>
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-vh-text">Pro Plan</h3>
                    <p className="text-xs text-vh-text-muted font-mono">1 开发者席位 • 10 Agents 并发</p>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-xl font-bold text-vh-text">¥ 99</span>
                  <span className="text-[10px] text-vh-text-muted font-mono uppercase">/ month</span>
                </div>
              </div>
              
              <div className="w-full bg-vh-elevated h-2 rounded-full overflow-hidden mb-2">
                <div className="bg-blue-500 h-full w-[45%]" />
              </div>
              <p className="text-xs text-vh-text-muted font-mono">4.5 / 10 GB Storage Used</p>
            </div>
            <div className="px-6 py-4 bg-vh-surface flex items-center justify-between">
              <span className="text-sm text-vh-text-muted">下一个账单日: 2026-05-18</span>
              <button className="px-4 py-2 rounded bg-vh-text text-vh-bg text-sm font-medium hover:opacity-90 transition-opacity">
                升级套餐
              </button>
            </div>
          </div>

          {/* Team Workspace Add-ons */}
          <div className="flex flex-col rounded-lg border border-vh-border bg-vh-surface shadow-sm overflow-hidden">
            <div className="px-6 py-5 border-b border-vh-border">
              <h3 className="text-sm font-semibold text-vh-text mb-1">Team Workspace 扩展包</h3>
              <p className="text-xs text-vh-text-muted">为团队增加席位与并发 Agent 配额。</p>
            </div>
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-vh-bg/50 text-[11px] font-mono uppercase tracking-wider text-vh-text-dark border-b border-vh-border">
                <tr>
                  <th className="px-6 py-3 font-medium">名称</th>
                  <th className="px-6 py-3 font-medium">包含内容</th>
                  <th className="px-6 py-3 font-medium text-right">价格</th>
                  <th className="px-6 py-3 font-medium text-right">状态</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-vh-border">
                <tr className="hover:bg-vh-elevated transition-colors">
                  <td className="px-6 py-4 font-medium text-vh-text">Team Labs (基础包)</td>
                  <td className="px-6 py-4 text-vh-text-muted">5 席位 • 20 Agents</td>
                  <td className="px-6 py-4 text-right font-mono text-vh-text">¥ 299/mo</td>
                  <td className="px-6 py-4 text-right">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-mono bg-green-900/20 text-green-400 border border-green-900/50">
                      <CheckCircle2 className="w-3 h-3" /> ACTIVE
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-vh-elevated transition-colors">
                  <td className="px-6 py-4 font-medium text-vh-text">Storage +100GB</td>
                  <td className="px-6 py-4 text-vh-text-muted">额外的对象存储配额</td>
                  <td className="px-6 py-4 text-right font-mono text-vh-text">¥ 50/mo</td>
                  <td className="px-6 py-4 text-right">
                    <button className="px-3 py-1 rounded border border-vh-border bg-vh-bg text-xs text-vh-text hover:bg-vh-surface">
                      Add
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Payment Method */}
          <div className="flex flex-col rounded-lg border border-vh-border bg-vh-surface shadow-sm overflow-hidden">
            <div className="px-6 py-5 border-b border-vh-border">
              <h3 className="text-sm font-semibold text-vh-text mb-1">支付方式</h3>
              <p className="text-xs text-vh-text-muted">支持 Alipay, WeChat Pay 以及企业发票对公转账。</p>
            </div>
            <div className="p-6 bg-vh-bg flex flex-col gap-4">
              <div className="flex items-center justify-between p-4 rounded border border-vh-border-strong bg-vh-surface relative overflow-hidden">
                <div className="absolute top-0 right-0 p-1 bg-vh-border-strong rounded-bl-lg text-[10px] font-mono font-bold px-2 text-vh-text">默认</div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-8 rounded bg-vh-bg border border-vh-border flex items-center justify-center text-[#1677FF] font-bold text-xs italic">
                    Alipay
                  </div>
                  <div>
                    <span className="block text-sm text-vh-text font-medium">支付宝</span>
                    <span className="block text-xs text-vh-text-muted font-mono">138****8888</span>
                  </div>
                </div>
              </div>
              <button className="self-start text-sm text-vh-accent hover:underline">+ 添加支付方式</button>
            </div>
          </div>

          {/* Danger Zone */}
          <div className="flex flex-col rounded-lg border border-red-900/30 bg-vh-surface shadow-sm overflow-hidden mb-12">
            <div className="px-6 py-5 border-b border-red-900/30 bg-red-900/10">
              <h3 className="text-sm font-semibold text-red-400 mb-1 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" /> Danger Zone
              </h3>
            </div>
            <div className="p-6 bg-vh-bg flex items-center justify-between">
              <div>
                <span className="block text-sm text-vh-text font-medium mb-1">取消订阅</span>
                <span className="block text-xs text-vh-text-muted">取消后将保留 Pro 权限至本账单周期结束。</span>
              </div>
              <button 
                onClick={() => setShowConfirm(true)}
                className="px-4 py-2 rounded border border-red-900/50 bg-red-900/20 text-sm font-medium text-red-400 hover:bg-red-900/30 transition-colors"
              >
                取消 Pro 订阅
              </button>
            </div>
          </div>

        </div>
      );
    }
    
    return (
      <div className="flex flex-col gap-4 max-w-[600px] mt-8">
        <h2 className="text-xl font-bold tracking-tight text-vh-text">{activeTab}</h2>
        <p className="text-sm text-vh-text-muted">此页面在演示中暂未实现。</p>
      </div>
    );
  };

  return (
    <ConsoleShell mobileBannerText="Settings are best configured on a desktop screen.">
      <div className="flex h-full w-full overflow-hidden bg-vh-bg relative isolate">
        
        {/* Left Nav */}
        <aside className="hidden md:flex flex-col w-[240px] border-r border-vh-border bg-vh-surface shrink-0 py-6 overflow-y-auto scrollbar-hide">
          <nav className="flex flex-col gap-1 px-3">
            {TABS.map((tab, i) => {
              if (tab.divider) {
                return <div key={`div-${i}`} className="my-2 border-b border-vh-border mx-3" />;
              }
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as string)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent",
                    activeTab === tab.id
                      ? "bg-vh-elevated text-vh-text border border-vh-border-strong shadow-sm"
                      : "text-vh-text-muted hover:text-vh-text hover:bg-vh-surface border border-transparent"
                  )}
                >
                  {Icon && <Icon className="w-4 h-4 shrink-0" />}
                  {tab.id}
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Mobile Horizontal Nav */}
        <div className="md:hidden flex items-center gap-2 overflow-x-auto scrollbar-hide p-4 border-b border-vh-border bg-vh-surface shrink-0 z-20 sticky top-0 w-full">
          {TABS.filter(t => !t.divider).map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as string)}
                className={cn(
                  "flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors border focus-visible:outline-none",
                  activeTab === tab.id 
                    ? "bg-vh-elevated text-vh-text border-vh-border-strong shadow-sm" 
                    : "bg-vh-bg text-vh-text-muted border-vh-border"
                )}
              >
                {Icon && <Icon className="w-3.5 h-3.5 shrink-0" />}
                {tab.id}
              </button>
            );
          })}
        </div>

        {/* Form Area */}
        <main className="flex-1 overflow-y-auto p-6 md:p-12 bg-vh-bg">
          <div className="w-full h-full pb-12">
             {renderContent()}
          </div>
        </main>
        
        {/* Confirm Dialog */}
        {showConfirm && (
          <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-sm rounded-lg border border-red-900/50 bg-vh-surface shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
              <div className="p-6">
                <div className="w-10 h-10 rounded-full bg-red-900/20 border border-red-900/50 flex items-center justify-center text-red-400 mb-4">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-vh-text mb-2">取消 Pro 订阅？</h3>
                <p className="text-sm text-vh-text-muted">
                  如果取消，您的配额将在下一个账单日 (2026-05-18) 降级为免费版。超出配额的 Agent 将自动被暂停。
                </p>
              </div>
              <div className="px-6 py-4 border-t border-vh-border bg-vh-bg flex justify-end gap-3">
                <button 
                  onClick={() => setShowConfirm(false)}
                  className="px-4 py-2 rounded border border-vh-border bg-vh-surface text-sm text-vh-text hover:bg-vh-elevated transition-colors"
                >
                  保持订阅
                </button>
                <button 
                  onClick={() => setShowConfirm(false)}
                  className="px-4 py-2 rounded bg-red-600 text-white text-sm font-medium hover:bg-red-700 transition-colors"
                >
                  确认取消
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </ConsoleShell>
  );
}
