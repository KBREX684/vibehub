import React, { useState } from "react";
import { ConsoleShell } from "../../components/work/ConsoleShell";
import { Filter, Search, ChevronDown, Check, X, ShieldAlert, Inbox, Clock, MessageSquare } from "lucide-react";
import { cn } from "../../utils";

export function Intents() {
  const [activeTab, setActiveTab] = useState("收到的");
  const TABS = [
    { id: "收到的", label: "收到的", count: 12 },
    { id: "发出的", label: "发出的", count: 3 },
    { id: "已接受", label: "已接受", count: 45 },
    { id: "已拒绝", label: "已拒绝", count: 8 },
    { id: "已过期", label: "已过期", count: 2 },
  ];

  const [confirmBlock, setConfirmBlock] = useState<string | null>(null);
  const [blockInput, setBlockInput] = useState("");

  const mockIntents = [
    {
      id: "i-1",
      applicant: "Alex Chen",
      avatar: "AC",
      project: "Nexus Core Engine",
      status: "open",
      time: "2 hours ago",
      expiresIn: "12 days",
      expirationDate: "2026-05-17",
      paragraphs: {
        who: "I am a senior distributed systems engineer with 8 years of experience building high-throughput services. Previously worked on the caching layer for a major e-commerce platform handling 1M+ RPS.",
        why: "I noticed your architecture relies heavily on Redis but doesn't handle hot-key invalidation efficiently. I've open-sourced a similar pattern before and can help implement a two-tier caching strategy.",
        how: "I can contribute directly to the caching module. I'd like to start with an architectural review and then implement the local cache synchronization protocol over the next 3 weeks.",
      }
    },
    {
      id: "i-2",
      applicant: "Sarah Jenkins",
      avatar: "SJ",
      project: "Vibe UI",
      status: "open",
      time: "1 day ago",
      expiresIn: "4 days",
      expirationDate: "2026-04-22",
      paragraphs: {
        who: "Frontend developer specializing in WebGL and complex animations. I maintain several popular React animation libraries.",
        why: "Your UI framework looks solid but the motion system feels a bit rigid. I think a physics-based spring system would fit the 'vibe' much better.",
        how: "I want to rewrite the core animation hook to use a spring solver instead of CSS transitions. I can submit a PR for the Drawer and Modal components first as a proof of concept.",
      }
    }
  ];

  const handleBlockConfirm = () => {
    if (blockInput === "拉黑并举报") {
      setConfirmBlock(null);
      setBlockInput("");
      // execute block
    }
  };

  return (
    <ConsoleShell mobileBannerText="Intent Inbox is best viewed on desktop.">
      <div className="flex flex-col h-full overflow-hidden bg-vh-bg relative">
        {/* Top toolbar */}
        <div className="sticky top-0 z-20 flex flex-col bg-vh-surface border-b border-vh-border px-6 pt-6 shrink-0">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold tracking-tight text-vh-text flex items-center gap-2">
              <Inbox className="w-5 h-5 text-vh-text-muted" />
              协作意向 Inbox
            </h2>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-3 py-1.5 rounded border border-vh-border bg-vh-bg text-sm text-vh-text hover:bg-vh-elevated transition-colors">
                <span className="text-vh-text-muted">项目:</span> 全部 <ChevronDown className="w-3.5 h-3.5" />
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 rounded border border-vh-border bg-vh-bg text-sm text-vh-text hover:bg-vh-elevated transition-colors">
                <span className="text-vh-text-muted">时间:</span> 最近 30 天 <ChevronDown className="w-3.5 h-3.5" />
              </button>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-vh-text-muted" />
                <input 
                  type="text" 
                  placeholder="搜索关键词..." 
                  className="w-48 h-8 bg-vh-void border border-vh-border rounded pl-9 pr-3 text-sm text-vh-text placeholder-vh-text-dim focus:outline-none focus:border-vh-signal/40 focus:shadow-[0_0_12px_rgba(205,213,227,0.06)] transition-all"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6 overflow-x-auto scrollbar-hide">
            {TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "py-3 text-sm font-medium whitespace-nowrap transition-colors relative flex items-center gap-2 focus-visible:outline-none",
                  activeTab === tab.id ? "text-vh-text" : "text-vh-text-muted hover:text-vh-text"
                )}
              >
                {tab.label}
                <span className="px-1.5 py-0.5 rounded-full bg-vh-elevated border border-vh-border text-[10px] font-mono leading-none">
                  {tab.count}
                </span>
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-vh-signal rounded-t-full" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-auto bg-vh-bg p-6 scrollbar-hide flex flex-col items-center">
          <div className="w-full max-w-[840px] flex flex-col gap-6 pb-20">
            {activeTab !== "收到的" && (
              <div className="h-[300px] flex flex-col items-center justify-center text-center p-8 border border-dashed border-vh-border rounded-lg bg-vh-surface/30 w-full">
                <Inbox className="w-8 h-8 text-vh-text-dark mb-3" />
                <h3 className="text-vh-text font-medium mb-1">
                  {activeTab === "已过期" ? "30 天内未处理将自动过期。" : `暂无${activeTab}的协作意向。`}
                </h3>
                {activeTab === "已过期" && (
                  <button className="text-sm text-vh-accent hover:underline mt-2">设置通知偏好</button>
                )}
              </div>
            )}

            {activeTab === "收到的" && mockIntents.map(intent => (
              <div key={intent.id} className="flex flex-col rounded-lg border border-vh-border bg-vh-surface shadow-sm overflow-hidden group relative vh-card-glow">
                {/* Signal color bar - left edge */}
                <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-vh-signal rounded-l-lg" />
                <div className="px-6 py-4 border-b border-vh-border bg-vh-void flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded border border-vh-border-strong flex items-center justify-center bg-gradient-to-b from-gray-800 to-gray-900 text-vh-text font-medium text-xs">
                      {intent.avatar}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-vh-text">{intent.applicant}</span>
                      <span className="text-vh-text-muted font-mono text-sm">→ @{intent.project}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-vh-orange-dim text-vh-orange border border-vh-orange/20">
                      OPEN
                    </span>
                    <span className="text-[11px] font-mono text-vh-text-dark">{intent.time}</span>
                  </div>
                </div>

                <div className="p-6 flex flex-col gap-5 text-sm text-vh-text-muted leading-relaxed">
                  <div className="flex flex-col gap-1.5">
                    <span className="text-[11px] font-mono text-vh-text-dim uppercase tracking-wider">我是谁·我能做什么</span>
                    <p className="line-clamp-4">{intent.paragraphs.who}</p>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <span className="text-[11px] font-mono text-vh-text-dim uppercase tracking-wider">我为什么联系你</span>
                    <p className="line-clamp-4">{intent.paragraphs.why}</p>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <span className="text-[11px] font-mono text-vh-text-dim uppercase tracking-wider">我希望怎样合作</span>
                    <p className="line-clamp-4">{intent.paragraphs.how}</p>
                  </div>
                  <button className="text-vh-signal text-xs font-mono self-start hover:underline">
                    展开全部内容...
                  </button>
                </div>

                <div className="px-6 py-4 border-t border-vh-border bg-vh-bg flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[11px] font-mono text-vh-text-dark">
                    <Clock className="w-3.5 h-3.5" />
                    过期时间: {intent.expirationDate} (剩 {intent.expiresIn})
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="px-4 py-1.5 rounded border border-vh-border bg-vh-bg text-xs font-medium text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated transition-colors">
                      婉拒
                    </button>
                    <button className="px-4 py-1.5 rounded border border-vh-border bg-vh-bg text-xs font-medium text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated transition-colors">
                      忽略
                    </button>
                    <button 
                      onClick={() => setConfirmBlock(intent.id)}
                      className="px-4 py-1.5 rounded border border-red-900/30 bg-red-900/10 text-xs font-medium text-red-400 hover:bg-red-900/20 transition-colors flex items-center gap-1"
                    >
                      <ShieldAlert className="w-3.5 h-3.5" /> 拉黑并举报
                    </button>
                    <button className="ml-2 px-6 py-1.5 rounded bg-vh-signal text-vh-void text-xs font-medium hover:bg-vh-accent-hover transition-colors shadow-[0_0_12px_rgba(205,213,227,0.15)]">
                      接受
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Block Confirm Dialog */}
        {confirmBlock && (
          <div className="absolute inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center">
            <div className="w-[400px] rounded-lg border border-vh-border-strong bg-vh-surface shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
              <div className="p-6">
                <div className="w-10 h-10 rounded-full bg-red-900/20 border border-red-900/50 flex items-center justify-center text-red-400 mb-4">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-vh-text mb-2">拉黑并举报该用户？</h3>
                <p className="text-sm text-vh-text-muted mb-4">
                  此操作将拒绝该意向，并阻止此用户未来向你发送任何协作意向。举报信息将提交至管理团队审核。
                </p>
                <div className="flex flex-col gap-2">
                  <span className="text-xs font-mono text-vh-text-dark">Type "拉黑并举报" to confirm</span>
                  <input 
                    type="text" 
                    value={blockInput}
                    onChange={(e) => setBlockInput(e.target.value)}
                    className="w-full h-9 bg-vh-bg border border-vh-border rounded px-3 text-sm text-vh-text focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-all"
                  />
                </div>
              </div>
              <div className="px-6 py-4 border-t border-vh-border bg-vh-bg flex justify-end gap-3">
                <button 
                  onClick={() => setConfirmBlock(null)}
                  className="px-4 py-2 rounded border border-vh-border bg-vh-surface text-sm text-vh-text hover:bg-vh-elevated transition-colors"
                >
                  取消
                </button>
                <button 
                  onClick={handleBlockConfirm}
                  disabled={blockInput !== "拉黑并举报"}
                  className="px-4 py-2 rounded bg-red-600 text-white text-sm font-medium hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  确认拉黑
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ConsoleShell>
  );
}
