import React, { useState } from "react";
import { ConsoleShell } from "../../components/work/ConsoleShell";
import { Bell, Inbox, MessageSquare, Users, Cpu, Camera, PlayCircle, Settings, CheckCircle2, ChevronRight, XCircle } from "lucide-react";
import { cn } from "../../utils";

export function Notifications() {
  const [activeCategory, setActiveCategory] = useState("协作意向");

  const CATEGORIES = [
    { id: "协作意向", icon: Inbox, count: 3, desc: "当有人申请与你协作项目时，将在此收到通知。" },
    { id: "留言与纠错", icon: MessageSquare, count: 1, desc: "当有人在你负责的节点或代码留下评论时，会在这里显示。" },
    { id: "团队邀请", icon: Users, count: 0, desc: "收到加入新 Workspace 的邀请函。" },
    { id: "Agent 完成任务", icon: Cpu, count: 5, desc: "系统绑定的 AI 代理执行完指定工作并等待确认。" },
    { id: "快照确认", icon: Camera, count: 2, desc: "项目创建新版本快照或里程碑时的相关通报。" },
    { id: "Deliverable 状态", icon: PlayCircle, count: 0, desc: "CI/CD 流水线或交付打包环节的状态变更。" },
    { id: "订阅与系统", icon: Settings, count: 1, desc: "账单续费、系统级维护或账户安全警告。" },
  ];

  const mockNotifications = [
    { id: "n-1", category: "协作意向", subject: "Alex Chen 发送了关于 Nexus Core Engine 的协作意向", actor: "Alex Chen", time: "10m ago", target: "@nexus-core", unread: true },
    { id: "n-2", category: "协作意向", subject: "Sarah Jenkins 发送了关于 Vibe UI 的协作意向", actor: "Sarah Jenkins", time: "2h ago", target: "@vibe-ui", unread: true },
    { id: "n-3", category: "协作意向", subject: "Dave Smith 取消了针对 Neural Cache 的申请", actor: "Dave Smith", time: "1d ago", target: "@neural-cache", unread: false },
    
    { id: "n-4", category: "留言与纠错", subject: "在 src/utils/hash.ts 第 42 行提出了可能的性能瓶颈", actor: "SecurityAuditBot", time: "5m ago", target: "PR #102", unread: true },
    
    { id: "n-5", category: "Agent 完成任务", subject: "DocsBot-v2 成功生成了 OpenAPI swagger 文档", actor: "DocsBot-v2", time: "1h ago", target: "openapi.yaml", unread: true },
    { id: "n-6", category: "Agent 完成任务", subject: "OpsBot 部署失败：边缘节点连接超时", actor: "OpsBot", time: "3h ago", target: "Deploy-Job-49", unread: false },
    { id: "n-7", category: "Agent 完成任务", subject: "ReactExpert 完成了组件重构的代码审查", actor: "ReactExpert", time: "1d ago", target: "Commit 9f2a1b", unread: false },
    { id: "n-8", category: "Agent 完成任务", subject: "SecBot 提交了每日依赖漏洞扫描报告", actor: "SecBot", time: "1d ago", target: "Report-20260417", unread: false },
    { id: "n-9", category: "Agent 完成任务", subject: "System 清理了 3 个过期的测试环境", actor: "System", time: "2d ago", target: "Env-Cleanup", unread: false },

    { id: "n-10", category: "快照确认", subject: "Release-v2 交付快照已发布并锁定", actor: "System", time: "4h ago", target: "Snapshot-99", unread: true },
    { id: "n-11", category: "快照确认", subject: "Liang 批准了合并 milestone 1.0", actor: "Liang", time: "2d ago", target: "Snapshot-98", unread: false },

    { id: "n-12", category: "订阅与系统", subject: "已成功为 Team Labs 续费 Pro 计划", actor: "System", time: "1w ago", target: "Invoice-202604", unread: true },
  ];

  const activeCategoryData = CATEGORIES.find(c => c.id === activeCategory);
  const activeNotifications = mockNotifications.filter(n => n.category === activeCategory);

  return (
    <ConsoleShell mobileBannerText="Notifications is optimized for desktop view.">
      <div className="flex h-full w-full overflow-hidden bg-vh-bg relative isolate">
        
        {/* Left Rail (Secondary) */}
        <aside className="hidden md:flex flex-col w-[240px] border-r border-vh-border bg-vh-surface shrink-0 z-10 py-6">
          <div className="px-6 mb-6 flex items-center justify-between">
            <h2 className="text-xl font-bold tracking-tight text-vh-text flex items-center gap-2">
              <Bell className="w-5 h-5 text-vh-text-muted" />
              通知
            </h2>
          </div>
          
          <nav className="flex-1 overflow-y-auto px-3 flex flex-col gap-1 scrollbar-hide">
            <div className="text-[10px] font-mono text-vh-text-dark uppercase tracking-wider px-3 mb-2">Category</div>
            {CATEGORIES.map(category => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={cn(
                    "flex items-center justify-between px-3 py-2 rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent",
                    activeCategory === category.id 
                      ? "bg-vh-elevated text-vh-text border border-vh-border-strong shadow-sm" 
                      : "text-vh-text-muted hover:text-vh-text hover:bg-vh-surface border border-transparent"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={cn("w-4 h-4 shrink-0", activeCategory === category.id ? "text-vh-text" : "text-vh-text-muted")} />
                    <span className="truncate">{category.id}</span>
                  </div>
                  {category.count > 0 && (
                    <span className={cn(
                      "text-[10px] font-mono px-1.5 py-0.5 rounded leading-none border",
                      activeCategory === category.id 
                        ? "bg-blue-900/20 text-blue-400 border-blue-900/50" 
                        : "bg-vh-bg text-vh-text-dark border-vh-border"
                    )}>
                      {category.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
          
          <div className="p-4 border-t border-vh-border bg-vh-surface shrink-0">
            <button className="w-full py-2 rounded border border-vh-border bg-vh-bg text-sm text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated transition-colors flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4" /> 全部已读
            </button>
          </div>
        </aside>

        {/* Main List */}
        <main className="flex-1 flex flex-col min-w-0 bg-vh-bg relative scrollbar-hide">
          
          {/* Mobile Horizontal Nav */}
          <div className="md:hidden flex items-center gap-2 overflow-x-auto scrollbar-hide p-4 border-b border-vh-border bg-vh-surface shrink-0 z-20 sticky top-0 w-full">
            {CATEGORIES.map(category => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={cn(
                    "flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors border focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent",
                    activeCategory === category.id 
                      ? "bg-vh-elevated text-vh-text border-vh-border-strong shadow-sm" 
                      : "bg-vh-bg text-vh-text-muted border-vh-border hover:bg-vh-surface"
                  )}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  {category.id}
                  {category.count > 0 && (
                    <span className="ml-1 opacity-70">[{category.count}]</span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="flex-1 overflow-y-auto p-4 md:p-6 flex flex-col items-center w-full">
            <div className="w-full max-w-[800px] flex flex-col gap-4 pb-12">
              
              <div className="flex items-center justify-between mb-2">
                <div className="flex flex-col">
                  <h3 className="text-lg font-bold text-vh-text mb-1">{activeCategory}</h3>
                  <p className="text-xs font-mono text-vh-text-muted max-w-sm">{activeCategoryData?.desc}</p>
                </div>
                <button className="text-[11px] font-mono text-vh-accent hover:underline md:hidden">
                  Mark all read
                </button>
              </div>

            {activeNotifications.length === 0 ? (
              <div className="h-[300px] flex flex-col items-center justify-center text-center p-8 border border-dashed border-vh-border rounded-lg bg-vh-surface/30 mx-4 md:mx-0 mt-4">
                <Bell className="w-8 h-8 text-vh-text-dark mb-3" />
                <h3 className="text-vh-text font-medium mb-1">
                  暂无新通知
                </h3>
                <p className="text-sm text-vh-text-muted mb-6">
                  {activeCategoryData?.desc}
                </p>
              </div>
            ) : (
              <div className="flex flex-col divide-y divide-vh-border border-y md:border border-vh-border md:rounded-lg bg-vh-surface">
                {activeNotifications.map(notification => (
                  <div 
                    key={notification.id} 
                    className={cn(
                      "flex items-center p-4 gap-4 transition-colors relative group hover:bg-vh-elevated cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent",
                      notification.unread ? "bg-vh-surface" : "bg-vh-bg opacity-70"
                    )}
                    tabIndex={0}
                  >
                    {/* Left colored bar for unread */}
                    {notification.unread && (
                      <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-vh-signal rounded-r-full" />
                    )}

                    <div className="w-8 h-8 rounded-full border border-vh-border bg-vh-bg flex items-center justify-center shrink-0">
                      {activeCategoryData && React.createElement(activeCategoryData.icon, { className: "w-4 h-4 text-vh-text-muted" })}
                    </div>

                    <div className="flex flex-col gap-1.5 flex-1 min-w-0 pr-4">
                      <p className={cn(
                        "text-sm truncate",
                        notification.unread ? "text-vh-text font-bold" : "text-vh-text-muted font-medium"
                      )}>
                        {notification.subject}
                      </p>
                      <div className="flex items-center gap-3 text-[11px] font-mono">
                        <span className="text-vh-text-dark truncate max-w-[120px]">{notification.actor}</span>
                        <span className="text-vh-border-strong">•</span>
                        <span className="text-vh-text-muted">{notification.time}</span>
                        <span className="text-vh-border-strong">•</span>
                        <span className="px-1.5 py-0.5 rounded bg-vh-bg border border-vh-border text-vh-text-muted truncate max-w-[100px]">
                          {notification.target}
                        </span>
                      </div>
                    </div>

                    <button className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded border border-vh-border bg-vh-bg text-[11px] font-mono text-vh-text-muted hover:text-vh-text hover:bg-vh-surface transition-colors shrink-0">
                      前往 <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            
            </div>
          </div>
        </main>
        
      </div>
    </ConsoleShell>
  );
}
