import React, { useState } from "react";
import { ConsoleShell } from "../../components/work/ConsoleShell";
import { cn } from "../../utils";
import { Bot, PlayCircle, Clock, CheckCircle2, XCircle, Terminal, Shield, FileText, Paperclip, Cpu, AlertTriangle, Check, ListFilter, Users, User } from "lucide-react";

type AgentStatus = "running" | "pending-confirm" | "done" | "failed";

interface TaskData {
  id: string;
  verb: string;
  status: AgentStatus;
  agent: string;
  spaceName: string;
  creatorAvatar: string;
  time: string;
}

const mockTasks: TaskData[] = [
  {
    id: "t-1",
    verb: "优化 Navbar 组件的重渲染逻辑",
    status: "pending-confirm",
    agent: "ReactExpert",
    spaceName: "vibe-ui",
    creatorAvatar: "LC",
    time: "10m ago"
  },
  {
    id: "t-2",
    verb: "为 @nexus-core 生成 OpenAPI 文档",
    status: "running",
    agent: "DocsBot-v2",
    spaceName: "nexus-core",
    creatorAvatar: "AC",
    time: "2h ago"
  },
  {
    id: "t-3",
    verb: "合并 PR #104 自动解决冲突",
    status: "failed",
    agent: "GitMaster",
    spaceName: "vibe-ui",
    creatorAvatar: "LC",
    time: "1d ago"
  },
  {
    id: "t-4",
    verb: "清理过期测试环境资源 (AWS)",
    status: "done",
    agent: "OpsBot",
    spaceName: "team-infra",
    creatorAvatar: "SYS",
    time: "2d ago"
  },
  {
    id: "t-5",
    verb: "分析 src/utils 潜在安全漏洞",
    status: "done",
    agent: "SecBot",
    spaceName: "nexus-core",
    creatorAvatar: "AC",
    time: "3d ago"
  }
];

const TABS = ["全部", "进行中", "待确认", "已完成", "失败"];
const SCOPES = [
  { id: "all", label: "全部", icon: ListFilter },
  { id: "personal", label: "个人", icon: User },
  { id: "team", label: "团队", icon: Users },
];

function StatusPill({ status }: { status: AgentStatus }) {
  switch (status) {
    case "running": return <span className="flex items-center gap-1 text-[10px] text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded border border-blue-500/20"><PlayCircle className="w-3 h-3"/> 进行中</span>;
    case "pending-confirm": return <span className="flex items-center gap-1 text-[10px] text-orange-400 bg-orange-500/10 px-1.5 py-0.5 rounded border border-orange-500/20"><Clock className="w-3 h-3"/> 待确认</span>;
    case "done": return <span className="flex items-center gap-1 text-[10px] text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded border border-green-500/20"><CheckCircle2 className="w-3 h-3"/> 已完成</span>;
    case "failed": return <span className="flex items-center gap-1 text-[10px] text-red-400 bg-red-500/10 px-1.5 py-0.5 rounded border border-red-500/20"><XCircle className="w-3 h-3"/> 失败</span>;
  }
}

function AgentBadge({ agent }: { agent: string }) {
  return (
    <span className="flex items-center gap-1.5 text-[10px] font-mono text-vh-text-dark bg-vh-surface px-2 py-0.5 rounded-full border border-vh-border">
      <Cpu className="w-3 h-3 text-purple-400" />
      {agent}
    </span>
  );
}

export function AgentTasks() {
  const [activeTab, setActiveTab] = useState("全部");
  const [activeScope, setActiveScope] = useState("all");
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>("t-1");
  const [detailTab, setDetailTab] = useState("确认");

  const selectedTask = mockTasks.find(t => t.id === selectedTaskId);

  // Detail panel tabs
  const DETAIL_TABS = ["输入上下文", "执行过程", "输出结果", "审计记录", "确认"];

  return (
    <ConsoleShell mobileBannerText="Agent Task Center is optimized for desktop view.">
      <div className="flex flex-col h-full w-full overflow-hidden bg-vh-bg relative isolate">
        
        {/* Top Filter Bar */}
        <div className="h-14 border-b border-vh-border bg-vh-surface flex flex-wrap items-center px-4 md:px-6 justify-between shrink-0 gap-4 overflow-x-auto scrollbar-hide z-20 relative">
          
          {/* Status Tabs */}
          <div className="flex items-center gap-1 md:gap-2">
             {TABS.map(tab => (
               <button
                 key={tab}
                 onClick={() => setActiveTab(tab)}
                 className={cn(
                   "px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent",
                   activeTab === tab
                     ? "bg-vh-elevated text-vh-text border border-vh-border-strong shadow-sm"
                     : "bg-vh-bg text-vh-text-muted border border-vh-border hover:bg-vh-surface"
                 )}
               >
                 {tab}
               </button>
             ))}
          </div>

          <div className="flex items-center gap-4 ml-auto">
            {/* Scope toggle */}
            <div className="flex items-center bg-vh-bg rounded-md p-0.5 border border-vh-border shrink-0">
              {SCOPES.map(scope => {
                const Icon = scope.icon;
                return (
                  <button
                    key={scope.id}
                    onClick={() => setActiveScope(scope.id)}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1 rounded-sm text-[11px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent",
                      activeScope === scope.id
                        ? "bg-vh-elevated text-vh-text shadow-sm"
                        : "text-vh-text-muted hover:text-vh-text"
                    )}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span className="hidden lg:inline">{scope.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="h-4 w-px bg-vh-border hidden sm:block" />

            {/* Agent / Space filters */}
            <button className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded border border-vh-border bg-vh-bg text-xs font-mono text-vh-text-muted hover:text-vh-text transition-colors">
              Agent <span className="text-vh-text px-1 bg-vh-surface rounded">All</span>
            </button>
            <button className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded border border-vh-border bg-vh-bg text-xs font-mono text-vh-text-muted hover:text-vh-text transition-colors">
              Space <span className="text-vh-text px-1 bg-vh-surface rounded">All</span>
            </button>
          </div>
        </div>

        {/* Split View Content */}
        <div className="flex flex-1 min-h-0 relative">
          
          {/* Left Panel: Task List */}
          <div className="w-full md:w-[320px] lg:w-[380px] border-r border-vh-border bg-vh-bg flex flex-col shrink-0">
            <div className="flex-1 overflow-y-auto scrollbar-hide">
              {mockTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full p-8 text-center text-vh-text-muted bg-vh-bg">
                  <Bot className="w-12 h-12 mb-4 text-vh-text-dark opacity-50" />
                  <p className="text-sm font-medium text-vh-text mb-1">暂无 Agent 任务</p>
                  <p className="text-xs mb-6 max-w-[200px] leading-relaxed">您的工作区目前没有任何 AI 代理的执行任务。</p>
                  <button className="text-xs px-4 py-2 border border-vh-border rounded bg-vh-surface text-vh-text hover:bg-vh-elevated transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent shadow-sm">
                    发起 Agent 任务
                  </button>
                </div>
              ) : (
                mockTasks.map(task => (
                  <div 
                    key={task.id}
                    onClick={() => setSelectedTaskId(task.id)}
                  className={cn(
                    "flex flex-col gap-2.5 p-4 border-b border-vh-border cursor-pointer transition-colors relative group focus-visible:outline-none focus-visible:bg-vh-elevated",
                    selectedTaskId === task.id ? "bg-vh-elevated" : "hover:bg-vh-surface/50"
                  )}
                  tabIndex={0}
                  role="button"
                >
                  {selectedTaskId === task.id && (
                    <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-vh-signal" />
                  )}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded bg-vh-surface border border-vh-border flex items-center justify-center overflow-hidden shrink-0">
                        <span className="text-[9px] font-bold text-vh-text-dark">{task.creatorAvatar}</span>
                      </div>
                      <span className="text-xs font-mono text-vh-text-muted truncate max-w-[120px]">@{task.spaceName}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] font-mono text-vh-text-dark shrink-0">
                      {task.time}
                      {task.status === 'pending-confirm' && <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shadow-[0_0_4px_rgba(249,115,22,0.8)]" />}
                    </div>
                  </div>
                  <div className="text-sm font-medium text-vh-text truncate" title={task.verb}>
                    {task.verb}
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <AgentBadge agent={task.agent} />
                    <StatusPill status={task.status} />
                  </div>
                </div>
                ))
              )}
            </div>
          </div>

          {/* Right Panel: Detail View */}
          <div className="hidden md:flex flex-1 flex-col bg-vh-bg min-w-0 relative">
            {!selectedTask ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-vh-bg relative z-10">
                <Bot className="w-16 h-16 text-vh-text-dark mb-4 opacity-50" />
                <h3 className="text-lg font-bold text-vh-text mb-2">未选择任务</h3>
                <p className="text-sm text-vh-text-muted">选择一个任务查看详情和执行上下文</p>
                <button className="mt-6 px-4 py-2 rounded border border-vh-border bg-vh-surface text-vh-text text-sm font-medium hover:bg-vh-elevated transition-colors">
                  发起 Agent 任务
                </button>
              </div>
            ) : (
              <div className="flex flex-col h-full absolute inset-0 z-10 bg-vh-bg">
                {/* Detail Header */}
                <div className="p-6 border-b border-vh-border shrink-0 bg-vh-surface/30">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex flex-col gap-2 flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-1">
                        <AgentBadge agent={selectedTask.agent} />
                        <span className="text-vh-border-strong text-sm">/</span>
                        <span className="text-xs font-mono text-vh-text-muted">@{selectedTask.spaceName}</span>
                      </div>
                      <h2 className="text-xl font-bold text-vh-text leading-tight">{selectedTask.verb}</h2>
                    </div>
                    <div className="shrink-0 pt-1">
                      <StatusPill status={selectedTask.status} />
                    </div>
                  </div>
                </div>

                {/* Detail Tabs */}
                <div className="px-6 border-b border-vh-border flex gap-6 shrink-0 bg-vh-surface/50 overflow-x-auto scrollbar-hide">
                  {DETAIL_TABS.map(tab => {
                    const isDisabled = (tab === "确认" && selectedTask.status !== "pending-confirm");
                    return (
                      <button
                        key={tab}
                        onClick={() => !isDisabled && setDetailTab(tab)}
                        disabled={isDisabled}
                        className={cn(
                          "py-3 text-sm font-medium whitespace-nowrap transition-colors relative focus-visible:outline-none focus-visible:text-vh-text",
                          detailTab === tab ? "text-vh-text" : "text-vh-text-muted hover:text-vh-text",
                          isDisabled && "opacity-30 cursor-not-allowed hover:text-vh-text-muted"
                        )}
                      >
                        {tab}
                        {detailTab === tab && (
                          <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-vh-signal rounded-t-full" />
                        )}
                        {tab === "确认" && selectedTask.status === "pending-confirm" && (
                          <span className="absolute top-3 -right-2.5 w-1.5 h-1.5 rounded-full bg-orange-500" />
                        )}
                      </button>
                    )
                  })}
                </div>

                {/* Detail Content */}
                <div className="flex-1 overflow-y-auto scrollbar-hide p-6 bg-vh-bg">
                  
                  {detailTab === "输入上下文" && (
                    <div className="max-w-3xl">
                      <h3 className="text-xs font-mono text-vh-text-dark uppercase tracking-wider mb-4">Prompt Context</h3>
                      <div className="prose prose-invert max-w-none text-sm text-vh-text-muted p-4 rounded-lg bg-vh-surface border border-vh-border leading-relaxed">
                        <p>请审查代码库中的 <code>TopNav</code> 组件，该组件目前在发生上下文切换时会引发不必要的重渲染。我们需要优化其渲染逻辑，使用 <code>React.memo</code> 或将 Context 抽离，确保组件性能。不要修改现有的样式，仅关注 React 渲染性能。</p>
                      </div>
                      <div className="mt-8 flex flex-col gap-3">
                        <h3 className="text-xs font-mono text-vh-text-dark uppercase tracking-wider">Attachments (2)</h3>
                        <div className="flex flex-wrap gap-3">
                          <button className="flex items-center gap-2 px-3 py-2 rounded-md border border-vh-border bg-vh-surface text-xs font-mono text-vh-text hover:bg-vh-elevated transition-colors">
                            <Paperclip className="w-4 h-4 text-vh-text-muted" /> src/app/components/TopNav.tsx
                          </button>
                          <button className="flex items-center gap-2 px-3 py-2 rounded-md border border-vh-border bg-vh-surface text-xs font-mono text-vh-text hover:bg-vh-elevated transition-colors">
                            <Paperclip className="w-4 h-4 text-vh-text-muted" /> src/app/hooks/useUserContext.ts
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {detailTab === "执行过程" && (
                    <div className="max-w-2xl">
                      <div className="flex items-center gap-4 mb-8">
                         <div className="w-10 h-10 rounded-lg border border-vh-border bg-vh-surface flex items-center justify-center shrink-0 shadow-sm">
                           <Cpu className="w-5 h-5 text-purple-400" />
                         </div>
                         <div className="flex flex-col gap-1">
                           <div className="text-sm font-bold text-vh-text">{selectedTask.agent}</div>
                           <div className="text-[11px] font-mono text-vh-text-muted">Session started 2026-04-18 14:32:00</div>
                         </div>
                      </div>
                      
                      <div className="flex flex-col gap-0 relative ml-2">
                        <div className="absolute left-[15px] top-4 bottom-4 w-px bg-vh-border" />
                        
                        {/* Timeline item 1 */}
                        <div className="flex gap-5 relative z-10 pb-8">
                           <div className="w-8 h-8 rounded-full bg-vh-bg border-2 border-vh-border flex items-center justify-center mt-0 shrink-0 shadow-sm">
                             <Terminal className="w-3.5 h-3.5 text-vh-text-muted" />
                           </div>
                           <div className="flex flex-col gap-2.5 flex-1 pt-1">
                             <div className="text-sm font-bold text-vh-text">Tool Invoked: ReadFile</div>
                             <div className="text-xs font-mono text-vh-text-muted">Reading `src/app/components/TopNav.tsx`</div>
                             <div className="p-3 rounded-md bg-vh-surface border border-vh-border font-mono text-[11px] text-vh-text-muted mt-1 whitespace-pre-wrap max-h-32 overflow-y-auto scrollbar-hide">
                               {`import React, { useContext } from 'react';\nimport { UserContext } from '../context';\n\nexport function TopNav() {\n  const user = useContext(UserContext);\n...`}
                             </div>
                           </div>
                        </div>

                        {/* Timeline item 2 */}
                        <div className="flex gap-5 relative z-10 pb-8">
                           <div className="w-8 h-8 rounded-full bg-vh-bg border-2 border-vh-border flex items-center justify-center mt-0 shrink-0 shadow-sm">
                             <Shield className="w-3.5 h-3.5 text-vh-text-muted" />
                           </div>
                           <div className="flex flex-col gap-2.5 flex-1 pt-1">
                             <div className="text-sm font-bold text-vh-text">Thought Process</div>
                             <div className="text-xs text-vh-text-muted leading-relaxed bg-vh-surface/50 p-4 rounded-md border border-vh-border">
                               组件 `TopNav` 直接消耗了 `UserContext`，当 `UserContext` 更新时，即使对于 TopNav 不相关的状态更新也会导致重渲染。通过包裹 `React.memo` 可以防止父级重渲染传递，但我还需要确认是否有自定义 Hook 被使用。接下来修改文件。
                             </div>
                           </div>
                        </div>

                        {/* Timeline item 3 */}
                        <div className="flex gap-5 relative z-10">
                           <div className="w-8 h-8 rounded-full bg-vh-bg border-2 border-blue-500/50 flex items-center justify-center mt-0 shrink-0 shadow-[0_0_10px_rgba(59,130,246,0.3)]">
                             <FileText className="w-3.5 h-3.5 text-blue-400" />
                           </div>
                           <div className="flex flex-col gap-2.5 flex-1 pt-1">
                             <div className="text-sm font-bold text-vh-text">Tool Invoked: EditFile</div>
                             <div className="text-xs font-mono text-vh-text-muted">Modified `src/app/components/TopNav.tsx`</div>
                           </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {detailTab === "确认" && selectedTask.status === "pending-confirm" && (
                    <div className="max-w-3xl flex flex-col h-full">
                      <div className="flex-1">
                        <div className="p-4 border border-orange-500/30 bg-orange-500/5 rounded-lg mb-6 flex items-start gap-4">
                          <AlertTriangle className="w-6 h-6 text-orange-400 shrink-0 mt-0.5" />
                          <div className="flex flex-col gap-1.5">
                            <h4 className="text-sm font-bold text-orange-400">需要权限确认 (Approval Required)</h4>
                            <p className="text-xs text-vh-text-muted leading-relaxed">
                              Agent 正在尝试提交代码修改到受保护的分支 (<code>main</code>)。请审查差异并执行最终确认。如果拒绝，Agent 将回滚文件修改。
                            </p>
                          </div>
                        </div>
                        
                        <div className="rounded-lg border border-vh-border overflow-hidden bg-vh-bg flex flex-col">
                          <div className="bg-vh-surface p-3 border-b border-vh-border text-xs font-mono text-vh-text flex items-center gap-3">
                            <FileText className="w-4 h-4 text-vh-text-muted" /> 
                            src/app/components/TopNav.tsx
                            <span className="ml-auto text-[10px] text-vh-text-muted bg-vh-bg px-2 py-0.5 rounded border border-vh-border">1 file changed</span>
                          </div>
                          <div className="p-4 font-mono text-[11px] overflow-x-auto whitespace-pre leading-relaxed select-text flex flex-col gap-1 bg-[#0d0d0f]">
                            <div className="flex group hover:bg-vh-surface/30 px-2 rounded"><span className="w-8 shrink-0 text-vh-text-dark select-none text-right pr-4">42</span><span className="text-vh-text-muted">  const {'{'} user {'}'} = useUserContext();</span></div>
                            <div className="flex group hover:bg-vh-surface/30 px-2 rounded"><span className="w-8 shrink-0 text-vh-text-dark select-none text-right pr-4">43</span><span className="text-vh-text-muted">  </span></div>
                            <div className="flex bg-red-950/30 px-2 rounded border-l-2 border-red-500/50"><span className="w-8 shrink-0 text-red-500/50 select-none text-right pr-4">44</span><span className="text-red-300">- export function TopNav() {'{'}</span></div>
                            <div className="flex bg-green-950/30 px-2 rounded border-l-2 border-green-500/50"><span className="w-8 shrink-0 text-green-500/50 select-none text-right pr-4">44</span><span className="text-green-300">+ export const TopNav = React.memo(function TopNav() {'{'}</span></div>
                            <div className="flex group hover:bg-vh-surface/30 px-2 rounded"><span className="w-8 shrink-0 text-vh-text-dark select-none text-right pr-4">45</span><span className="text-vh-text-muted">    return (</span></div>
                            <div className="flex group hover:bg-vh-surface/30 px-2 rounded"><span className="w-8 shrink-0 text-vh-text-dark select-none text-right pr-4">46</span><span className="text-vh-text-muted">      &lt;div className="flex items-center..."&gt;</span></div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Fixed Action Bar at Bottom of Detail View */}
                      <div className="mt-8 pt-4 border-t border-vh-border flex items-center justify-end gap-3 sticky bottom-0 bg-vh-bg pb-2">
                        <button className="px-4 py-2.5 rounded-md border border-vh-border bg-vh-surface text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated transition-colors text-sm font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent shadow-sm">
                          拒绝修改并回滚
                        </button>
                        <button className="px-6 py-2.5 rounded-md bg-vh-text text-vh-bg hover:bg-white transition-colors text-sm font-bold flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-vh-accent shadow-[0_0_15px_rgba(250,250,250,0.15)]">
                          <Check className="w-4 h-4" /> 批准提交
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Placeholder for other tabs */}
                  {(detailTab === "输出结果" || detailTab === "审计记录") && (
                    <div className="flex flex-col items-center justify-center h-[300px] text-center border border-dashed border-vh-border rounded-lg bg-vh-surface/20">
                       <FileText className="w-8 h-8 text-vh-text-dark mb-3 opacity-50" />
                       <h3 className="text-vh-text font-medium text-sm mb-1">{detailTab} 正在生成中</h3>
                       <p className="text-xs text-vh-text-muted">数据已记录，完整视图将在任务完成后可用。</p>
                    </div>
                  )}

                </div>
              </div>
            )}
          </div>
        </div>

      </div>
    </ConsoleShell>
  );
}
