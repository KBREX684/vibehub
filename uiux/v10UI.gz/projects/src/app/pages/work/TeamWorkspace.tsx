import React, { useState, useEffect } from "react";
import { ConsoleShell } from "../../components/work/ConsoleShell";
import { EventDrawer } from "../../components/work/EventDrawer";
import { 
  Users, ChevronDown, UserPlus, Upload, Camera, CheckCircle, Shield, FileText, 
  Bot, Clock, MoreHorizontal, MessageSquare, Briefcase, Zap, Command, Lock, Cpu 
} from "lucide-react";
import { cn } from "../../utils";

export function TeamWorkspace() {
  const [activeTab, setActiveTab] = useState("活动流");
  const [composerOpen, setComposerOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);

  const TABS = ["活动流", "文件", "快照", "任务", "成员", "Agent", "设置"];

  // Handle Command+K for the composer bar
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        // Just a mock action
        setComposerOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const COMPLIANCE_ITEMS = [
    { label: "数据区域", value: "cn" },
    { label: "跨境", value: "✗" },
    { label: "模型备案", value: "已登记" },
    { label: "审计留存", value: "12 个月" },
  ];

  const EVENT_KINDS = [
    "讨论", "决策", "@Agent 指派", "Agent 执行", "Agent 输出", 
    "人工确认", "驳回", "快照创建", "快照发布为公开", "交付确认", "成员变更"
  ];

  const MOCK_EVENTS = [
    { id: "e-1", dateStr: "今天", time: "14:30:12", kind: "交付确认", verb: "发起了交付确认请求", actor: "Liang", avatar: "L", target: "Release-v2", status: "PENDING" },
    { id: "e-2", dateStr: "今天", time: "14:15:00", kind: "Agent 输出", verb: "生成了安全审计报告", actor: "SecBot", avatar: <Bot className="w-4 h-4"/>, target: "AuditReport.pdf", status: "SUCCESS" },
    { id: "e-3", dateStr: "今天", time: "14:12:45", kind: "@Agent 指派", verb: "指派了依赖扫描任务", actor: "System", avatar: "S", target: "SecBot", status: "ACKNOWLEDGED" },
    { id: "e-4", dateStr: "昨天", time: "18:45:22", kind: "决策", verb: "通过了架构变更决议", actor: "TechLead", avatar: "T", target: "ADR-042", status: "APPROVED" },
    { id: "e-5", dateStr: "昨天", time: "10:20:00", kind: "讨论", verb: "发起了关于缓存策略的讨论", actor: "Dev_X", avatar: "X", target: "Thread-11", status: "OPEN" },
    { id: "e-6", dateStr: "2026-04-17", time: "09:00:10", kind: "快照创建", verb: "创建了里程碑快照", actor: "System", avatar: "S", target: "Snapshot-99", status: "LOCKED" },
  ];

  const groupedEvents = MOCK_EVENTS.reduce((acc, event) => {
    if (!acc[event.dateStr]) acc[event.dateStr] = [];
    acc[event.dateStr].push(event);
    return acc;
  }, {} as Record<string, typeof MOCK_EVENTS>);

  const rightRailContent = (
    <div className="flex flex-col gap-4">
      {["CodeReviewer", "SecBot", "DeployOps", "DocsBot"].map(agent => (
        <div key={agent} className="p-3 rounded border border-vh-border bg-vh-bg flex items-center justify-between">
           <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded bg-vh-surface flex items-center justify-center text-vh-text border border-vh-border-strong">
               <Cpu className="w-4 h-4 text-purple-400" />
             </div>
             <div className="flex flex-col">
               <span className="text-xs font-mono font-bold text-vh-text">{agent}</span>
               <span className="text-[10px] font-mono text-vh-text-muted flex items-center gap-1">
                 <span className="w-1.5 h-1.5 rounded-full bg-green-500" /> Online
               </span>
             </div>
           </div>
           <button className="text-vh-text-muted hover:text-vh-text p-1 rounded hover:bg-vh-elevated">
             <ChevronDown className="w-4 h-4" />
           </button>
        </div>
      ))}
      <div className="mt-4 p-4 border border-dashed border-vh-border rounded-lg bg-vh-surface/50 flex flex-col items-center justify-center text-center">
        <Cpu className="w-6 h-6 text-vh-text-dark mb-2" />
        <span className="text-xs text-vh-text-muted font-mono">Agent limits: 4/10 used</span>
        <button className="mt-3 px-4 py-1.5 text-xs rounded border border-vh-border text-vh-text hover:bg-vh-elevated transition-colors w-full">
          Upgrade Quota
        </button>
      </div>
    </div>
  );

  return (
    <ConsoleShell isTeam mobileBannerText="Workspace 协作建议在桌面端完成。" rightRail={rightRailContent}>
      
      {/* WorkspaceTopBar */}
      <div className="h-16 flex items-center justify-between px-6 border-b border-vh-border bg-vh-surface shrink-0 z-20">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 text-vh-text">
            <div className="w-8 h-8 rounded-md bg-vh-elevated border border-vh-border flex items-center justify-center font-bold text-sm shadow-sm">
              NX
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium tracking-tight">Nexus Labs</span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-vh-accent uppercase tracking-wider">Startup</span>
              </div>
            </div>
          </div>
          
          <div className="h-6 w-[1px] bg-vh-border mx-2" />
          
          <button className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-vh-bg border border-vh-border hover:border-vh-border-strong hover:bg-vh-elevated transition-colors group focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent shadow-sm">
            <span className="w-2 h-2 rounded-full bg-vh-signal group-hover:shadow-[0_0_8px_rgba(205,213,227,0.5)] transition-shadow" />
            <span className="text-xs font-mono font-medium text-vh-text">nexus-core-engine</span>
            <ChevronDown className="w-3.5 h-3.5 text-vh-text-muted" />
          </button>

          <div className="hidden 2xl:flex items-center gap-3 ml-4">
            <span className="text-[10px] font-mono text-vh-text-muted bg-vh-bg px-2 py-0.5 rounded border border-vh-border shadow-sm">6 成员</span>
            <span className="text-[10px] font-mono text-vh-text-muted bg-vh-bg px-2 py-0.5 rounded border border-vh-border shadow-sm">4 Agents</span>
            <span className="text-[10px] font-mono text-vh-text-muted bg-vh-bg px-2 py-0.5 rounded border border-vh-border shadow-sm">12.7/20 GB</span>
            <span className="text-[10px] font-mono text-vh-text-muted bg-vh-bg px-2 py-0.5 rounded border border-vh-border shadow-sm">48 快照</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded border border-vh-border bg-vh-bg text-xs font-medium text-vh-text hover:bg-vh-elevated transition-colors">
            <UserPlus className="w-3.5 h-3.5" /> 邀请成员
          </button>
          <div className="w-[1px] h-4 bg-vh-border hidden sm:block mx-1" />
          <button className="flex items-center justify-center p-2 rounded-md border border-vh-border bg-vh-bg text-vh-text hover:bg-vh-elevated transition-colors tooltip-trigger relative group">
            <Upload className="w-4 h-4" />
          </button>
          <button className="flex items-center justify-center p-2 rounded-md border border-vh-border bg-vh-bg text-vh-text hover:bg-vh-elevated transition-colors tooltip-trigger relative group">
            <Camera className="w-4 h-4" />
          </button>
          <button className="flex items-center gap-2 px-4 py-1.5 rounded bg-blue-600 border border-blue-500 text-xs font-medium text-white hover:bg-blue-700 transition-colors shadow-[0_0_15px_rgba(37,99,235,0.2)] ml-2">
            <CheckCircle className="w-3.5 h-3.5" /> 发起交付确认
          </button>
        </div>
      </div>

      {/* ComplianceStrip (MANDATORY) */}
      <div className="h-8 flex items-center px-6 border-b border-vh-border bg-vh-bg shrink-0 overflow-x-auto scrollbar-hide">
        <Shield className="w-3 h-3 text-green-500 mr-3 shrink-0" />
        <div className="flex items-center h-full">
          {COMPLIANCE_ITEMS.map((item, idx) => (
            <React.Fragment key={item.label}>
              <div className="flex items-center gap-2 font-mono text-[11px] whitespace-nowrap">
                <span className="text-vh-text-dark">{item.label}</span>
                <span className="text-vh-text-muted">{item.value}</span>
              </div>
              {idx < COMPLIANCE_ITEMS.length - 1 && (
                <div className="w-[1px] h-3 bg-vh-border mx-3 shrink-0" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* ViewTabs */}
      <div className="px-6 border-b border-vh-border bg-vh-surface shrink-0 overflow-x-auto scrollbar-hide">
        <div className="flex items-center gap-6">
          {TABS.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "py-3 text-sm font-medium whitespace-nowrap transition-colors relative focus-visible:outline-none focus-visible:text-vh-text",
                activeTab === tab ? "text-vh-text" : "text-vh-text-muted hover:text-vh-text"
              )}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-vh-signal rounded-t-full" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex flex-col bg-vh-bg relative isolate">
        {activeTab === "活动流" && (
          <>
            <div className="flex-1 overflow-y-auto pb-[72px] scrollbar-hide">
              <div className="max-w-[800px] mx-auto w-full py-8 px-4 sm:px-8">
                {Object.entries(groupedEvents).map(([date, events]) => (
                  <div key={date} className="mb-10 last:mb-0 relative">
                    <div className="sticky top-0 z-10 flex items-center py-2 bg-vh-bg/90 backdrop-blur-sm -mx-4 px-4 sm:-mx-8 sm:px-8 mb-4">
                       <span className="text-xs font-mono text-vh-text-dark uppercase tracking-wider">{date}</span>
                       <div className="flex-1 h-[1px] bg-vh-border ml-4" />
                    </div>
                    <div className="flex flex-col gap-3">
                      {events.map(event => (
                        <div 
                          key={event.id}
                          className="group flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-lg border border-vh-border bg-vh-surface hover:bg-vh-elevated hover:border-vh-border-strong transition-all cursor-pointer shadow-sm relative focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent"
                          tabIndex={0}
                        >
                          <div className="flex items-center gap-4 flex-1 min-w-0 pr-4">
                            <div className="w-7 h-7 shrink-0 rounded flex items-center justify-center text-[11px] font-medium bg-vh-bg border border-vh-border text-vh-text overflow-hidden">
                              {event.avatar}
                            </div>
                            <div className="flex flex-wrap items-center gap-2 flex-1 min-w-0 text-sm">
                              <span className="text-vh-text font-medium truncate max-w-[100px]">{event.actor}</span>
                              <span className="text-vh-text-muted">{event.verb}</span>
                              <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono rounded bg-vh-bg border border-vh-border text-vh-text-muted truncate max-w-[150px]">
                                {event.target}
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between sm:justify-end gap-4 mt-3 sm:mt-0 shrink-0">
                            <span className={cn(
                              "px-2 py-0.5 text-[10px] font-mono rounded-full border",
                              event.status === "SUCCESS" && "bg-green-900/20 text-green-400 border-green-900/50",
                              event.status === "PENDING" && "bg-orange-900/20 text-orange-400 border-orange-900/50",
                              event.status === "APPROVED" && "bg-blue-900/20 text-blue-400 border-blue-900/50",
                              event.status === "LOCKED" && "bg-vh-surface text-vh-text-muted border-vh-border",
                              event.status === "OPEN" && "bg-vh-bg text-vh-text-muted border-vh-border",
                              event.status === "ACKNOWLEDGED" && "bg-purple-900/20 text-purple-400 border-purple-900/50"
                            )}>
                              {event.status}
                            </span>
                            <div className="flex items-center gap-3">
                              <span className="text-[11px] font-mono text-vh-text-dark">{event.time}</span>
                              <button 
                                onClick={(e) => { e.stopPropagation(); setSelectedEvent(event); }}
                                className="opacity-0 group-hover:opacity-100 transition-opacity text-[11px] font-mono text-vh-accent hover:underline flex items-center gap-1 focus-visible:opacity-100 focus-visible:outline-none"
                              >
                                打开 <ChevronDown className="w-3 h-3 -rotate-90" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Composer bar (bottom, sticky, 56 tall) */}
            <div className="absolute bottom-0 left-0 right-0 h-16 border-t border-vh-border bg-vh-surface/80 backdrop-blur-md px-6 flex items-center justify-center xl:justify-between z-20">
              <div className="hidden xl:flex items-center gap-2">
                <Shield className="w-4 h-4 text-vh-text-dark" />
                <span className="text-xs font-mono text-vh-text-dark">Audit Env Enabled</span>
              </div>
              
              <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide flex-nowrap w-full xl:w-auto justify-start xl:justify-center">
                <button className="shrink-0 flex items-center gap-2 px-4 py-2 rounded-md bg-vh-bg border border-vh-border text-sm font-medium text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated hover:border-vh-border-strong transition-all focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent shadow-sm">
                  <MessageSquare className="w-4 h-4" /> 写讨论
                </button>
                <button className="shrink-0 flex items-center gap-2 px-4 py-2 rounded-md bg-vh-bg border border-vh-border text-sm font-medium text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated hover:border-vh-border-strong transition-all focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent shadow-sm">
                  <Briefcase className="w-4 h-4" /> 创建决策
                </button>
                <button className="shrink-0 flex items-center gap-2 px-4 py-2 rounded-md bg-vh-bg border border-vh-border text-sm font-medium text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated hover:border-vh-border-strong transition-all focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent shadow-sm">
                  <Zap className="w-4 h-4" /> @Agent 指派
                </button>
                <button className="shrink-0 flex items-center justify-center p-2 rounded-md bg-vh-bg border border-vh-border text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated hover:border-vh-border-strong transition-all tooltip-trigger relative group">
                   <Camera className="w-4 h-4" />
                </button>
                <button className="shrink-0 flex items-center justify-center p-2 rounded-md bg-vh-bg border border-vh-border text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated hover:border-vh-border-strong transition-all tooltip-trigger relative group">
                   <Upload className="w-4 h-4" />
                </button>
              </div>

              <div className="hidden xl:flex items-center justify-end w-[180px]">
                <div className="flex items-center gap-1.5 px-2 py-1 rounded border border-vh-border bg-vh-bg text-[10px] font-mono text-vh-text-dark">
                  <Command className="w-3 h-3" />
                  <span>K to open Command Palette</span>
                </div>
              </div>
            </div>

            {/* Composer Command Palette Mock Overlay */}
            {composerOpen && (
              <div className="absolute inset-0 z-50 bg-vh-bg/80 backdrop-blur-sm flex items-start justify-center pt-[10vh]">
                <div className="w-[600px] rounded-xl border border-vh-border bg-vh-surface shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                  <div className="flex items-center gap-3 p-4 border-b border-vh-border">
                    <Command className="w-5 h-5 text-vh-text-muted" />
                    <input 
                      autoFocus
                      type="text" 
                      placeholder="Type a command or search..."
                      className="flex-1 bg-transparent border-none text-vh-text focus:outline-none text-base placeholder:text-vh-text-dark"
                    />
                    <button onClick={() => setComposerOpen(false)} className="text-vh-text-dark hover:text-vh-text px-2 py-1 rounded bg-vh-bg border border-vh-border text-xs font-mono">ESC</button>
                  </div>
                  <div className="p-2 max-h-[300px] overflow-y-auto flex flex-col gap-1">
                    {EVENT_KINDS.map((kind, i) => (
                      <button key={i} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md hover:bg-vh-elevated text-sm text-vh-text-muted hover:text-vh-text text-left transition-colors">
                        <FileText className="w-4 h-4" />
                        <span>创建 {kind}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
        
        {activeTab !== "活动流" && (
          <div className="flex flex-col items-center justify-center h-full text-center max-w-sm mx-auto pb-16">
            <div className="w-16 h-16 rounded-full bg-vh-surface border border-vh-border flex items-center justify-center mb-4">
              <Lock className="w-6 h-6 text-vh-text-dark" />
            </div>
            <h3 className="text-lg font-semibold text-vh-text mb-2 tracking-tight">内容为空</h3>
            <p className="text-sm text-vh-text-muted leading-relaxed">
              这是 {activeTab} 视图的预留区域，数据尚未初始化或已被归档清理。
            </p>
          </div>
        )}
      </div>
      
      <EventDrawer 
        isOpen={!!selectedEvent} 
        onClose={() => setSelectedEvent(null)} 
        event={selectedEvent} 
      />
    </ConsoleShell>
  );
}
