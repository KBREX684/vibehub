import React, { useState } from "react";
import { ConsoleShell } from "../../components/work/ConsoleShell";
import { Search, Plus, Upload, Filter, MoreHorizontal, Eye, Lock, Globe, FileText, CheckCircle2, ChevronDown, CheckSquare, Square } from "lucide-react";
import { cn } from "../../utils";

export function ProjectLibrary() {
  const [activeTab, setActiveTab] = useState("已公开");
  const TABS = ["草稿", "已公开", "私有", "开源", "已归档"];
  
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };
  const toggleSelectAll = () => {
    if (selectedIds.length === mockData.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(mockData.map(x => x.id));
    }
  };

  const mockData = [
    { id: "1", name: "Nexus Core Engine", slug: "nexus-core", status: "已公开", visibility: "globe", license: "MIT", workspace: "Nexus Labs", updated: "10m ago", intentCount: 12 },
    { id: "2", name: "Vibe UI", slug: "vibe-ui", status: "草稿", visibility: "lock", license: "Proprietary", workspace: "Personal", updated: "2h ago", intentCount: 0 },
    { id: "3", name: "Neural Cache", slug: "neural-cache", status: "已公开", visibility: "eye", license: "Apache-2.0", workspace: "Nexus Labs", updated: "1d ago", intentCount: 3 },
    { id: "4", name: "React Agent Framework", slug: "react-agent", status: "开源", visibility: "globe", license: "Apache-2.0", workspace: "Nexus Labs", updated: "3d ago", intentCount: 45 },
  ];

  const data = activeTab === "草稿" 
    ? mockData.filter(d => d.status === "草稿") 
    : activeTab === "已公开" 
      ? mockData.filter(d => d.status === "已公开")
      : activeTab === "开源"
        ? mockData.filter(d => d.status === "开源")
        : [];

  return (
    <ConsoleShell mobileBannerText="Project Library is optimized for desktop.">
      <div className="flex flex-col h-full overflow-hidden bg-vh-bg">
        {/* Top toolbar (sticky) */}
        <div className="sticky top-0 z-20 flex flex-col bg-vh-surface border-b border-vh-border px-6 pt-6 shrink-0">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold tracking-tight text-vh-text">项目库</h2>
            <div className="flex items-center gap-3">
              <div className="relative hidden md:block">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-vh-text-muted" />
                <input 
                  type="text" 
                  placeholder="搜索项目..." 
                  className="w-64 h-9 bg-vh-bg border border-vh-border rounded-md pl-9 pr-3 text-sm text-vh-text placeholder-vh-text-dark focus:outline-none focus:border-vh-border-strong focus:ring-1 focus:ring-vh-border-strong transition-all"
                />
              </div>
              <button className="flex items-center justify-center p-2 rounded-md border border-vh-border bg-vh-bg text-vh-text hover:bg-vh-elevated transition-colors tooltip-trigger relative group">
                <Filter className="w-4 h-4 text-vh-text-muted" />
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 rounded bg-vh-bg border border-vh-border text-sm font-medium text-vh-text hover:bg-vh-elevated transition-colors">
                <Upload className="w-4 h-4" /> 导入项目
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 rounded bg-blue-600 border border-blue-500 text-sm font-medium text-white hover:bg-blue-700 transition-colors shadow-[0_0_15px_rgba(37,99,235,0.2)]">
                <Plus className="w-4 h-4" /> 新建项目
              </button>
            </div>
          </div>

          <div className="flex items-center gap-6 overflow-x-auto scrollbar-hide">
            {TABS.map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "py-3 text-sm font-medium whitespace-nowrap transition-colors relative focus-visible:outline-none focus-visible:text-vh-text",
                  activeTab === tab ? "text-vh-text" : "text-vh-text-muted hover:text-vh-text"
                )}
              >
                {tab}
                {activeTab === tab && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-vh-signal rounded-t-full" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* DataTable */}
        <div className="flex-1 overflow-auto bg-vh-bg p-6">
          {data.length === 0 ? (
            <div className="h-[400px] flex flex-col items-center justify-center text-center p-8 border border-dashed border-vh-border rounded-lg bg-vh-surface/30">
              <FileText className="w-8 h-8 text-vh-text-dark mb-3" />
              <h3 className="text-vh-text font-medium mb-1">
                {activeTab === "草稿" ? "还没有草稿。" : "你还没有公开任何项目。"}
              </h3>
              <p className="text-sm text-vh-text-muted mb-6">
                {activeTab === "草稿" ? "新建一个项目开始。" : "发布首个项目与全世界协作。"}
              </p>
              <button className="px-4 py-2 rounded bg-vh-bg border border-vh-border text-sm text-vh-text hover:bg-vh-elevated transition-colors">
                {activeTab === "草稿" ? "新建项目" : "发布首个项目"}
              </button>
            </div>
          ) : (
            <div className="w-full rounded-md border border-vh-border bg-vh-surface overflow-hidden">
              {selectedIds.length > 0 && (
                <div className="bg-vh-elevated px-4 py-2 border-b border-vh-border flex items-center justify-between">
                  <span className="text-sm font-mono text-vh-text-muted">Selected {selectedIds.length} items</span>
                  <div className="flex items-center gap-2">
                    <button className="px-3 py-1 rounded bg-vh-bg border border-vh-border text-xs text-vh-text hover:bg-vh-surface">归档</button>
                    <button className="px-3 py-1 rounded bg-vh-bg border border-vh-border text-xs text-vh-text hover:bg-vh-surface">下线</button>
                    <button className="px-3 py-1 rounded bg-vh-bg border border-vh-border text-xs text-vh-text hover:bg-vh-surface">批量标签</button>
                  </div>
                </div>
              )}
              <table className="w-full text-left text-sm whitespace-nowrap">
                <thead className="bg-vh-bg/50 text-[11px] font-mono uppercase tracking-wider text-vh-text-dark border-b border-vh-border">
                  <tr>
                    <th className="px-4 py-3 w-[40px]">
                      <button onClick={toggleSelectAll} className="text-vh-text-muted hover:text-vh-text">
                        {selectedIds.length === data.length ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                      </button>
                    </th>
                    <th className="px-4 py-3 font-medium">名称</th>
                    <th className="px-4 py-3 font-medium">状态</th>
                    <th className="px-4 py-3 font-medium">可见性</th>
                    <th className="px-4 py-3 font-medium">许可证</th>
                    <th className="px-4 py-3 font-medium">绑定 Workspace</th>
                    <th className="px-4 py-3 font-medium">最近更新</th>
                    <th className="px-4 py-3 font-medium">协作意向数</th>
                    <th className="px-4 py-3 font-medium text-right">操作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-vh-border">
                  {data.map((row) => (
                    <tr key={row.id} className="hover:bg-vh-elevated transition-colors group">
                      <td className="px-4 py-3">
                        <button onClick={() => toggleSelect(row.id)} className="text-vh-text-muted hover:text-vh-text">
                          {selectedIds.includes(row.id) ? <CheckSquare className="w-4 h-4 text-blue-500" /> : <Square className="w-4 h-4" />}
                        </button>
                      </td>
                      <td className="px-4 py-3 flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-gradient-to-br from-gray-800 to-gray-900 border border-vh-border shrink-0" />
                        <div className="flex flex-col">
                          <span className="font-medium text-vh-text">{row.name}</span>
                          <span className="text-[11px] font-mono text-vh-text-dark">{row.slug}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          "px-2 py-0.5 text-[11px] font-mono rounded border",
                          row.status === "已公开" ? "bg-green-900/20 text-green-400 border-green-900/50" : "bg-orange-900/20 text-orange-400 border-orange-900/50"
                        )}>
                          {row.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5 text-vh-text-muted">
                          {row.visibility === "globe" && <Globe className="w-3.5 h-3.5" />}
                          {row.visibility === "lock" && <Lock className="w-3.5 h-3.5" />}
                          {row.visibility === "eye" && <Eye className="w-3.5 h-3.5" />}
                          <span className="text-xs">{row.visibility === "globe" ? "Public" : row.visibility === "lock" ? "Private" : "Unlisted"}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-1.5 py-0.5 bg-vh-bg border border-vh-border rounded text-[11px] font-mono text-vh-text-muted">
                          {row.license}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-sm bg-vh-bg border border-vh-border flex items-center justify-center text-[10px] font-bold text-vh-text">
                            {row.workspace[0]}
                          </div>
                          <span className="text-sm text-vh-text-muted">{row.workspace}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-[11px] font-mono text-vh-text-dark">{row.updated}</span>
                      </td>
                      <td className="px-4 py-3">
                        <button className="text-[11px] font-mono text-vh-accent hover:underline flex items-center gap-1">
                          {row.intentCount} <ChevronDown className="w-3 h-3 -rotate-90" />
                        </button>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button className="p-1 rounded text-vh-text-muted hover:text-vh-text hover:bg-vh-bg transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </ConsoleShell>
  );
}
