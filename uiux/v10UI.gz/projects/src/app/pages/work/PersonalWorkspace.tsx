import React, { useState } from "react";
import { ConsoleShell } from "../../components/work/ConsoleShell";
import { Home, ChevronDown, Plus, Upload, Camera, Database, Lock, Cpu, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { cn } from "../../utils";
import { TaskData, TaskCard } from "../../components/work/TaskCard";

export function PersonalWorkspace() {
  const [activeTab, setActiveTab] = useState("任务");

  const TABS = ["任务", "活动流", "文件", "快照", "Agent"];

  const mockTasks: TaskData[] = [
    {
      id: "t-1",
      verb: "为 @project-x 生成 OpenAPI 文档",
      state: "in-progress",
      agent: "DocsBot-v2",
      preview: "Analyzing controller abstract trees...",
      actorType: "agent",
      actorAvatar: "Bot",
    },
    {
      id: "t-2",
      verb: "优化 Navbar 组件的重渲染逻辑",
      state: "pending",
      agent: "ReactExpert",
      preview: "Added useMemo wrapper to navigation array.",
      actorType: "agent",
      actorAvatar: "Bot",
    },
    {
      id: "t-3",
      verb: "更新 README 部署指南",
      state: "completed",
      agent: "System",
      preview: "Merged PR #40 into main.",
      actorType: "user",
      actorAvatar: "ME",
    },
    {
      id: "t-4",
      verb: "部署到边缘节点",
      state: "failed",
      agent: "OpsBot",
      preview: "Timeout connecting to region us-west-2.",
      actorType: "agent",
      actorAvatar: "Bot",
    }
  ];

  const columns = [
    { id: "in-progress", title: "进行中", items: mockTasks.filter(t => t.state === "in-progress") },
    { id: "pending", title: "待确认", items: mockTasks.filter(t => t.state === "pending") },
    { id: "completed", title: "已完成", items: mockTasks.filter(t => t.state === "completed") },
    { id: "failed", title: "失败", items: mockTasks.filter(t => t.state === "failed") },
  ];

  const rightRailContent = (
    <div className="flex flex-col gap-4">
      {["DocsBot-v2", "ReactExpert", "OpsBot"].map(agent => (
        <div key={agent} className="p-3 rounded border border-vh-border bg-vh-bg flex items-center justify-between">
           <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded bg-vh-surface flex items-center justify-center text-vh-text border border-vh-border-strong">
               <Cpu className="w-4 h-4 text-vh-violet" />
             </div>
             <div className="flex flex-col">
               <span className="text-xs font-mono font-bold text-vh-text">{agent}</span>
               <span className="text-[10px] font-mono text-vh-text-muted flex items-center gap-1">
                 <span className="w-1.5 h-1.5 rounded-full bg-green-500" /> 在线
               </span>
             </div>
           </div>
           <button className="text-vh-text-muted hover:text-vh-text p-1 rounded hover:bg-vh-elevated">
             <ChevronDown className="w-4 h-4" />
           </button>
        </div>
      ))}
    </div>
  );

  return (
    <ConsoleShell mobileBannerText="建议在桌面端使用 Workspace Console" rightRail={rightRailContent}>
      
      {/* WorkspaceTopBar */}
      <div className="h-16 flex items-center justify-between px-6 border-b border-vh-border bg-vh-surface shrink-0 z-20">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-vh-text font-medium">
            <Home className="w-4 h-4 text-vh-text-muted" />
            <span className="text-sm">我的工作区</span>
          </div>
          
          <div className="h-4 w-[1px] bg-vh-border mx-2" />
          
          <button className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-vh-bg border border-vh-border hover:border-vh-border-strong hover:bg-vh-elevated transition-colors group focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent">
            <span className="w-2 h-2 rounded-full bg-vh-signal group-hover:shadow-[0_0_8px_rgba(205,213,227,0.5)] transition-shadow" />
            <span className="text-xs font-mono font-medium text-vh-text">vibe-core-ui</span>
            <ChevronDown className="w-3.5 h-3.5 text-vh-text-muted" />
          </button>

          <div className="hidden xl:flex items-center gap-3 ml-4">
            <span className="text-[10px] font-mono text-vh-text-muted bg-vh-bg px-2 py-0.5 rounded border border-vh-border">3 智能体</span>
            <span className="text-[10px] font-mono text-vh-text-muted bg-vh-bg px-2 py-0.5 rounded border border-vh-border">18 快照</span>
            <span className="text-[10px] font-mono text-vh-text-muted bg-vh-bg px-2 py-0.5 rounded border border-vh-border">2.3/5 GB</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="flex items-center justify-center p-2 rounded-md border border-vh-border bg-vh-bg text-vh-text hover:bg-vh-elevated transition-colors tooltip-trigger relative group focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent">
            <Plus className="w-4 h-4" />
            <span className="absolute top-full mt-2 px-2 py-1 bg-vh-elevated border border-vh-border rounded text-[10px] font-mono text-vh-text whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none">
              新建项目
            </span>
          </button>
          <button className="flex items-center justify-center p-2 rounded-md border border-vh-border bg-vh-bg text-vh-text hover:bg-vh-elevated transition-colors tooltip-trigger relative group focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent">
            <Upload className="w-4 h-4" />
            <span className="absolute top-full mt-2 px-2 py-1 bg-vh-elevated border border-vh-border rounded text-[10px] font-mono text-vh-text whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none">
              上传
            </span>
          </button>
          <button className="flex items-center justify-center p-2 rounded-md border border-vh-border bg-vh-bg text-vh-text hover:bg-vh-elevated transition-colors tooltip-trigger relative group focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent">
            <Camera className="w-4 h-4" />
            <span className="absolute top-full mt-2 px-2 py-1 bg-vh-elevated border border-vh-border rounded text-[10px] font-mono text-vh-text whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none">
              创建快照
            </span>
          </button>
        </div>
      </div>

      {/* ViewTabs */}
      <div className="px-6 border-b border-vh-border bg-vh-surface shrink-0 overflow-x-auto scrollbar-hide">
        <div className="flex items-center gap-6">
          {TABS.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "py-3 text-sm font-medium whitespace-nowrap transition-colors relative focus-visible:outline-none focus-visible:text-vh-text",
                activeTab === tab ? "text-vh-text" : "text-vh-text-muted hover:text-vh-text"
              )}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-vh-signal rounded-t-full" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-x-auto overflow-y-hidden bg-vh-bg p-6 scrollbar-hide focus:outline-none">
        {activeTab === "任务" && (
          <div className="flex gap-6 h-full min-w-max pb-4">
            {columns.map(col => (
              <div key={col.id} className="flex flex-col w-[300px] shrink-0 border border-vh-border bg-vh-surface/30 rounded-lg overflow-hidden">
                <div className="flex items-center justify-between p-3 border-b border-vh-border bg-vh-surface shrink-0">
                  <span className="text-xs font-mono text-vh-text font-semibold tracking-wider">
                    {col.title}
                  </span>
                  <span className="w-5 h-5 rounded bg-vh-elevated border border-vh-border flex items-center justify-center text-[10px] font-mono text-vh-text-muted">
                    {col.items.length}
                  </span>
                </div>
                
                <div className="flex-1 overflow-y-auto p-3 space-y-3 scrollbar-hide">
                  {col.items.length > 0 ? (
                    col.items.map(item => (
                      <TaskCard key={item.id} task={item} />
                    ))
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-4 border border-dashed border-vh-border rounded-lg bg-vh-bg/50">
                      <div className="w-10 h-10 rounded-full bg-vh-surface border border-vh-border flex items-center justify-center mb-2">
                        <Database className="w-4 h-4 text-vh-text-dark" />
                      </div>
                      <span className="text-xs font-mono text-vh-text-muted">暂无任务</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
        
        {activeTab !== "任务" && (
          <div className="flex flex-col items-center justify-center h-full text-center max-w-sm mx-auto">
            <div className="w-16 h-16 rounded-full bg-vh-surface border border-vh-border flex items-center justify-center mb-4">
              <Lock className="w-6 h-6 text-vh-text-dark" />
            </div>
            <h3 className="text-lg font-semibold text-vh-text mb-2 tracking-tight">内容为空</h3>
            <p className="text-sm text-vh-text-muted leading-relaxed">
              这是 {activeTab} 视图的预留区域，数据尚未初始化或已被归档清理。
            </p>
          </div>
        )}
      </div>
    </ConsoleShell>
  );
}
