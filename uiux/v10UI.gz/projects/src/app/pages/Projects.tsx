import { FolderKanban, Plus, MoreHorizontal } from "lucide-react";

const projects = [
  { id: "v10", name: "VibeHub v10.0 Core", status: "Active", progress: 68, members: 12 },
  { id: "mobile", name: "iOS Refactor", status: "Planning", progress: 14, members: 5 },
  { id: "api", name: "GraphQL to REST", status: "Active", progress: 92, members: 3 },
  { id: "design", name: "Monochrome Geek Dark DS", status: "Completed", progress: 100, members: 4 },
];

export function Projects() {
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center justify-between border-b border-border-default pb-6">
        <div>
          <h1 className="text-h2 font-medium tracking-tight">项目 (Projects)</h1>
          <p className="text-secondary text-body-sm mt-1">Manage active repositories and initiatives.</p>
        </div>
        <button className="bg-primary text-inverse hover:bg-opacity-90 px-4 py-2 rounded-md font-medium text-body-sm flex items-center gap-2 transition-all">
          <Plus size={16} />
          新建项目 (New Project)
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map(p => (
          <div key={p.id} className="group p-5 rounded-xl border border-border-default hover:border-border-strong bg-surface hover:bg-surface-hover transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-md bg-subtle flex items-center justify-center text-primary font-mono text-body-lg">
                {p.id.substring(0, 2).toUpperCase()}
              </div>
              <button className="p-1 rounded text-muted hover:bg-subtle hover:text-primary transition-colors">
                <MoreHorizontal size={18} />
              </button>
            </div>
            <h3 className="text-body-lg font-medium text-primary mb-1">{p.name}</h3>
            <div className="flex items-center gap-2 mb-6">
              <span className={`px-2 py-0.5 rounded-[4px] text-micro font-mono ${
                p.status === "Active" ? "bg-accent-apple-subtle text-accent-apple" :
                p.status === "Completed" ? "bg-semantic-success-subtle text-semantic-success" :
                "bg-subtle text-muted"
              }`}>
                {p.status}
              </span>
              <span className="text-caption text-secondary font-mono">{p.members} contributors</span>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between text-caption font-mono">
                <span className="text-muted">Progress</span>
                <span className="text-primary">{p.progress}%</span>
              </div>
              <div className="w-full h-1.5 rounded-pill bg-elevated border border-border-subtle overflow-hidden">
                <div 
                  className={`h-full rounded-pill transition-all duration-1000 ${
                    p.progress === 100 ? 'bg-semantic-success' : 'bg-primary'
                  }`}
                  style={{ width: `${p.progress}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}