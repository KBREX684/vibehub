import { ArrowRight, Compass, MessageSquarePlus, Users, Bot, Shield, Lock, Code, Globe } from "lucide-react";
import { Link } from "react-router";
import Threads from "../components/Threads";

export function Home() {
  return (
    <div className="min-h-full bg-vh-void text-vh-text font-sans">

      {/* ── Hero ── */}
      <section className="relative w-full overflow-hidden" style={{ minHeight: '560px' }}>
        {/* Threads background animation */}
        <div className="absolute inset-0 z-0">
          <Threads
            color={[0.804, 0.835, 0.890]}
            amplitude={1}
            distance={0.3}
            enableMouseInteraction={true}
          />
        </div>
        {/* Fade-to-void gradient at bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-vh-void to-transparent z-[1] pointer-events-none" />
        {/* Subtle noise overlay */}
        <div
          className="absolute inset-0 pointer-events-none z-[2] opacity-[0.04]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'repeat',
            backgroundSize: '256px 256px',
          }}
        />

        {/* Content */}
        <div className="relative z-10 max-w-[1440px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col justify-center" style={{ minHeight: '560px' }}>
          <div className="max-w-2xl pt-16 pb-24">
            <div className="font-mono text-[11px] text-vh-text uppercase tracking-[0.2em] flex items-center gap-2 mb-6">
              <div className="w-1.5 h-1.5 rounded-full bg-vh-signal vh-breathe" style={{ color: 'var(--color-vh-signal)' }} />
              打破一人公司的孤岛 · 团队-AGENT协作平台
            </div>

            <h1 className="font-display text-[2.75rem] md:text-[3.5rem] font-bold leading-[1.05] tracking-[-0.03em] text-vh-text mb-16">
              重构团队协作流<br />
              <span className="text-vh-text/70">让开发者和 Agent 在同一空间推进项目</span>
            </h1>


            <div className="flex items-center gap-4">
              <Link
                to="/discover"
                className="h-12 px-7 inline-flex items-center justify-center gap-2 rounded-md font-medium transition-all bg-vh-signal hover:bg-vh-accent-hover text-vh-void shadow-[0_0_24px_rgba(205,213,227,0.15)] hover:shadow-[0_0_36px_rgba(205,213,227,0.22)]"
              >
                去发现项目 <ArrowRight size={16} />
              </Link>
              <Link
                to="/signup"
                className="h-12 px-7 inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors border border-vh-border hover:bg-vh-deep hover:border-vh-border-strong text-vh-text"
              >
                免费注册
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Core Loop ── */}
      <section className="max-w-[1440px] mx-auto px-4 md:px-8 lg:px-12 py-20">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="text-2xl font-display font-bold text-vh-text mb-2">协作主循环</h2>
            <p className="text-sm text-vh-text-muted">从发现到交付，每一步都有人与 Agent 的协作痕迹</p>
          </div>
          <span className="hidden md:block font-mono text-[11px] text-vh-text-dim uppercase tracking-wider">协作主循环</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            { icon: Compass, label: "发现项目", desc: "在社区中探索活跃的开源项目与协作机会", color: "vh-cyan", dim: "vh-cyan-dim", num: "01" },
            { icon: MessageSquarePlus, label: "发起协作", desc: "表达协作意图，快速创建工作流与讨论通道", color: "vh-violet", dim: "vh-violet-dim", num: "02" },
            { icon: Users, label: "工作空间", desc: "在结构化数字空间中，人类与 AI 共同维护代码库", color: "vh-blue", dim: "vh-blue-dim", num: "03" },
            { icon: Bot, label: "Agent 推进", desc: "授权智能体自动执行代码审查、构建和重构", color: "vh-signal", dim: "vh-signal-dim", num: "04" },
          ].map(({ icon: Icon, label, desc, color, dim, num }) => (
            <div key={num} className="p-6 border border-vh-border rounded-xl bg-vh-surface flex flex-col gap-4 vh-card-glow hover:border-vh-signal/20 transition-all">
              <div className="flex items-center justify-between">
                <div className={`w-10 h-10 rounded-md bg-${dim} text-${color} flex items-center justify-center`}>
                  <Icon size={20} />
                </div>
                <span className="font-mono text-[11px] text-vh-text-dim">{num}</span>
              </div>
              <div>
                <h3 className="text-lg font-display font-semibold text-vh-text mb-2">{label}</h3>
                <p className="text-sm text-vh-text-muted leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Trust ── */}
      <section className="max-w-[1440px] mx-auto px-4 md:px-8 lg:px-12 pb-20">
        <div className="border border-vh-border rounded-xl bg-vh-surface overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-vh-border">
            {[
              { icon: Shield, title: "审计 · 权限 · 交付确认", desc: "每一步操作皆可追溯，精细到 Agent 级别的读写权限控制", code: "AUDIT_LOG_ENABLED = true" },
              { icon: Lock, title: "中国数据区域 · 跨境边界", desc: "符合国内合规要求，支持私有化部署与专线隔离访问", code: "REGION = \"cn-east-1\"" },
              { icon: Code, title: "AIGC 公示 · 模型登记", desc: "集成已备案的开源及商业大模型，模型水印与声明清晰可见", code: "MODEL_REGISTRY = \"Gz-2026\"" },
            ].map(({ icon: Icon, title, desc, code }) => (
              <div key={code} className="p-6 space-y-2">
                <Icon size={20} className="text-vh-text-muted mb-4" />
                <h4 className="text-base font-display font-semibold">{title}</h4>
                <p className="text-sm text-vh-text-muted">{desc}</p>
                <div className="font-mono text-[11px] text-vh-text-dim pt-2">{code}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="max-w-[1440px] mx-auto px-4 md:px-8 lg:px-12 pt-12 border-t border-vh-border">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div className="space-y-4">
            <h5 className="font-medium text-sm">产品</h5>
            <ul className="space-y-2 text-sm text-vh-text-muted">
              <li><Link to="#" className="hover:text-vh-text transition-colors">工作空间</Link></li>
              <li><Link to="#" className="hover:text-vh-text transition-colors">Agents 库</Link></li>
              <li><Link to="#" className="hover:text-vh-text transition-colors">集成中心</Link></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h5 className="font-medium text-sm">开发者</h5>
            <ul className="space-y-2 text-sm text-vh-text-muted">
              <li><Link to="#" className="hover:text-vh-text transition-colors">API 文档</Link></li>
              <li><Link to="#" className="hover:text-vh-text transition-colors">开源 SDK</Link></li>
              <li><Link to="#" className="hover:text-vh-text transition-colors">CLI 工具</Link></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h5 className="font-medium text-sm">法律</h5>
            <ul className="space-y-2 text-sm text-vh-text-muted">
              <li><Link to="#" className="hover:text-vh-text transition-colors">隐私政策</Link></li>
              <li><Link to="#" className="hover:text-vh-text transition-colors">服务条款</Link></li>
              <li><Link to="#" className="hover:text-vh-text transition-colors">AIGC 合规声明</Link></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h5 className="font-medium text-sm">语言与区域</h5>
            <ul className="space-y-2 text-sm text-vh-text-muted">
              <li className="font-mono text-[11px] bg-vh-deep px-2 py-1 rounded-sm inline-block">ZH-CN</li>
              <li className="flex items-center gap-1 mt-3 text-vh-text-dim">
                <Globe size={14} /> cn-east-1
              </li>
            </ul>
          </div>
        </div>
        <div className="flex flex-col md:flex-row items-center justify-between py-6 border-t border-vh-border">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <svg width="20" height="20" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2 14 L7 7 L12 18 L17 5 L22 14" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="text-vh-signal" />
              <circle cx="7" cy="7" r="2" className="fill-vh-signal" />
              <circle cx="17" cy="5" r="2" className="fill-vh-signal" />
              <path d="M24 11 L26 14 L24 17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-vh-signal/40" />
            </svg>
            <span className="font-display font-medium text-sm">VibeHub</span>
          </div>
          <div className="text-[11px] text-vh-text-dim font-mono">
            © 2026 VibeHub Network. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
