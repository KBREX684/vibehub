import { MessageSquare, Plus, CornerDownRight } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

const topics = [
  { 
    id: "D-1", 
    title: "Monochrome Geek Dark DS Implementation Guide",
    excerpt: "We're adopting a purely monochrome dark theme for v10. Key points: use canvas #09090B, no gradients, flat borders. Thoughts?",
    author: "Alice Bao",
    avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=alice",
    time: "2h ago",
    replies: 14,
    tags: ["design", "v10.0"]
  },
  { 
    id: "D-2", 
    title: "Moving away from REST to GraphQL",
    excerpt: "The API payload size is getting too large for mobile clients. GraphQL can help us fetch only what we need.",
    author: "Chen Dong",
    avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=chen",
    time: "5h ago",
    replies: 32,
    tags: ["backend", "api"]
  },
  { 
    id: "D-3", 
    title: "New AI Agents Copilot features",
    excerpt: "Let's discuss how the AI agents should integrate into the command palette. It should feel like a pair programmer.",
    author: "Yuan Zhi",
    avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=yuan",
    time: "1d ago",
    replies: 8,
    tags: ["ai", "product"]
  }
];

export function Discussions() {
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center justify-between border-b border-border-default pb-6">
        <div>
          <h1 className="text-h2 font-medium tracking-tight">讨论 (Discussions)</h1>
          <p className="text-secondary text-body-sm mt-1">Collaborate, ideate, and resolve issues.</p>
        </div>
        <button className="bg-primary text-inverse hover:bg-opacity-90 px-4 py-2 rounded-md font-medium text-body-sm flex items-center gap-2 transition-all">
          <Plus size={16} />
          新话题 (New Topic)
        </button>
      </div>

      <div className="space-y-4">
        {topics.map((topic) => (
          <div key={topic.id} className="group p-5 rounded-xl border border-border-default hover:border-border-strong bg-surface hover:bg-surface-hover transition-all flex gap-4 cursor-pointer">
            <div className="flex-shrink-0 flex flex-col items-center gap-2">
              <div className="w-10 h-10 rounded-full border border-border-strong bg-elevated overflow-hidden group-hover:border-accent-cyan transition-colors">
                <ImageWithFallback src={topic.avatar} alt={topic.author} className="w-full h-full object-cover grayscale" />
              </div>
              <div className="flex flex-col items-center justify-center text-muted font-mono text-micro mt-2 group-hover:text-secondary transition-colors">
                <MessageSquare size={14} className="mb-1" />
                {topic.replies}
              </div>
            </div>

            <div className="flex-1 space-y-2">
              <div className="flex items-start justify-between">
                <h3 className="text-body-lg font-medium text-primary group-hover:text-accent-cyan transition-colors">
                  {topic.title}
                </h3>
                <span className="font-mono text-micro text-muted whitespace-nowrap">
                  {topic.time}
                </span>
              </div>
              
              <p className="text-body-sm text-secondary line-clamp-2 leading-relaxed">
                {topic.excerpt}
              </p>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-2">
                  <span className="text-caption text-muted flex items-center gap-1 font-mono">
                    <CornerDownRight size={14} />
                    {topic.author}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {topic.tags.map(tag => (
                    <span key={tag} className="px-2 py-0.5 rounded-[4px] bg-subtle border border-border-default text-muted font-mono text-micro">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}