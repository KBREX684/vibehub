import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  FolderKanban, Bell, MessageSquare, Star, GitFork, CheckSquare,
  Search, Plus, AlertTriangle, Inbox, Zap,
} from "lucide-react";

// Primitives
import {
  Button, IconButton, Input, Textarea, Select, Checkbox, Radio, Toggle,
  Avatar, AvatarStack, Badge, StatusPill, Tag, Tooltip, Kbd, Divider,
  Skeleton, EmptyState, ToastItem, ConfirmDialog,
} from "../components/vibehub/primitives";
import type { StatusKey, Tone, ToastType } from "../components/vibehub/primitives";

// Shell
import {
  TopNav, LeftRail, ConsoleShell, PageHeader, SectionCard, WorkspaceTopBar,
  ComplianceStrip, ViewTabs, DrawerSheet, CommandPaletteShell,
} from "../components/vibehub/shell";

// Domain
import {
  ProjectCard, IntentCard, TaskCard, ActivityEvent, SnapshotCard,
  AgentBadge, NotificationRow,
} from "../components/vibehub/domain-cards";

/* ─── Showcase Section ─── */
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-4">
      <h2 className="text-[length:var(--text-h3)] text-[var(--text-primary)] font-sans font-medium">{title}</h2>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

function SubSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <h3 className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)] font-sans font-medium uppercase tracking-wider">{title}</h3>
      {children}
    </div>
  );
}

function Row({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={`flex items-center gap-3 flex-wrap ${className || ""}`}>{children}</div>;
}

/* ─── Main ─── */
export function UILibrary() {
  const [checkA, setCheckA] = useState(false);
  const [checkB, setCheckB] = useState(true);
  const [radioVal, setRadioVal] = useState("a");
  const [toggleA, setToggleA] = useState(false);
  const [toggleB, setToggleB] = useState(true);
  const [selectVal, setSelectVal] = useState("opt1");
  const [activeTab, setActiveTab] = useState("overview");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [toasts, setToasts] = useState<{ id: number; type: ToastType; message: string }[]>([]);

  const addToast = (type: ToastType, message: string) => {
    const id = Date.now();
    setToasts((t) => [...t, { id, type, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  };

  const allStatuses: StatusKey[] = [
    "draft", "public", "private", "open-source", "archived",
    "open", "accepted", "declined", "expired", "blocked",
    "pending", "running", "pending-confirm", "done", "failed",
  ];
  const tones: Tone[] = ["neutral", "apple", "violet", "cyan", "success", "warning", "error"];

  return (
    <div className="min-h-full bg-[var(--canvas)] p-6 space-y-12 max-w-5xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-3">
          <h1 className="text-[length:var(--text-h1)] text-[var(--text-primary)] font-sans font-medium">VibeHub/UI v10</h1>
          <Tag>组件库</Tag>
        </div>
        <p className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)]">
          Monochrome Geek Dark · 8pt Grid · CSS Token Driven · Dev-Handoff Ready
        </p>
      </div>

      <Divider />

      {/* ═══ A. PRIMITIVES ═══ */}
      <Section title="A. 基础组件 (Primitives)">

        {/* Buttons */}
        <SubSection title="Button · 按钮">
          <SectionCard>
            <div className="space-y-4">
              {(["sm", "md", "lg"] as const).map((size) => (
                <div key={size} className="space-y-2">
                  <span className="text-[length:var(--text-micro)] text-[var(--text-muted)] font-mono">size={size}</span>
                  <Row>
                    <Button variant="primary" size={size}>Primary</Button>
                    <Button variant="apple" size={size}>Apple CTA</Button>
                    <Button variant="secondary" size={size}>Secondary</Button>
                    <Button variant="ghost" size={size}>Ghost</Button>
                    <Button variant="destructive" size={size}>Destructive</Button>
                    <Button variant="primary" size={size} disabled>Disabled</Button>
                  </Row>
                </div>
              ))}
            </div>
          </SectionCard>
        </SubSection>

        {/* IconButton */}
        <SubSection title="IconButton · 图标按钮">
          <SectionCard>
            <Row>
              <IconButton size="sm"><Search size={14} /></IconButton>
              <IconButton size="md"><Plus size={16} /></IconButton>
              <IconButton size="lg"><Bell size={18} /></IconButton>
              <IconButton size="md" disabled><Star size={16} /></IconButton>
            </Row>
          </SectionCard>
        </SubSection>

        {/* Input */}
        <SubSection title="Input · 输入框">
          <SectionCard>
            <div className="space-y-3 max-w-md">
              <Input placeholder="默认输入框 (md)" />
              <Input placeholder="搜索..." leftIcon={<Search size={14} />} inputType="search" />
              <Input placeholder="密码" inputType="password" />
              <Input placeholder="Small" size="sm" />
              <Input placeholder="Large" size="lg" />
              <Input placeholder="Disabled" disabled />
            </div>
          </SectionCard>
        </SubSection>

        {/* Textarea */}
        <SubSection title="Textarea · 文本域">
          <SectionCard>
            <div className="max-w-md">
              <Textarea placeholder="输入内容..." />
            </div>
          </SectionCard>
        </SubSection>

        {/* Select */}
        <SubSection title="Select · 下拉选择">
          <SectionCard>
            <div className="max-w-[200px]">
              <Select
                value={selectVal}
                onChange={setSelectVal}
                options={[
                  { value: "opt1", label: "选项一" },
                  { value: "opt2", label: "选项二" },
                  { value: "opt3", label: "选项三" },
                ]}
              />
            </div>
          </SectionCard>
        </SubSection>

        {/* Checkbox / Radio / Toggle */}
        <SubSection title="Checkbox · Radio · Toggle">
          <SectionCard>
            <div className="space-y-4">
              <Row>
                <Checkbox checked={checkA} onChange={setCheckA} label="未选中" />
                <Checkbox checked={checkB} onChange={setCheckB} label="已选中" />
                <Checkbox checked={false} disabled label="禁用" />
              </Row>
              <Divider />
              <Row>
                <Radio checked={radioVal === "a"} onChange={() => setRadioVal("a")} label="选项 A" />
                <Radio checked={radioVal === "b"} onChange={() => setRadioVal("b")} label="选项 B" />
                <Radio checked={false} disabled label="禁用" />
              </Row>
              <Divider />
              <Row>
                <Toggle checked={toggleA} onChange={setToggleA} />
                <Toggle checked={toggleB} onChange={setToggleB} />
                <Toggle checked={false} disabled />
              </Row>
            </div>
          </SectionCard>
        </SubSection>

        {/* Avatar */}
        <SubSection title="Avatar · 头像 & AvatarStack">
          <SectionCard>
            <Row>
              <Avatar name="张三" size="sm" />
              <Avatar name="李四" size="md" />
              <Avatar name="王五" size="lg" />
              <Avatar name="赵六" size="xl" />
              <Divider orientation="vertical" />
              <AvatarStack
                avatars={[
                  { name: "张三" },
                  { name: "李四" },
                  { name: "王五" },
                  { name: "赵六" },
                  { name: "钱七" },
                  { name: "孙八" },
                ]}
                max={4}
              />
            </Row>
          </SectionCard>
        </SubSection>

        {/* Badge */}
        <SubSection title="Badge · 徽标">
          <SectionCard>
            <div className="space-y-3">
              <Row>
                {tones.map((t) => <Badge key={t} tone={t} style="subtle">{t}</Badge>)}
              </Row>
              <Row>
                {tones.map((t) => <Badge key={t} tone={t} style="solid">{t}</Badge>)}
              </Row>
            </div>
          </SectionCard>
        </SubSection>

        {/* StatusPill */}
        <SubSection title="StatusPill · 状态标签">
          <SectionCard>
            <Row>
              {allStatuses.map((s) => <StatusPill key={s} status={s} />)}
            </Row>
          </SectionCard>
        </SubSection>

        {/* Tag / Tooltip / Kbd */}
        <SubSection title="Tag · Tooltip · Kbd · Divider">
          <SectionCard>
            <Row>
              <Tag>MIT</Tag>
              <Tag>react</Tag>
              <Tag>v2.1.0</Tag>
              <Divider orientation="vertical" />
              <Tooltip content="快捷键提示">
                <span className="text-[length:var(--text-caption)] text-[var(--text-secondary)] cursor-default">悬停查看</span>
              </Tooltip>
              <Divider orientation="vertical" />
              <Kbd>⌘</Kbd>
              <Kbd>K</Kbd>
              <Kbd>Shift</Kbd>
              <Kbd>Enter</Kbd>
            </Row>
          </SectionCard>
        </SubSection>

        {/* Skeleton */}
        <SubSection title="Skeleton · 骨架屏">
          <SectionCard>
            <div className="space-y-3 max-w-md">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-20 w-full" />
              <div className="flex gap-3">
                <Skeleton className="h-8 w-8 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-3 w-2/3" />
                </div>
              </div>
            </div>
          </SectionCard>
        </SubSection>

        {/* EmptyState */}
        <SubSection title="EmptyState · 空状态">
          <SectionCard>
            <EmptyState
              icon={<Inbox size={32} />}
              title="暂无数据"
              description="当前没有可显示的内容，请尝试创建新项目"
              action={<Button variant="apple" size="sm"><Plus size={14} /> 新建项目</Button>}
            />
          </SectionCard>
        </SubSection>

        {/* Toast */}
        <SubSection title="Toast · 提示">
          <SectionCard>
            <Row>
              <Button variant="secondary" size="sm" onClick={() => addToast("success", "操作成功完成")}>Success</Button>
              <Button variant="secondary" size="sm" onClick={() => addToast("info", "这是一条信息提示")}>Info</Button>
              <Button variant="secondary" size="sm" onClick={() => addToast("warning", "注意：请检查配置")}>Warning</Button>
              <Button variant="secondary" size="sm" onClick={() => addToast("error", "操作失败，请重试")}>Error</Button>
            </Row>
          </SectionCard>
        </SubSection>

        {/* ConfirmDialog */}
        <SubSection title="ConfirmDialog · 确认对话框">
          <SectionCard>
            <Button variant="destructive" size="sm" onClick={() => setConfirmOpen(true)}>
              打开确认对话框
            </Button>
          </SectionCard>
        </SubSection>
      </Section>

      <Divider />

      {/* ═══ B. SHELL & LAYOUT ═══ */}
      <Section title="B. 外壳与布局 (Shell & Layout)">

        {/* TopNav */}
        <SubSection title="TopNav · 顶部导航栏 (h-56, sticky)">
          <div className="space-y-3">
            {/* Label */}
            <div className="flex items-center gap-2">
              <span className="text-[length:var(--text-micro)] font-mono text-[var(--text-muted)] uppercase tracking-wider">
                Guest 未登录变体
              </span>
            </div>
            {/* Guest variant preview */}
            <div
              className="rounded-[var(--radius-lg)] overflow-hidden border border-[var(--border-default)]"
              style={{ position: "relative" }}
            >
              <TopNav
                mode="guest"
                onCommandOpen={() => setCmdOpen(true)}
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <span className="text-[length:var(--text-micro)] font-mono text-[var(--text-muted)] uppercase tracking-wider">
                Authed 已登录变体 (free tier · unread=3 · admin)
              </span>
            </div>
            {/* Authed variant preview */}
            <div
              className="rounded-[var(--radius-lg)] overflow-hidden border border-[var(--border-default)]"
              style={{ position: "relative" }}
            >
              <TopNav
                mode="authed"
                user={{
                  name: "张伟",
                  email: "zhangwei@vibehub.dev",
                  isAdmin: true,
                }}
                subscription={{ tier: "free" }}
                unreadCount={3}
                onCommandOpen={() => setCmdOpen(true)}
                onCreateSelect={(key) => addToast("info", `创建操作: ${key}`)}
                onLogout={() => addToast("warning", "已退出登录")}
                onUpgrade={() => addToast("success", "跳转升级页面...")}
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <span className="text-[length:var(--text-micro)] font-mono text-[var(--text-muted)] uppercase tracking-wider">
                Authed 已登录变体 (pro tier · no unread · non-admin)
              </span>
            </div>
            <div
              className="rounded-[var(--radius-lg)] overflow-hidden border border-[var(--border-default)]"
              style={{ position: "relative" }}
            >
              <TopNav
                mode="authed"
                user={{
                  name: "李雨桐",
                  email: "liyutong@vibehub.dev",
                  isAdmin: false,
                }}
                subscription={{ tier: "pro" }}
                unreadCount={0}
                onCommandOpen={() => setCmdOpen(true)}
              />
            </div>
          </div>
        </SubSection>

        {/* PageHeader */}
        <SubSection title="PageHeader · 页面头部">
          <SectionCard className="p-0 overflow-hidden">
            <PageHeader
              title="项目列表"
              subtitle="管理你的所有项目和协作"
              filter={<Input placeholder="筛选..." size="sm" leftIcon={<Search size={12} />} />}
              action={<Button variant="apple" size="sm"><Plus size={14} /> 新建项目</Button>}
            />
          </SectionCard>
        </SubSection>

        {/* WorkspaceTopBar */}
        <SubSection title="WorkspaceTopBar · 工作区信息栏">
          <SectionCard className="p-0 overflow-hidden">
            <WorkspaceTopBar
              name="VibeHub 核心"
              project="AI Agent 系统"
              counts={[
                { label: "任务", value: 42 },
                { label: "成员", value: 8 },
                { label: "快照", value: 15 },
              ]}
              actions={<Button variant="secondary" size="sm">管理</Button>}
            />
          </SectionCard>
        </SubSection>

        {/* ComplianceStrip */}
        <SubSection title="ComplianceStrip · 合规信息条">
          <SectionCard className="p-0 overflow-hidden">
            <ComplianceStrip
              region="cn-east-1"
              crossBorder={false}
              modelFiling="沪AI-2024-0042"
              auditRetention="180天"
            />
          </SectionCard>
        </SubSection>

        {/* ViewTabs */}
        <SubSection title="ViewTabs · 视图选项卡">
          <SectionCard className="p-0 overflow-hidden">
            <ViewTabs
              tabs={[
                { key: "overview", label: "概览" },
                { key: "tasks", label: "任务" },
                { key: "snapshots", label: "快照" },
                { key: "settings", label: "设置" },
              ]}
              active={activeTab}
              onChange={setActiveTab}
            />
          </SectionCard>
        </SubSection>

        {/* SectionCard */}
        <SubSection title="SectionCard · 区块卡片">
          <SectionCard>
            <div className="space-y-2">
              <h4 className="text-[length:var(--text-body)] text-[var(--text-primary)] font-medium">区块标题</h4>
              <p className="text-[length:var(--text-caption)] text-[var(--text-secondary)]">
                这是一个标准区块卡片，使用 surface 背景 + 1px border，无阴影。
              </p>
            </div>
          </SectionCard>
        </SubSection>

        {/* DrawerSheet & CommandPalette */}
        <SubSection title="DrawerSheet & CommandPalette">
          <SectionCard>
            <Row>
              <Button variant="secondary" size="sm" onClick={() => setDrawerOpen(true)}>
                打开抽屉面板
              </Button>
              <Button variant="secondary" size="sm" onClick={() => setCmdOpen(true)}>
                打开命令面板
              </Button>
            </Row>
          </SectionCard>
        </SubSection>
      </Section>

      <Divider />

      {/* ═══ C. DOMAIN CARDS ═══ */}
      <Section title="C. 领域卡片 (Domain Cards)">

        {/* ProjectCard */}
        <SubSection title="ProjectCard v2 · 项目卡片">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ProjectCard
              title="AI 协作引擎 v3"
              author={{ name: "张三" }}
              type="工具"
              visibility="public"
              license="MIT"
              collabStatus="open"
              recommendationScore={4}
              description="基于多智能体协调的开发协作引擎，支持人机混合工作流和自动化交付管理"
            />
            <ProjectCard
              title="数据可视化平台"
              author={{ name: "李四" }}
              type="应用"
              visibility="private"
              collabStatus="pending"
              recommendationScore={2}
              description="面向数据分析师的低代码可视化平台，内置 20+ 图表组件和实时数据源连接"
            />
          </div>
        </SubSection>

        {/* IntentCard */}
        <SubSection title="IntentCard · 协作意向卡片">
          <IntentCard
            pitch="我们正在构建下一代 AI 代码审查工具，需要一位有 AST 分析经验的合作者。"
            whyYou="你在 Tree-sitter 和静态分析领域有深厚的开源贡献，非常适合这个方向。"
            howCollab="前期远程协作，每周同步一次。代码贡献以 PR 形式提交，核心模块共同维护。"
            status="pending"
            createdAt="2026-04-15 14:30"
            updatedAt="2026-04-17 09:15"
          />
        </SubSection>

        {/* TaskCard */}
        <SubSection title="TaskCard · 任务卡片">
          <div className="space-y-2">
            <TaskCard
              actor={{ name: "张三" }}
              action="创建了任务"
              target="完成 API 接口文档"
              state="pending"
              time="10 分钟前"
              onConfirm={() => {}}
            />
            <TaskCard
              actor={{ name: "AI Agent" }}
              action="完成了"
              target="代码审查 #142"
              state="done"
              time="1 小时前"
            />
            <TaskCard
              actor={{ name: "李四" }}
              action="标记为失败"
              target="部署预发布环境"
              state="failed"
              time="3 小时前"
            />
          </div>
        </SubSection>

        {/* ActivityEvent */}
        <SubSection title="ActivityEvent · 活动事件">
          <SectionCard>
            <div className="space-y-1">
              <ActivityEvent
                actor="张三"
                verb="提交了快照至"
                target="AI 协作引擎 v3"
                workspaceId="ws-a1b2"
                snapshotId="snap-c3d4"
                agentBindingId="bind-e5f6"
                time="2026-04-18 10:32"
              />
              <Divider />
              <ActivityEvent
                actor="AI Reviewer"
                verb="审核通过了"
                target="接口规范 v2.1"
                workspaceId="ws-a1b2"
                snapshotId="snap-g7h8"
                time="2026-04-18 09:15"
              />
            </div>
          </SectionCard>
        </SubSection>

        {/* SnapshotCard */}
        <SubSection title="SnapshotCard · 快照卡片">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <SnapshotCard
              title="Sprint 22 交付快照"
              intent="完成协作引擎核心 API 和权限模块"
              previousSnapshot="snap-v21"
              artifactCount={8}
              deliverableStatus="done"
            />
            <SnapshotCard
              title="Sprint 23 进行中"
              intent="实现多智能体调度和任务分配"
              artifactCount={3}
              deliverableStatus="running"
            />
          </div>
        </SubSection>

        {/* AgentBadge */}
        <SubSection title="AgentBadge · 智能体标签">
          <SectionCard>
            <Row>
              <AgentBadge role="Reader" />
              <AgentBadge role="Executor" />
              <AgentBadge role="Reviewer" />
              <AgentBadge role="Coordinator" />
            </Row>
          </SectionCard>
        </SubSection>

        {/* NotificationRow */}
        <SubSection title="NotificationRow · 通知行">
          <SectionCard className="p-0">
            <NotificationRow icon={<MessageSquare size={14} />} message="张三 在「API 设计」讨论中回复了你" time="5分钟前" />
            <Divider />
            <NotificationRow icon={<CheckSquare size={14} />} message="任务「数据库迁移」已被标记为完成" time="30分钟前" />
            <Divider />
            <NotificationRow icon={<GitFork size={14} />} message="李四 发起了项目「可视化平台」的协作意向" time="2小时前" />
            <Divider />
            <NotificationRow icon={<AlertTriangle size={14} />} message="AI Agent 在代码审查中发现 3 个潜在问题" time="昨天" />
          </SectionCard>
        </SubSection>
      </Section>

      <Divider />

      {/* Footer */}
      <div className="text-center py-8">
        <p className="text-[length:var(--text-caption)] text-[var(--text-muted)]">
          VibeHub/UI v10.0 · 所有组件遵循 8pt 网格 · CSS Token 驱动 · 零内联色值
        </p>
        <p className="text-[length:var(--text-micro)] text-[var(--text-muted)] mt-1 font-mono">
          Monochrome Geek Dark · Inter + Geist Mono
        </p>
      </div>

      {/* ─── Floating Overlays ─── */}
      <DrawerSheet open={drawerOpen} onClose={() => setDrawerOpen(false)} title="详情面板">
        <div className="space-y-4">
          <p className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)]">
            这是一个右侧抽屉面板，桌面端宽度 480px。可用于展示详情、编辑表单或预览内容。
          </p>
          <SectionCard>
            <div className="space-y-2">
              <h4 className="text-[length:var(--text-body)] text-[var(--text-primary)] font-medium">示例内容</h4>
              <p className="text-[length:var(--text-caption)] text-[var(--text-secondary)]">面板内可嵌套任意组件。</p>
            </div>
          </SectionCard>
        </div>
      </DrawerSheet>

      <CommandPaletteShell
        open={cmdOpen}
        onClose={() => setCmdOpen(false)}
        groups={[
          {
            heading: "快捷操作",
            items: [
              { icon: <Plus size={14} />, label: "新建项目", shortcut: "C" },
              { icon: <Search size={14} />, label: "搜索任务", shortcut: "⌘K" },
              { icon: <Zap size={14} />, label: "运行 AI Agent" },
            ],
          },
          {
            heading: "最近访问",
            items: [
              { icon: <FolderKanban size={14} />, label: "AI 协作引擎 v3" },
              { icon: <FolderKanban size={14} />, label: "数据可视化平台" },
            ],
          },
        ]}
      />

      <ConfirmDialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        onConfirm={() => setConfirmOpen(false)}
        title="确认删除项目"
        body="此操作不可撤销，项目中的所有数据将被永久删除。"
        confirmText="确认删除"
        confirmValue="DELETE"
      />

      {/* Toast container */}
      <div className="fixed bottom-4 right-4 z-[200] space-y-2">
        <AnimatePresence>
          {toasts.map((t) => (
            <ToastItem
              key={t.id}
              type={t.type}
              message={t.message}
              onDismiss={() => setToasts((ts) => ts.filter((x) => x.id !== t.id))}
            />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}