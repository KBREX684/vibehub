import { CheckCircle2, Circle, Clock, Filter, Plus, ArrowRight } from "lucide-react";
import { useState } from "react";

const mockTasks = [
  { id: "VBH-104", title: "Implement Command Palette", status: "done", priority: "high", assignee: "YZ" },
  { id: "VBH-105", title: "Setup Figma Variables mapping", status: "in-progress", priority: "high", assignee: "YZ" },
  { id: "VBH-106", title: "Update typography to Geist Mono", status: "todo", priority: "medium", assignee: "AB" },
  { id: "VBH-107", title: "Design V10 Dashboard layout", status: "done", priority: "low", assignee: "YZ" },
  { id: "VBH-108", title: "Refactor global CSS tokens", status: "in-progress", priority: "high", assignee: "CD" },
  { id: "VBH-109", title: "Write e2e tests for Sidebar", status: "todo", priority: "low", assignee: "Unassigned" },
];

export function Tasks() {
  const [filter, setFilter] = useState("all");

  const filteredTasks = mockTasks.filter(t => {
    if (filter === "all") return true;
    return t.status === filter;
  });

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center justify-between border-b border-border-default pb-6">
        <div>
          <h1 className="text-h2 font-medium tracking-tight">任务 (Tasks)</h1>
          <p className="text-secondary text-body-sm mt-1">Track and manage your work items.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-surface border border-border-default rounded-md p-1">
            {["all", "todo", "in-progress", "done"].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-sm text-caption font-medium capitalize transition-all ${
                  filter === f 
                    ? "bg-elevated text-primary shadow-sm" 
                    : "text-muted hover:text-secondary hover:bg-subtle"
                }`}
              >
                {f.replace("-", " ")}
              </button>
            ))}
          </div>
          <button className="bg-primary text-inverse hover:bg-opacity-90 p-2 rounded-md transition-colors flex items-center justify-center">
            <Plus size={18} />
          </button>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center px-4 py-2 text-caption font-mono text-muted uppercase tracking-wider border-b border-border-subtle mb-4">
          <div className="w-10"></div>
          <div className="flex-1">Task</div>
          <div className="w-24 text-center">Status</div>
          <div className="w-24 text-center">Priority</div>
          <div className="w-24 text-right">Assignee</div>
        </div>
        
        {filteredTasks.map((task) => (
          <div key={task.id} className="group flex items-center px-4 py-3 rounded-md border border-transparent hover:border-border-strong bg-surface hover:bg-surface-hover transition-all cursor-pointer shadow-card">
            <div className="w-10 flex-shrink-0 text-muted group-hover:text-primary transition-colors">
              {task.status === "done" ? <CheckCircle2 size={18} className="text-semantic-success" /> : 
               task.status === "in-progress" ? <Clock size={18} className="text-accent-apple" /> : 
               <Circle size={18} />}
            </div>
            <div className="flex-1 flex flex-col gap-1">
              <span className={`text-body-sm font-medium ${task.status === 'done' ? 'line-through text-muted' : 'text-primary'}`}>
                {task.title}
              </span>
              <span className="font-mono text-micro text-muted group-hover:text-secondary transition-colors">
                {task.id}
              </span>
            </div>
            <div className="w-24 text-center">
              <span className={`px-2 py-0.5 rounded-[4px] text-micro font-mono capitalize ${
                task.status === 'done' ? 'bg-semantic-success-subtle text-semantic-success' :
                task.status === 'in-progress' ? 'bg-accent-apple-subtle text-accent-apple' :
                'bg-subtle text-muted'
              }`}>
                {task.status.replace('-', ' ')}
              </span>
            </div>
            <div className="w-24 text-center">
              <span className={`flex items-center justify-center gap-1 text-micro font-mono capitalize ${
                task.priority === 'high' ? 'text-semantic-error' :
                task.priority === 'medium' ? 'text-semantic-warning' :
                'text-muted'
              }`}>
                {task.priority === 'high' && <ArrowRight size={12} className="-rotate-90" />}
                {task.priority === 'medium' && <ArrowRight size={12} />}
                {task.priority === 'low' && <ArrowRight size={12} className="rotate-90" />}
                {task.priority}
              </span>
            </div>
            <div className="w-24 flex justify-end">
              <div className="flex items-center gap-2">
                <span className="font-mono text-caption text-secondary">{task.assignee}</span>
                {task.assignee !== 'Unassigned' && (
                  <div className="w-6 h-6 rounded-full bg-elevated border border-border-default flex items-center justify-center text-[10px] font-mono">
                    {task.assignee}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}