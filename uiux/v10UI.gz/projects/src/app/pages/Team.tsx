import { useState } from "react";
import { Search, UserPlus, Mail, MoreHorizontal, Shield, Cpu } from "lucide-react";
import { cn } from "../utils";

const teamMembers = [
  {
    id: "1",
    name: "张伟",
    handle: "zhangwei",
    role: "后端工程师",
    email: "zhangwei@vibehub.dev",
    status: "online" as const,
    initials: "ZW",
    agents: 3,
    tasks: 7,
  },
  {
    id: "2",
    name: "李雨桐",
    handle: "liyutong",
    role: "产品设计师",
    email: "liyutong@vibehub.dev",
    status: "offline" as const,
    initials: "LY",
    agents: 1,
    tasks: 2,
  },
  {
    id: "3",
    name: "陈东",
    handle: "chendong",
    role: "前端工程师",
    email: "chendong@vibehub.dev",
    status: "online" as const,
    initials: "CD",
    agents: 2,
    tasks: 5,
  },
  {
    id: "4",
    name: "王浩宇",
    handle: "wanghy",
    role: "技术负责人",
    email: "wanghy@vibehub.dev",
    status: "busy" as const,
    initials: "WH",
    agents: 4,
    tasks: 12,
  },
  {
    id: "5",
    name: "刘晓丹",
    handle: "liuxd",
    role: "DevOps 工程师",
    email: "liuxd@vibehub.dev",
    status: "online" as const,
    initials: "LX",
    agents: 2,
    tasks: 4,
  },
  {
    id: "6",
    name: "赵明",
    handle: "zhaoming",
    role: "安全工程师",
    email: "zhaoming@vibehub.dev",
    status: "offline" as const,
    initials: "ZM",
    agents: 1,
    tasks: 1,
  },
];

const STATUS_LABELS: Record<string, string> = {
  online: "在线",
  offline: "离线",
  busy: "忙碌",
};

const STATUS_COLORS: Record<string, string> = {
  online: "bg-green-500",
  offline: "bg-vh-text-dark",
  busy: "bg-orange-500",
};

const ROLES = ["全部", "工程师", "设计师", "管理者", "运维"];

export function Team() {
  const [search, setSearch] = useState("");
  const [activeRole, setActiveRole] = useState("全部");

  const filtered = teamMembers.filter((m) => {
    const matchSearch =
      !search ||
      m.name.includes(search) ||
      m.handle.includes(search) ||
      m.email.includes(search);
    const matchRole =
      activeRole === "全部" ||
      (activeRole === "工程师" && m.role.includes("工程师")) ||
      (activeRole === "设计师" && m.role.includes("设计师")) ||
      (activeRole === "管理者" && m.role.includes("负责人")) ||
      (activeRole === "运维" && m.role.includes("DevOps"));
    return matchSearch && matchRole;
  });

  return (
    <div className="flex flex-col min-h-full bg-vh-bg">
      {/* Page Header */}
      <div className="px-6 pt-8 pb-0 border-b border-vh-border bg-vh-bg sticky top-0 z-20">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h1 className="text-vh-text" style={{ fontSize: 20, fontWeight: 700, letterSpacing: "-0.02em" }}>
              团队成员
            </h1>
            <p className="text-vh-text-muted mt-1" style={{ fontSize: 13 }}>
              管理 Workspace 成员及其 Agent 配额
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-vh-text-muted pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="搜索成员..."
                className="w-52 h-8 bg-vh-surface border border-vh-border rounded pl-9 pr-3 text-vh-text placeholder-vh-text-dark focus:outline-none focus:border-vh-border-strong focus:ring-1 focus:ring-vh-border-strong transition-all"
                style={{ fontSize: 13 }}
              />
            </div>
            <button
              className="flex items-center gap-2 px-3 h-8 rounded border border-vh-border bg-vh-surface text-vh-text hover:bg-vh-elevated transition-colors"
              style={{ fontSize: 13, fontWeight: 500 }}
            >
              <UserPlus className="w-3.5 h-3.5" />
              邀请成员
            </button>
          </div>
        </div>

        {/* Role Filter Tabs */}
        <div className="flex items-center gap-5 overflow-x-auto scrollbar-hide">
          {ROLES.map((role) => (
            <button
              key={role}
              onClick={() => setActiveRole(role)}
              className={cn(
                "py-3 whitespace-nowrap transition-colors relative focus-visible:outline-none",
                activeRole === role ? "text-vh-text" : "text-vh-text-muted hover:text-vh-text"
              )}
              style={{ fontSize: 13, fontWeight: 500 }}
            >
              {role}
              {activeRole === role && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-vh-signal rounded-t-full" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Strip */}
      <div className="flex items-center gap-6 px-6 py-3 border-b border-vh-border bg-vh-surface/60 overflow-x-auto scrollbar-hide">
        <div className="flex items-center gap-2">
          <span className="font-mono text-vh-text-dark" style={{ fontSize: 11 }}>总成员</span>
          <span className="font-mono text-vh-text" style={{ fontSize: 11, fontWeight: 600 }}>{teamMembers.length}</span>
        </div>
        <div className="w-px h-3 bg-vh-border" />
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
          <span className="font-mono text-vh-text-dark" style={{ fontSize: 11 }}>在线</span>
          <span className="font-mono text-vh-text" style={{ fontSize: 11, fontWeight: 600 }}>
            {teamMembers.filter((m) => m.status === "online").length}
          </span>
        </div>
        <div className="w-px h-3 bg-vh-border" />
        <div className="flex items-center gap-2">
          <Cpu className="w-3 h-3 text-purple-400" />
          <span className="font-mono text-vh-text-dark" style={{ fontSize: 11 }}>总 Agent</span>
          <span className="font-mono text-vh-text" style={{ fontSize: 11, fontWeight: 600 }}>
            {teamMembers.reduce((a, m) => a + m.agents, 0)}
          </span>
        </div>
        <div className="w-px h-3 bg-vh-border" />
        <div className="flex items-center gap-2">
          <Shield className="w-3 h-3 text-vh-text-dark" />
          <span className="font-mono text-vh-text-dark" style={{ fontSize: 11 }}>数据区域</span>
          <span className="font-mono text-vh-text-muted" style={{ fontSize: 11 }}>cn-east-1</span>
        </div>
      </div>

      {/* Member Grid */}
      <div className="flex-1 p-6">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center border border-dashed border-vh-border rounded-lg bg-vh-surface/20">
            <Search className="w-8 h-8 text-vh-text-dark mb-3" />
            <p className="text-vh-text font-medium" style={{ fontSize: 14 }}>
              未找到匹配成员
            </p>
            <p className="text-vh-text-muted mt-1" style={{ fontSize: 13 }}>
              尝试调整搜索词或角色筛选
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map((member) => (
              <div
                key={member.id}
                className="group flex flex-col p-5 rounded-lg border border-vh-border bg-vh-surface hover:bg-vh-elevated hover:border-vh-border-strong transition-all cursor-pointer"
              >
                {/* Avatar + Status */}
                <div className="flex items-start justify-between mb-4">
                  <div className="relative">
                    <div
                      className="w-10 h-10 rounded-md border border-vh-border-strong flex items-center justify-center text-vh-text shrink-0"
                      style={{ background: "#101014", fontSize: 13, fontWeight: 700, letterSpacing: "-0.01em" }}
                    >
                      {member.initials}
                    </div>
                    <div
                      className={cn(
                        "absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-vh-surface",
                        STATUS_COLORS[member.status]
                      )}
                    />
                  </div>
                  <button className="p-1 rounded text-vh-text-dark hover:text-vh-text hover:bg-vh-bg transition-colors opacity-0 group-hover:opacity-100">
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </div>

                {/* Name + Role */}
                <div className="flex flex-col gap-0.5 mb-4">
                  <span className="text-vh-text" style={{ fontSize: 14, fontWeight: 600 }}>
                    {member.name}
                  </span>
                  <span className="font-mono text-vh-text-muted" style={{ fontSize: 11 }}>
                    @{member.handle}
                  </span>
                  <span className="text-vh-text-dark mt-1" style={{ fontSize: 12 }}>
                    {member.role}
                  </span>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-3 mb-4 py-2.5 px-3 rounded border border-vh-border bg-vh-bg">
                  <div className="flex flex-col items-center flex-1">
                    <span className="font-mono text-vh-text" style={{ fontSize: 13, fontWeight: 600 }}>
                      {member.agents}
                    </span>
                    <span className="font-mono text-vh-text-dark" style={{ fontSize: 10 }}>Agents</span>
                  </div>
                  <div className="w-px h-6 bg-vh-border" />
                  <div className="flex flex-col items-center flex-1">
                    <span className="font-mono text-vh-text" style={{ fontSize: 13, fontWeight: 600 }}>
                      {member.tasks}
                    </span>
                    <span className="font-mono text-vh-text-dark" style={{ fontSize: 10 }}>任务</span>
                  </div>
                  <div className="w-px h-6 bg-vh-border" />
                  <div className="flex flex-col items-center flex-1">
                    <div className="flex items-center gap-1">
                      <span
                        className={cn("w-1.5 h-1.5 rounded-full", STATUS_COLORS[member.status])}
                      />
                    </div>
                    <span className="font-mono text-vh-text-dark" style={{ fontSize: 10 }}>
                      {STATUS_LABELS[member.status]}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 mt-auto">
                  <button className="flex items-center justify-center w-8 h-7 rounded border border-vh-border bg-vh-bg text-vh-text-muted hover:text-vh-text hover:border-vh-border-strong transition-colors">
                    <Mail className="w-3.5 h-3.5" />
                  </button>
                  <button
                    className="flex-1 h-7 rounded border border-vh-border bg-vh-bg text-vh-text-muted hover:text-vh-text hover:border-vh-border-strong transition-colors font-mono"
                    style={{ fontSize: 11 }}
                  >
                    查看主页
                  </button>
                </div>
              </div>
            ))}

            {/* Invite Slot */}
            <div className="flex flex-col items-center justify-center p-5 rounded-lg border border-dashed border-vh-border bg-vh-bg hover:bg-vh-surface/50 transition-colors cursor-pointer group min-h-[200px]">
              <UserPlus className="w-6 h-6 text-vh-text-dark group-hover:text-vh-text-muted mb-3 transition-colors" />
              <span className="text-vh-text-muted group-hover:text-vh-text transition-colors" style={{ fontSize: 13 }}>
                邀请新成员
              </span>
              <span className="font-mono text-vh-text-dark mt-1" style={{ fontSize: 11 }}>
                通过邮件或链接邀请
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
