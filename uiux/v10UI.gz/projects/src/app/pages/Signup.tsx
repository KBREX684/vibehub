import { useState } from "react";
import { Link } from "react-router";
import { Eye, EyeOff, ArrowRight } from "lucide-react";

export function Signup() {
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    nickname: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [agreed, setAgreed] = useState(false);

  const update = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center bg-vh-void px-4 py-12">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex items-center justify-center mb-6">
            <svg width="40" height="40" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2 14 L7 7 L12 18 L17 5 L22 14" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="text-vh-signal" />
              <circle cx="7" cy="7" r="2" className="fill-vh-signal" />
              <circle cx="17" cy="5" r="2" className="fill-vh-signal" />
              <path d="M24 11 L26 14 L24 17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-vh-signal/40" />
            </svg>
          </div>
          <h1 className="font-display text-2xl font-bold text-vh-text mb-2">创建 VibeHub 账号</h1>
          <p className="text-sm text-vh-text-muted">加入开发者与 Agent 的协作空间</p>
        </div>

        {/* Form */}
        <div className="space-y-5">
          {/* Nickname */}
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-vh-text-dim uppercase tracking-wider">昵称</label>
            <input
              type="text"
              value={form.nickname}
              onChange={(e) => update("nickname", e.target.value)}
              placeholder="你的名字"
              className="w-full h-10 px-3 rounded-md bg-vh-surface border border-vh-border text-vh-text text-sm placeholder:text-vh-text-dim focus:border-vh-signal/40 focus:shadow-[0_0_20px_rgba(205,213,227,0.08)] focus:outline-none transition-colors"
            />
          </div>

          {/* Email */}
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-vh-text-dim uppercase tracking-wider">邮箱</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              placeholder="you@example.com"
              className="w-full h-10 px-3 rounded-md bg-vh-surface border border-vh-border text-vh-text text-sm placeholder:text-vh-text-dim focus:border-vh-signal/40 focus:shadow-[0_0_20px_rgba(205,213,227,0.08)] focus:outline-none transition-colors"
            />
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-vh-text-dim uppercase tracking-wider">密码</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={form.password}
                onChange={(e) => update("password", e.target.value)}
                placeholder="至少 8 位字符"
                className="w-full h-10 px-3 pr-10 rounded-md bg-vh-surface border border-vh-border text-vh-text text-sm placeholder:text-vh-text-dim focus:border-vh-signal/40 focus:shadow-[0_0_20px_rgba(205,213,227,0.08)] focus:outline-none transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-vh-text-dim hover:text-vh-text transition-colors"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {/* Confirm Password */}
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-vh-text-dim uppercase tracking-wider">确认密码</label>
            <input
              type="password"
              value={form.confirmPassword}
              onChange={(e) => update("confirmPassword", e.target.value)}
              placeholder="再次输入密码"
              className="w-full h-10 px-3 rounded-md bg-vh-surface border border-vh-border text-vh-text text-sm placeholder:text-vh-text-dim focus:border-vh-signal/40 focus:shadow-[0_0_20px_rgba(205,213,227,0.08)] focus:outline-none transition-colors"
            />
          </div>

          {/* Agreement */}
          <label className="flex items-start gap-3 cursor-pointer group">
            <div
              className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${
                agreed
                  ? "bg-vh-signal border-vh-signal"
                  : "bg-vh-surface border-vh-border group-hover:border-vh-border-strong"
              }`}
              onClick={() => setAgreed(!agreed)}
            >
              {agreed && (
                <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
                  <path d="M2 6L5 9L10 3" stroke="#06060A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </div>
            <span className="text-xs text-vh-text-muted leading-relaxed">
              我已阅读并同意{" "}
              <Link to="#" className="text-vh-signal hover:underline">服务条款</Link>
              {" "}和{" "}
              <Link to="#" className="text-vh-signal hover:underline">隐私政策</Link>
            </span>
          </label>

          {/* Submit */}
          <button
            type="button"
            className="w-full h-11 rounded-md font-medium text-sm bg-vh-signal text-vh-void hover:bg-vh-accent-hover shadow-[0_0_24px_rgba(205,213,227,0.12)] hover:shadow-[0_0_36px_rgba(205,213,227,0.18)] transition-all flex items-center justify-center gap-2"
          >
            创建账号 <ArrowRight size={16} />
          </button>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4 my-8">
          <div className="flex-1 h-px bg-vh-border" />
          <span className="text-[11px] font-mono text-vh-text-dim uppercase tracking-wider">或</span>
          <div className="flex-1 h-px bg-vh-border" />
        </div>

        {/* Social login */}
        <div className="space-y-3">
          <button
            type="button"
            className="w-full h-10 rounded-md font-medium text-sm border border-vh-border bg-vh-surface text-vh-text hover:bg-vh-deep hover:border-vh-border-strong transition-colors flex items-center justify-center gap-2"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.164 6.839 9.489.5.092.682-.217.682-.482 0-.237-.009-.866-.013-1.7-2.782.604-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.831.092-.646.35-1.086.636-1.336-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.268 2.75 1.026A9.578 9.578 0 0112 6.836a9.59 9.59 0 012.504.337c1.909-1.294 2.747-1.026 2.747-1.026.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.161 22 16.418 22 12c0-5.523-4.477-10-10-10z" fill="currentColor" />
            </svg>
            通过 GitHub 注册
          </button>
        </div>

        {/* Footer link */}
        <p className="text-center text-sm text-vh-text-muted mt-8">
          已有账号？{" "}
          <Link to="/" className="text-vh-signal hover:underline font-medium">登录</Link>
        </p>
      </div>
    </div>
  );
}
