import React, { useState, useEffect, useRef } from "react";
import { Compass, Search, ChevronDown, SlidersHorizontal, Loader2, X, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "../utils";
import { ProjectCard, ProjectCardSkeleton } from "../components/ProjectCard";
import { mockProjects } from "../data";
import { useSearchParams } from "react-router";
import { 
  Drawer, 
  DrawerContent, 
  DrawerHeader, 
  DrawerTitle, 
  DrawerDescription,
  DrawerTrigger 
} from "../components/ui/drawer";

const PROJECT_TYPES = ["全部", "正在招募协作", "开源", "仅展示", "最新公开快照", "高推荐"];
const QUICK_TAGS = ["AI", "WebAssembly", "Rust", "Distributed", "WebRTC"];
const SORTS = ["最新发布", "最多关注", "最多协作", "高优推荐"];

export function Discover() {
  const [searchParams] = useSearchParams();
  const usePaginationParams = searchParams.get("pagination") === "1";
  
  const [searchQuery, setSearchQuery] = useState("");
  const [activeType, setActiveType] = useState("全部");
  const [activeSort, setActiveSort] = useState("最新发布");
  const [activeTags, setActiveTags] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isPaginating, setIsPaginating] = useState(false);
  const [page, setPage] = useState(1);
  const [showDropdown, setShowDropdown] = useState(false);
  
  const orbitRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Simulate initial load
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  const handleLoadMore = () => {
    setIsPaginating(true);
    setTimeout(() => {
      setPage(p => p + 1);
      setIsPaginating(false);
    }, 1000);
  };

  const toggleTag = (tag: string) => {
    setActiveTags(prev => 
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const handleClearAll = () => {
    setActiveType("全部");
    setActiveTags([]);
    setSearchQuery("");
  };

  const scrollOrbit = (direction: 'left' | 'right') => {
    if (orbitRef.current) {
      const scrollAmount = 340; // card width + gap
      orbitRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const filteredProjects = mockProjects.filter(p => {
    if (activeType !== "全部" && p.type !== activeType) return false;
    if (activeTags.length > 0 && !activeTags.some(t => p.tags.includes(t))) return false;
    if (searchQuery && !p.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const featuredProjects = mockProjects.filter(p => p.featured);

  const hasActiveFilters = activeType !== "全部" || activeTags.length > 0 || searchQuery.length > 0;

  return (
    <div className="flex flex-col min-h-full pb-24 relative isolate">
      {/* 1) Page Header */}
      <div className="sticky top-0 z-30 flex flex-col items-center w-full bg-vh-void border-b border-vh-border px-4 md:px-8 pt-8 pb-4 transition-all">
        <div className="w-full max-w-[1440px] mx-auto flex flex-col items-center">
          <div className="text-center mb-6">
            <h2 className="text-2xl md:text-3xl font-display font-bold tracking-[-0.02em] text-vh-text">Discover</h2>
            <p className="text-sm text-vh-text-muted mt-1.5 font-sans">
              探索全网前沿开发者项目与协作机会
            </p>
          </div>

          <div className="w-full max-w-[720px] relative group mb-6">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Search className="w-5 h-5 text-vh-text-dim group-focus-within:text-vh-signal transition-colors" />
            </div>
            {/* Signal waveform decoration */}
            <div className="absolute left-12 top-1/2 -translate-y-1/2 w-16 h-6 pointer-events-none opacity-0 group-focus-within:opacity-100 transition-opacity duration-500">
              <svg viewBox="0 0 64 24" className="w-full h-full" preserveAspectRatio="none">
                <path d="M0 12 Q8 4 16 12 Q24 20 32 12 Q40 4 48 12 Q56 20 64 12" stroke="var(--color-vh-signal)" strokeWidth="1.5" fill="none" opacity="0.4">
                  <animate attributeName="d" dur="3s" repeatCount="indefinite" values="M0 12 Q8 4 16 12 Q24 20 32 12 Q40 4 48 12 Q56 20 64 12;M0 12 Q8 20 16 12 Q24 4 32 12 Q40 20 48 12 Q56 4 64 12;M0 12 Q8 4 16 12 Q24 20 32 12 Q40 4 48 12 Q56 20 64 12" />
                </path>
              </svg>
            </div>
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索项目、标签、作者或技术栈 (按 ⌘K 定位)"
              className="w-full h-12 bg-vh-abyss border border-vh-border rounded-md pl-12 pr-12 text-[15px] text-vh-text placeholder-vh-text-dim focus:outline-none focus:border-vh-signal/40 focus:bg-vh-deep focus:shadow-[0_0_20px_rgba(205,213,227,0.06)] transition-all shadow-sm"
            />
            <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none">
              <kbd className="hidden sm:inline-flex h-6 items-center gap-1 rounded border border-vh-border bg-vh-void px-2 font-mono text-[11px] font-medium text-vh-text-dim">
                ⌘ K
              </kbd>
            </div>
          </div>

          {/* Desktop Filter Row */}
          <div className="hidden lg:flex w-full items-center justify-between gap-4">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-vh-text-dim mr-1 font-mono uppercase tracking-wider">Quick Tags</span>
              {QUICK_TAGS.map(tag => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={cn(
                    "px-2.5 py-1 rounded border text-xs font-mono transition-all focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal relative overflow-hidden",
                    activeTags.includes(tag) 
                      ? "bg-vh-signal-dim border-vh-signal/30 text-vh-signal" 
                      : "bg-vh-void border-vh-border text-vh-text-dim hover:border-vh-border-strong hover:text-vh-text"
                  )}
                >
                  {tag}
                  {activeTags.includes(tag) && <div className="absolute bottom-0 left-1/4 right-1/4 h-[2px] bg-vh-signal rounded-full" />}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <button 
                  onClick={() => setShowDropdown(!showDropdown)}
                  className="flex items-center gap-2 h-8 px-3 rounded border border-vh-border bg-vh-abyss text-sm text-vh-signal hover:bg-vh-deep transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal"
                >
                  {activeSort}
                  <ChevronDown className="w-4 h-4 text-vh-text-dim" />
                </button>
                {showDropdown && (
                  <div className="absolute right-0 top-full mt-1 w-40 rounded border border-vh-border bg-vh-surface py-1 shadow-xl z-50">
                    {SORTS.map(sort => (
                      <button
                        key={sort}
                        onClick={() => { setActiveSort(sort); setShowDropdown(false); }}
                        className="w-full text-left px-3 py-1.5 text-sm text-vh-text hover:bg-vh-elevated focus:bg-vh-elevated outline-none"
                      >
                        {sort}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-center p-0.5 rounded border border-vh-border bg-vh-void">
                {PROJECT_TYPES.map(type => (
                  <button
                    key={type}
                    onClick={() => setActiveType(type)}
                    className={cn(
                      "px-3 py-1 text-sm rounded-sm transition-all relative focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal",
                      activeType === type 
                        ? "bg-vh-deep text-vh-text border border-vh-border-strong shadow-sm" 
                        : "text-vh-text-dim hover:text-vh-text border border-transparent"
                    )}
                  >
                    {type}
                    {activeType === type && <div className="absolute bottom-0 left-2 right-2 h-[2px] bg-vh-signal rounded-full" />}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Mobile Filter Trigger */}
          <div className="lg:hidden flex w-full items-center justify-between gap-4">
            <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide flex-1 pr-4">
               {QUICK_TAGS.map(tag => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={cn(
                    "px-2 py-1 rounded border text-xs font-mono whitespace-nowrap transition-colors",
                    activeTags.includes(tag) 
                      ? "bg-vh-elevated border-vh-border-strong text-vh-text" 
                      : "bg-vh-bg border-vh-border text-vh-text-muted"
                  )}
                >
                  {tag}
                </button>
              ))}
            </div>
            
            <Drawer>
              <DrawerTrigger asChild>
                <button className="flex shrink-0 items-center gap-2 h-8 px-3 rounded border border-vh-border bg-vh-surface text-sm text-vh-accent">
                  <SlidersHorizontal className="w-4 h-4" />
                  筛选
                </button>
              </DrawerTrigger>
              <DrawerContent>
                <DrawerHeader>
                  <DrawerTitle>筛选与排序</DrawerTitle>
                  <DrawerDescription className="sr-only">项目发现页面的筛选和排序选项</DrawerDescription>
                </DrawerHeader>
                <div className="p-4 flex flex-col gap-6">
                  <div className="space-y-3">
                    <h4 className="text-xs font-mono text-vh-text-dark uppercase">排序依据</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {SORTS.map(sort => (
                        <button
                          key={sort}
                          onClick={() => setActiveSort(sort)}
                          className={cn(
                            "px-3 py-2 text-sm rounded border transition-colors text-left",
                            activeSort === sort 
                              ? "bg-vh-elevated border-vh-border-strong text-vh-text" 
                              : "bg-vh-bg border-vh-border text-vh-text-muted"
                          )}
                        >
                          {sort}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-3 pb-8">
                    <h4 className="text-xs font-mono text-vh-text-dark uppercase">项目类型</h4>
                    <div className="flex flex-col gap-2">
                       {PROJECT_TYPES.map(type => (
                        <button
                          key={type}
                          onClick={() => setActiveType(type)}
                          className={cn(
                            "px-3 py-2 text-sm rounded border transition-colors text-left flex justify-between items-center",
                            activeType === type 
                              ? "bg-vh-elevated border-vh-border-strong text-vh-text" 
                              : "bg-vh-bg border-vh-border text-vh-text-muted"
                          )}
                        >
                          {type}
                          {activeType === type && <div className="w-2 h-2 rounded-full bg-vh-accent" />}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </DrawerContent>
            </Drawer>
          </div>
        </div>
      </div>

      <div className="w-full max-w-[1440px] mx-auto px-4 md:px-8 mt-8 flex flex-col gap-12">
        
        {/* 2) Featured Gallery Orbit */}
        {!searchQuery && activeType === "全部" && activeTags.length === 0 && (
          <section className="relative w-full group/section">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-mono tracking-tight text-vh-text-muted flex items-center gap-2 uppercase">
                <div className="w-1.5 h-1.5 rounded-full bg-vh-signal vh-breathe" style={{ color: 'var(--color-vh-signal)' }} />
                Featured Orbit
              </h3>
            </div>
            
            <div className="relative group/orbit h-[200px] flex items-center rounded border border-vh-border bg-vh-abyss overflow-hidden">
              {/* Sticky fade masks */}
              <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-vh-abyss to-transparent z-10 pointer-events-none" />
              <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-vh-abyss to-transparent z-10 pointer-events-none" />
              
              {/* Hover Arrows */}
              <button 
                onClick={() => scrollOrbit('left')}
                className="absolute left-4 z-20 w-8 h-8 rounded-full bg-vh-surface border border-vh-border flex items-center justify-center text-vh-text-muted opacity-0 group-hover/orbit:opacity-100 transition-opacity hover:text-vh-text hover:bg-vh-elevated focus:opacity-100"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              
              <button 
                onClick={() => scrollOrbit('right')}
                className="absolute right-4 z-20 w-8 h-8 rounded-full bg-vh-surface border border-vh-border flex items-center justify-center text-vh-text-muted opacity-0 group-hover/orbit:opacity-100 transition-opacity hover:text-vh-text hover:bg-vh-elevated focus:opacity-100"
              >
                <ChevronRight className="w-4 h-4" />
              </button>

              <div 
                ref={orbitRef}
                className="w-full flex gap-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide py-5 px-6 focus:outline-none"
                tabIndex={-1}
              >
                {isLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="snap-start shrink-0">
                      <ProjectCardSkeleton featured />
                    </div>
                  ))
                ) : (
                  [...featuredProjects, ...mockProjects.slice(0, 4)].map((project, i) => (
                    <div key={`${project.id}-feat-${i}`} className="snap-start shrink-0">
                      <ProjectCard project={project} featured />
                    </div>
                  ))
                )}
              </div>
            </div>
          </section>
        )}

        {/* 3) Project Grid */}
        <section className="w-full">
          {hasActiveFilters && (
            <div className="mb-6 flex items-center justify-between">
              <span className="text-sm text-vh-text-muted font-mono">
                Found {filteredProjects.length} results
              </span>
              <button 
                onClick={handleClearAll}
                className="text-xs text-vh-text-dark hover:text-vh-text flex items-center gap-1 transition-colors"
              >
                <X className="w-3 h-3" /> 清除所有筛选
              </button>
            </div>
          )}

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <ProjectCardSkeleton key={i} />
              ))}
            </div>
          ) : filteredProjects.length === 0 ? (
            /* Empty State */
            <div className="flex flex-col items-center justify-center py-32 text-center rounded-lg border border-dashed border-vh-border bg-vh-surface/50">
              <div className="w-16 h-16 rounded-full bg-vh-surface border border-vh-border flex items-center justify-center mb-4">
                <Compass className="w-8 h-8 text-vh-border-strong" />
              </div>
              <h3 className="text-vh-text font-medium mb-2">这里暂时没有匹配的项目</h3>
              <p className="text-sm text-vh-text-muted max-w-sm mb-6">
                尝试调整您的筛选条件或减少搜索关键词，或者看看其他类型的项目。
              </p>
              <button 
                onClick={handleClearAll}
                className="px-4 py-2 rounded border border-vh-border text-sm text-vh-signal hover:bg-vh-signal-dim hover:text-vh-signal transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal"
              >
                清除所有筛选
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredProjects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
              {/* Duplicate mapping slightly to show pagination effect if page > 1 */}
              {page > 1 && filteredProjects.map((project) => (
                <ProjectCard key={`${project.id}-page2`} project={{...project, id: `${project.id}-p2`}} />
              ))}
            </div>
          )}

          {/* 4) Pagination */}
          {!isLoading && filteredProjects.length > 0 && (
             <div className="mt-16 flex justify-center">
               {usePaginationParams ? (
                 <div className="flex items-center gap-2">
                   {[1, 2, 3, 4, 5].map(p => (
                     <button 
                      key={p} 
                      className={cn(
                        "w-8 h-8 rounded border flex items-center justify-center text-sm transition-colors",
                        p === 1 ? "bg-vh-elevated border-vh-border-strong text-vh-text" : "bg-transparent border-transparent text-vh-text-muted hover:bg-vh-surface hover:text-vh-text"
                      )}
                     >
                       {p}
                     </button>
                   ))}
                 </div>
               ) : (
                 <button 
                  onClick={handleLoadMore}
                  disabled={isPaginating}
                  className="group flex items-center gap-2 px-6 py-2.5 rounded border border-vh-border bg-vh-void text-sm font-medium text-vh-text-muted hover:text-vh-text hover:border-vh-signal/30 hover:shadow-[0_0_15px_rgba(205,213,227,0.05)] hover:bg-vh-abyss transition-all disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal"
                >
                  {isPaginating ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <ChevronDown className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
                  )}
                  加载更多
                </button>
               )}
             </div>
          )}
        </section>
      </div>
    </div>
  );
}
