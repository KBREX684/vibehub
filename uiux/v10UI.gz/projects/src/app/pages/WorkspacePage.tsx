import { WorkspaceConsole } from "../components/vibehub/workspace-console";

export function WorkspacePage() {
  return <WorkspaceConsole />;
}
