import { useNavigate } from 'react-router';

export function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center h-full min-h-[400px] gap-4">
      <div className="text-center">
        <p className="mono" style={{ fontSize: 48, color: '#52525B', fontWeight: 500, lineHeight: 1 }}>
          404
        </p>
        <p style={{ fontSize: 16, color: '#71717A', marginTop: 12, fontWeight: 500 }}>
          页面未找到
        </p>
        <p style={{ fontSize: 13, color: '#52525B', marginTop: 4 }}>
          该路径不存在或已被移除
        </p>
      </div>
      <button
        onClick={() => navigate('/')}
        className="px-4 h-8 rounded-[6px] cursor-pointer"
        style={{
          background: '#17171C',
          border: '1px solid rgba(255,255,255,0.08)',
          fontSize: 13,
          color: '#A1A1AA',
          marginTop: 8,
        }}
      >
        返回概览
      </button>
    </div>
  );
}
