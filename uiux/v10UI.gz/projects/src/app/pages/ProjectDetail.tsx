import React, { useState } from "react";
import { useParams, Link } from "react-router";
import { ChevronRight, ExternalLink, Bookmark, Check, ShieldAlert, ShieldCheck, MapPin, Eye, GitPullRequest, Search, FileText } from "lucide-react";
import { cn } from "../utils";
import { mockProjects } from "../data";
import { ProjectCard } from "../components/ProjectCard";
import { IntentDrawer } from "../components/IntentDrawer";

export function ProjectDetail() {
  const { slug } = useParams();
  const [isIntentDrawerOpen, setIntentDrawerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"留言" | "纠错">("留言");
  const [commentText, setCommentText] = useState("");
  const [commentFilter, setCommentFilter] = useState<"全部" | "留言" | "纠错" | "仅未处理">("全部");

  const project = mockProjects.find((p) => p.id === slug) || mockProjects[0];

  // Dummy comments data
  const comments = [
    { id: 1, type: "纠错", author: "Liang", avatar: "L", body: "在 README 中关于分布式集群节点的选举算法描述似乎有误，建议核对 Paxos 相关的初始化步骤说明。", status: "open", time: "2026-04-18 10:12" },
    { id: 2, type: "留言", author: "System", avatar: "S", body: "看起来架构设计很棒！我想了解一下在高并发场景下内存溢出的处理策略是什么？", status: null, time: "2026-04-17 14:30" },
    { id: 3, type: "纠错", author: "Xiao", avatar: "X", body: "依赖库版本冲突：安装依赖时发现 `react-hook-form` 版本应该锁定在 7.55.0 否则会导致运行时报错。", status: "accepted", time: "2026-04-16 09:21" }
  ];

  const filteredComments = comments.filter(c => {
    if (commentFilter === "全部") return true;
    if (commentFilter === "留言") return c.type === "留言";
    if (commentFilter === "纠错") return c.type === "纠错";
    if (commentFilter === "仅未处理") return c.status === "open";
    return true;
  });

  const RightRail = ({ className }: { className?: string }) => (
    <aside className={cn("w-full xl:w-[320px] shrink-0 flex flex-col gap-6 pb-8 xl:pb-24", className)}>
      {/* Project At A Glance */}
      <div className="flex flex-col p-5 rounded-lg border border-vh-border bg-vh-surface">
         <h4 className="text-xs font-mono text-vh-text-dark uppercase mb-4">Project Metrics</h4>
         <div className="grid grid-cols-2 gap-y-4 gap-x-2">
           <div className="flex flex-col gap-1">
             <span className="text-2xl font-mono text-vh-text">{project.stats.stars}</span>
             <span className="text-[10px] font-mono text-vh-text-muted">收藏</span>
           </div>
           <div className="flex flex-col gap-1">
             <span className="text-2xl font-mono text-vh-text">12</span>
             <span className="text-[10px] font-mono text-vh-text-muted">协作意向数</span>
           </div>
           <div className="flex flex-col gap-1">
             <span className="text-2xl font-mono text-vh-text">3</span>
             <span className="text-[10px] font-mono text-vh-text-muted">快照数</span>
           </div>
           <div className="flex flex-col gap-1">
             <span className="text-lg font-mono text-vh-text mt-1">2h ago</span>
             <span className="text-[10px] font-mono text-vh-text-muted">最后活动</span>
           </div>
         </div>
      </div>

      {/* Author Card */}
      <div className="flex flex-col p-5 rounded-lg border border-vh-border bg-vh-surface gap-4">
         <div className="flex items-center gap-3">
           <div className="w-12 h-12 rounded-full bg-vh-elevated border border-vh-border flex items-center justify-center text-lg font-medium text-vh-text">
             {project.author.avatar}
           </div>
           <div className="flex flex-col">
             <span className="text-sm font-medium text-vh-text">{project.author.name}</span>
             <span className="text-xs text-vh-text-muted font-mono">@developer_x</span>
           </div>
         </div>
         <p className="text-xs text-vh-text-muted leading-relaxed">
           全栈开发者，开源爱好者。致力于构建高性能基础设施与���发者工具。
         </p>
         <button className="w-full py-1.5 rounded border border-vh-border bg-vh-bg text-xs font-medium text-vh-text hover:bg-vh-elevated transition-colors">
           View Profile
         </button>
      </div>

      {/* Related Projects */}
      <div className="flex flex-col gap-4 mt-2">
        <h4 className="text-xs font-mono text-vh-text-dark uppercase">Related Projects</h4>
        <div className="flex flex-col gap-3">
          {mockProjects.slice(1, 4).map(p => (
            <Link key={p.id} to={`/p/${p.id}`} className="group flex flex-col p-3 rounded border border-vh-border bg-vh-surface hover:bg-vh-elevated hover:border-vh-border-strong transition-all focus:outline-none focus-visible:ring-1 focus-visible:ring-vh-accent">
              <div className="flex justify-between items-start mb-1">
                <span className="text-sm font-medium text-vh-text group-hover:text-white truncate max-w-[200px]">{p.title}</span>
                {p.type === "正在招募协作" && <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5 shrink-0" />}
              </div>
              <span className="text-xs text-vh-text-muted font-mono">Stars: {p.stats.stars}</span>
            </Link>
          ))}
        </div>
      </div>
    </aside>
  );

  return (
    <div className="flex flex-col min-h-screen bg-vh-bg w-full isolate">
      {/* Top Breadcrumb Header */}
      <div className="sticky top-0 z-30 w-full border-b border-vh-border bg-vh-bg/80 backdrop-blur-md px-4 py-3 md:px-8">
        <div className="max-w-[1440px] mx-auto flex items-center text-xs font-mono text-vh-text-dark">
          <Link to="/discover" className="hover:text-vh-text transition-colors">Discover</Link>
          <ChevronRight className="w-3 h-3 mx-2" />
          <span className="text-vh-text-muted">项目</span>
          <ChevronRight className="w-3 h-3 mx-2" />
          <span className="text-vh-text">{project.title}</span>
        </div>
      </div>

      {/* Layout Container */}
      <div className="w-full max-w-[1440px] mx-auto px-4 md:px-8 py-8 flex flex-col xl:flex-row gap-8 relative">
        
        {/* MAIN COLUMN */}
        <main className="flex-1 w-full max-w-[720px] flex flex-col gap-12 shrink-0">
          
          {/* Section 1: Project info header */}
          <section className="flex flex-col gap-6">
            {/* Optional Cover Image */}
            <div className="w-full aspect-[16/9] rounded-xl bg-vh-surface border border-vh-border overflow-hidden relative group">
              <div className="absolute inset-0 bg-gradient-to-t from-vh-bg/80 to-transparent z-10" />
              <div className="absolute inset-0 flex items-center justify-center opacity-30 group-hover:opacity-50 transition-opacity">
                <FileText className="w-16 h-16 text-vh-text-dark" />
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <div className="flex items-start justify-between gap-4">
                <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-vh-text">
                  {project.title}
                </h1>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center rounded-sm bg-vh-surface border border-vh-border px-2 py-0.5 text-xs font-mono font-medium text-vh-text-muted">
                  <Eye className="w-3 h-3 mr-1" /> Public
                </span>
                <span className="inline-flex items-center rounded-sm bg-vh-surface border border-vh-border px-2 py-0.5 text-xs font-mono font-medium text-vh-text-muted">
                  <GitPullRequest className="w-3 h-3 mr-1" /> OSS
                </span>
                {project.type === "正在招募协作" ? (
                  <span className="inline-flex items-center rounded-sm bg-blue-900/30 border border-blue-900 px-2 py-0.5 text-xs font-mono font-medium text-blue-400">
                    开放协作
                  </span>
                ) : (
                  <span className="inline-flex items-center rounded-sm bg-vh-surface border border-vh-border px-2 py-0.5 text-xs font-mono font-medium text-vh-text-dark">
                    协作已满
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-sm text-vh-text-dark">
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-vh-elevated text-xs font-medium text-vh-text ring-1 ring-vh-border">
                    {project.author.avatar}
                  </div>
                  <span className="text-vh-text-muted">{project.author.name}</span>
                </div>
                <div className="w-1 h-1 rounded-full bg-vh-border-strong" />
                <span className="inline-flex items-center rounded bg-vh-elevated px-1.5 py-0.5 text-[10px] font-mono text-vh-text-muted">
                  MIT License
                </span>
                <div className="w-1 h-1 rounded-full bg-vh-border-strong" />
                <span className="font-mono text-xs">主体：个人开发者</span>
                <div className="w-1 h-1 rounded-full bg-vh-border-strong" />
                <span className="font-mono text-xs text-vh-text-muted">最近更新 2026-04-18</span>
              </div>

              <div className="flex flex-wrap items-center gap-3 mt-4">
                <button 
                  onClick={() => setIntentDrawerOpen(true)}
                  className="flex items-center justify-center px-6 py-2.5 rounded-md bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors shadow-[0_0_15px_rgba(37,99,235,0.2)]"
                >
                  发起协作意向
                </button>
                <button className="flex items-center justify-center px-6 py-2.5 rounded-md border border-vh-border bg-vh-bg text-vh-text-muted text-sm font-medium hover:bg-vh-elevated hover:text-vh-text transition-colors">
                  查看公开快照
                </button>
                <button className="flex items-center justify-center p-2.5 rounded-md border border-vh-border bg-vh-bg text-vh-text-muted hover:bg-vh-elevated hover:text-vh-text transition-colors focus:outline-none">
                  <Bookmark className="w-4 h-4" />
                </button>
              </div>
            </div>
          </section>

          {/* Section 2: Project Showcase */}
          <section className="flex flex-col gap-8 py-8 border-y border-vh-border">
            <div className="prose prose-invert prose-p:text-vh-text-muted prose-p:leading-[1.7] prose-p:text-[15px] prose-headings:text-vh-text max-w-none">
              <p>{project.description}</p>
              <p>本项目旨在探索前沿技术栈的组合应用。通过重构底层调度逻辑，极大地降低了冷启动延迟。我们在多个高压环境中进行了压力测试，性能表现优于同类开源方案约 30%。架构设计采用微内核模式，保证了极高的可扩展性。</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="aspect-[16/10] bg-vh-surface border border-vh-border rounded cursor-pointer hover:border-vh-border-strong transition-colors relative group">
                 <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-vh-bg/40 backdrop-blur-sm transition-all">
                    <Search className="w-5 h-5 text-vh-text" />
                 </div>
              </div>
              <div className="aspect-[16/10] bg-vh-surface border border-vh-border rounded cursor-pointer hover:border-vh-border-strong transition-colors relative group">
                 <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-vh-bg/40 backdrop-blur-sm transition-all">
                    <Search className="w-5 h-5 text-vh-text" />
                 </div>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <h3 className="text-sm font-mono text-vh-text-dark uppercase">关键特点</h3>
              <ul className="flex flex-col gap-3">
                {["动态资源调度算法实现", "基于 Rust 的核心组件重写", "零依赖的客户端 SDK 设计", "完整的 E2E 自动化测试覆盖"].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-vh-text-muted">
                    <Check className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex flex-col gap-4">
              <h3 className="text-sm font-mono text-vh-text-dark uppercase">最近更新</h3>
              <div className="flex flex-col gap-2">
                 <div className="flex items-center gap-4 text-sm">
                   <span className="font-mono text-vh-text-dark w-32 shrink-0">2026-04-18</span>
                   <span className="text-vh-text-muted truncate">发布 v1.2.0: 增加分布式锁机制</span>
                 </div>
                 <div className="flex items-center gap-4 text-sm">
                   <span className="font-mono text-vh-text-dark w-32 shrink-0">2026-04-15</span>
                   <span className="text-vh-text-muted truncate">合并 PR #42: 修复在高并发场景下的内存泄漏问题</span>
                 </div>
                 <div className="flex items-center gap-4 text-sm">
                   <span className="font-mono text-vh-text-dark w-32 shrink-0">2026-04-10</span>
                   <span className="text-vh-text-muted truncate">更新架构文档与部署指南</span>
                 </div>
              </div>
            </div>
          </section>

          {/* Section 3: Project Evaluation */}
          <section className="flex flex-col gap-6 py-4">
            <h3 className="text-sm font-mono text-vh-text-dark uppercase">项目评估指数</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex flex-col gap-5">
                {[
                  { label: "完整度", score: 4 },
                  { label: "可理解度", score: 3 },
                  { label: "协作意愿度", score: 5 },
                ].map(metric => (
                  <div key={metric.label} className="flex items-center justify-between gap-4">
                    <span className="text-sm text-vh-text-muted font-mono min-w-[80px]">{metric.label}</span>
                    <div className="flex-1 max-w-[200px] h-1 bg-vh-surface rounded-full overflow-hidden flex">
                      <div className="h-full bg-cyan-500/80 rounded-full" style={{ width: `${(metric.score / 5) * 100}%` }} />
                    </div>
                    <span className="text-xs font-mono text-vh-text-dark">{metric.score}.0</span>
                  </div>
                ))}
              </div>
              <div className="flex flex-col gap-2">
                <span className="text-xs text-vh-text-dark font-mono uppercase">Recommendation Signal (Weekly)</span>
                <div className="flex items-end gap-1 h-12 mt-2">
                  {[2, 4, 3, 5, 8, 6, 12, 15, 10, 18, 14, 20].map((val, i) => (
                    <div key={i} className="w-3 bg-vh-surface rounded-t-sm hover:bg-cyan-500/50 transition-colors" style={{ height: `${(val / 20) * 100}%` }} />
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Section 4: 留言 & 纠错 */}
          <section className="flex flex-col gap-6 pt-8">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-vh-text tracking-tight">反馈与探讨</h3>
            </div>
            
            {/* Compose Box */}
            <div className="flex flex-col rounded-md border border-vh-border bg-vh-surface overflow-hidden focus-within:border-vh-border-strong focus-within:ring-1 focus-within:ring-vh-border-strong transition-all">
              <div className="flex items-center gap-4 px-4 py-2 border-b border-vh-border bg-vh-bg/50">
                <button 
                  onClick={() => setActiveTab("留言")}
                  className={cn("text-sm font-medium transition-colors", activeTab === "留言" ? "text-vh-text" : "text-vh-text-dark hover:text-vh-text-muted")}
                >
                  写留言
                </button>
                <button 
                  onClick={() => setActiveTab("纠错")}
                  className={cn("text-sm font-medium transition-colors", activeTab === "纠错" ? "text-vh-text" : "text-vh-text-dark hover:text-vh-text-muted")}
                >
                  提交纠错
                </button>
              </div>
              <textarea 
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder={activeTab === "留言" ? "留下你对项目的看法或疑问..." : "指出文档或代码中存在的错误..."}
                className="w-full bg-transparent px-4 py-3 text-sm text-vh-text placeholder:text-vh-text-dark resize-none min-h-[100px] focus:outline-none"
                maxLength={1000}
              />
              <div className="flex items-center justify-between px-4 py-2 border-t border-vh-border bg-vh-bg/50">
                <span className="text-[11px] font-mono text-vh-text-dark">{commentText.length}/1000</span>
                <button className="px-4 py-1.5 rounded bg-vh-elevated text-xs font-medium text-vh-text hover:bg-vh-border transition-colors">
                  提交
                </button>
              </div>
            </div>

            {/* List Filter */}
            <div className="flex items-center gap-2 border-b border-vh-border pb-2 mt-4 overflow-x-auto scrollbar-hide">
              {["全部", "留言", "纠错", "仅未处理"].map(filter => (
                <button 
                  key={filter}
                  onClick={() => setCommentFilter(filter as any)}
                  className={cn(
                    "px-3 py-1 text-xs rounded-sm transition-all whitespace-nowrap focus-visible:outline-none",
                    commentFilter === filter 
                      ? "bg-vh-elevated text-vh-text border border-vh-border-strong" 
                      : "text-vh-text-muted hover:text-vh-text border border-transparent"
                  )}
                >
                  {filter}
                </button>
              ))}
            </div>

            {/* List */}
            <div className="flex flex-col rounded-md border border-vh-border bg-vh-bg">
              {filteredComments.map((comment, index) => (
                <div key={comment.id} className={cn(
                  "flex flex-col gap-3 p-4",
                  index !== filteredComments.length - 1 && "border-b border-vh-border"
                )}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-2">
                      <span className={cn(
                        "px-1.5 py-0.5 text-[10px] font-mono rounded-sm border",
                        comment.type === "纠错" ? "bg-orange-900/20 text-orange-400 border-orange-900/50" : "bg-vh-surface text-vh-text-muted border-vh-border"
                      )}>
                        {comment.type}
                      </span>
                      <div className="flex items-center gap-2 ml-1">
                        <div className="w-5 h-5 rounded-full bg-vh-elevated flex items-center justify-center text-[10px] text-vh-text font-medium border border-vh-border">
                          {comment.avatar}
                        </div>
                        <span className="text-xs text-vh-text-muted">{comment.author}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      {comment.type === "纠错" && (
                        <span className={cn(
                          "px-2 py-0.5 text-[10px] font-mono rounded-full",
                          comment.status === "open" && "bg-vh-surface text-vh-text-muted border border-vh-border",
                          comment.status === "accepted" && "bg-green-900/20 text-green-400 border border-green-900/50",
                          comment.status === "dismissed" && "bg-red-900/20 text-red-400 border border-red-900/50"
                        )}>
                          {comment.status === "open" ? "OPEN" : comment.status === "accepted" ? "ACCEPTED" : "DISMISSED"}
                        </span>
                      )}
                      <span className="text-[10px] font-mono text-vh-text-dark">{comment.time}</span>
                    </div>
                  </div>
                  <p className="text-sm text-vh-text-muted line-clamp-3 ml-1 leading-relaxed">
                    {comment.body}
                  </p>
                </div>
              ))}
              {filteredComments.length === 0 && (
                <div className="p-8 text-center text-sm text-vh-text-dark">
                  暂无匹配记录
                </div>
              )}
            </div>
          </section>

          {/* Right Rail inline for smaller screens (moves under section 4) */}
          <RightRail className="xl:hidden mt-8" />

          {/* Section 5: 协作意向区 */}
          <section className="flex flex-col gap-6 py-8 border-t-2 border-t-blue-500/50 mt-8" id="collab-intent">
            <div className="flex items-center justify-between">
               <h2 className="text-xl font-semibold tracking-tight text-vh-text">参与协作</h2>
               <span className="inline-flex items-center rounded-sm bg-blue-900/30 border border-blue-900 px-2 py-0.5 text-xs font-mono font-medium text-blue-400">
                  开放协作中
               </span>
            </div>
            
            <div className="flex flex-col gap-4 p-6 rounded-lg bg-vh-surface border border-vh-border">
              <div className="flex flex-col gap-2">
                <span className="text-xs font-mono text-vh-text-dark uppercase">Current Roles Demand</span>
                <div className="flex flex-wrap gap-2 mt-1">
                  {["前端工程师", "Rust 开发", "技术写作", "产品设计"].map(role => (
                    <span key={role} className="px-2 py-1 rounded bg-vh-bg border border-vh-border text-xs text-vh-text-muted">
                      需要：{role}
                    </span>
                  ))}
                </div>
              </div>
              <p className="text-sm text-vh-text-muted mt-2">
                当前项目正在积极寻找对底层架构与性能优化感兴趣的开发者。如果你有相关经验或强烈意愿，欢迎发起协作请求。我们将在一周内回复。
              </p>
              <button 
                onClick={() => setIntentDrawerOpen(true)}
                className="mt-4 w-full py-3 rounded-md bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors shadow-[0_0_15px_rgba(37,99,235,0.2)]"
              >
                发起协作意向
              </button>
            </div>
          </section>

          {/* Section 6: Authorized Viewers area */}
          <section className="flex flex-col gap-4 p-4 rounded border border-dashed border-vh-border-strong bg-vh-bg/50">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-4 h-4 text-green-500" />
              <span className="text-xs font-mono text-vh-text-muted">OWNER / MEMBER ACTIONS</span>
            </div>
            <div className="flex gap-3">
               <Link to={`/p/${slug}/snapshots`} className="flex-1 py-2 text-center rounded border border-vh-border bg-vh-surface text-xs text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated transition-colors">
                 查看公开快照配置
               </Link>
               <Link to={`/work/team/project-${slug}`} className="flex-1 py-2 text-center rounded border border-vh-border bg-vh-surface text-xs text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated transition-colors">
                 进入工作空间
               </Link>
            </div>
          </section>

        </main>

        {/* RIGHT RAIL for XL screens */}
        <RightRail className="hidden xl:flex xl:sticky xl:top-24 xl:h-fit" />

      </div>

      <IntentDrawer 
        isOpen={isIntentDrawerOpen} 
        onClose={() => setIntentDrawerOpen(false)} 
        projectName={project.title}
      />
    </div>
  );
}
