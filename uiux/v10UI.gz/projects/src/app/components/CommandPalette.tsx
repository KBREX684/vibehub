import { Search, FolderKanban, CheckSquare, Users, Settings, ArrowRight } from "lucide-react";
import { useEffect, useState, ElementType } from "react";

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CommandPalette({ isOpen, onClose }: CommandPaletteProps) {
  const [query, setQuery] = useState("");

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        isOpen ? onClose() : document.dispatchEvent(new CustomEvent("open-command"));
      }
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh]">
      <div 
        className="absolute inset-0 bg-canvas/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-2xl bg-surface border border-border-strong rounded-xl shadow-modal overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center px-4 border-b border-border-default">
          <Search size={18} className="text-muted" />
          <input
            autoFocus
            className="flex-1 bg-transparent border-none px-4 py-4 text-body-lg text-primary outline-none placeholder:text-muted font-sans"
            placeholder="Search commands, projects, or users..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <kbd className="font-mono text-micro text-muted bg-subtle px-2 py-1 rounded-md border border-border-default">
            ESC
          </kbd>
        </div>

        <div className="max-h-[300px] overflow-y-auto p-2">
          <div className="mb-2">
            <h3 className="text-micro font-mono text-muted px-3 py-2 uppercase tracking-wider">
              建议 (Suggestions)
            </h3>
            <div className="space-y-1">
              <CommandItem icon={FolderKanban} label="Go to Projects" shortcut="G P" />
              <CommandItem icon={CheckSquare} label="Create New Task" shortcut="C T" />
              <CommandItem icon={Users} label="View Team Directory" shortcut="G T" />
              <CommandItem icon={Settings} label="Open Settings" shortcut="⌘ ," />
            </div>
          </div>
        </div>

        <div className="bg-elevated border-t border-border-default p-3 flex items-center justify-between text-caption text-muted font-mono">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <kbd className="bg-surface border border-border-default rounded px-1">↑↓</kbd> to navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="bg-surface border border-border-default rounded px-1">↵</kbd> to select
            </span>
          </div>
          <span>VibeHub v10.0</span>
        </div>
      </div>
    </div>
  );
}

function CommandItem({ icon: Icon, label, shortcut }: { icon: ElementType, label: string, shortcut: string }) {
  return (
    <button className="w-full flex items-center justify-between px-3 py-2.5 rounded-md hover:bg-elevated text-secondary hover:text-primary transition-colors group">
      <div className="flex items-center gap-3">
        <Icon size={16} className="text-muted group-hover:text-primary transition-colors" />
        <span className="text-body-sm font-sans">{label}</span>
      </div>
      <kbd className="font-mono text-micro text-muted group-hover:text-secondary tracking-widest bg-subtle px-1.5 py-0.5 rounded-md">
        {shortcut}
      </kbd>
    </button>
  );
}