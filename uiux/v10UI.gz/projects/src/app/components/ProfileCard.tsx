import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Pencil, Check, X, Mail, User, AtSign } from "lucide-react";

interface ProfileData {
  nickname: string;
  email: string;
  username: string;
  avatarUrl: string;
  bio: string;
}

const MOCK_PROFILE: ProfileData = {
  nickname: "信号漂移者",
  email: "drifter@vibehub.dev",
  username: "signal_drifter",
  avatarUrl: "",
  bio: "在虚空中探索信号。",
};

interface ProfileCardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ProfileCard({ open, onOpenChange }: ProfileCardProps) {
  const [editing, setEditing] = useState(false);
  const [profile, setProfile] = useState<ProfileData>({ ...MOCK_PROFILE });
  const [draft, setDraft] = useState<ProfileData>({ ...MOCK_PROFILE });

  const handleEdit = () => {
    setDraft({ ...profile });
    setEditing(true);
  };

  const handleSave = () => {
    setProfile({ ...draft });
    setEditing(false);
  };

  const handleCancel = () => {
    setDraft({ ...profile });
    setEditing(false);
  };

  const updateDraft = (field: keyof ProfileData, value: string) => {
    setDraft((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-vh-deep border-vh-border text-vh-text sm:max-w-md p-0 overflow-hidden">
        {/* Banner area */}
        <div className="h-24 bg-gradient-to-b from-vh-signal-dim to-vh-deep relative">
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(ellipse_at_50%_0%,var(--color-vh-signal-glow),transparent_70%)]" />
        </div>

        <div className="px-6 pb-6 -mt-10 relative">
          {/* Avatar */}
          <div className="mb-4">
            <Avatar className="w-20 h-20 border-4 border-vh-deep ring-2 ring-vh-signal/20">
              <AvatarImage src={profile.avatarUrl} alt={profile.nickname} />
              <AvatarFallback className="bg-vh-signal text-vh-void font-display text-2xl font-bold">
                {profile.nickname.slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </div>

          {/* Header + Edit toggle */}
          <DialogHeader className="mb-5">
            <div className="flex items-center justify-between">
              <DialogTitle className="font-display text-lg tracking-tight text-vh-text">
                {editing ? "编辑个人资料" : "个人资料"}
              </DialogTitle>
              {editing ? (
                <div className="flex items-center gap-1.5">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCancel}
                    className="h-7 px-2.5 text-vh-text-muted hover:text-vh-text"
                  >
                    <X className="w-3.5 h-3.5 mr-1" />
                    取消
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleSave}
                    className="h-7 px-2.5 bg-vh-signal text-vh-void hover:bg-vh-accent-hover font-medium"
                  >
                    <Check className="w-3.5 h-3.5 mr-1" />
                    保存
                  </Button>
                </div>
              ) : (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleEdit}
                  className="h-7 px-2.5 text-vh-text-muted hover:text-vh-text"
                >
                  <Pencil className="w-3.5 h-3.5 mr-1" />
                  编辑
                </Button>
              )}
            </div>
          </DialogHeader>

          {/* Fields */}
          <div className="flex flex-col gap-4">
            {/* Nickname */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-vh-text-dim uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3 h-3" />
                昵称
              </label>
              {editing ? (
                <Input
                  value={draft.nickname}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    updateDraft("nickname", e.target.value)
                  }
                  className="h-8 bg-vh-surface border-vh-border text-vh-text text-sm focus-visible:border-vh-signal/40 focus-visible:ring-vh-signal/10"
                />
              ) : (
                <span className="text-sm text-vh-text pl-0.5">{profile.nickname}</span>
              )}
            </div>

            {/* Username */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-vh-text-dim uppercase tracking-wider flex items-center gap-1.5">
                <AtSign className="w-3 h-3" />
                用户名
              </label>
              {editing ? (
                <Input
                  value={draft.username}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    updateDraft("username", e.target.value)
                  }
                  className="h-8 bg-vh-surface border-vh-border text-vh-text text-sm font-mono focus-visible:border-vh-signal/40 focus-visible:ring-vh-signal/10"
                />
              ) : (
                <span className="text-sm text-vh-text-muted font-mono pl-0.5">
                  @{profile.username}
                </span>
              )}
            </div>

            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-vh-text-dim uppercase tracking-wider flex items-center gap-1.5">
                <Mail className="w-3 h-3" />
                邮箱
              </label>
              {editing ? (
                <Input
                  type="email"
                  value={draft.email}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    updateDraft("email", e.target.value)
                  }
                  className="h-8 bg-vh-surface border-vh-border text-vh-text text-sm focus-visible:border-vh-signal/40 focus-visible:ring-vh-signal/10"
                />
              ) : (
                <span className="text-sm text-vh-text-muted pl-0.5">{profile.email}</span>
              )}
            </div>

            {/* Bio */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-vh-text-dim uppercase tracking-wider flex items-center gap-1.5">
                Bio
              </label>
              {editing ? (
                <Input
                  value={draft.bio}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    updateDraft("bio", e.target.value)
                  }
                  className="h-8 bg-vh-surface border-vh-border text-vh-text text-sm focus-visible:border-vh-signal/40 focus-visible:ring-vh-signal/10"
                />
              ) : (
                <span className="text-sm text-vh-text-muted pl-0.5">{profile.bio}</span>
              )}
            </div>
          </div>

          {/* Footer signal line */}
          {!editing && (
            <div className="mt-6 pt-4 border-t border-vh-border">
              <p className="text-[10px] font-mono text-vh-text-dim uppercase tracking-widest">
                2024 年加入 · 专业版
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
