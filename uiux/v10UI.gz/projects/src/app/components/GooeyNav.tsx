import { useRef, useEffect, useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router';
import './GooeyNav.css';

interface GooeyNavItem {
  label: string;
  to: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface GooeyNavProps {
  items: GooeyNavItem[];
  initialActiveIndex?: number;
}

const GooeyNav: React.FC<GooeyNavProps> = ({
  items,
  initialActiveIndex = 0,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLUListElement>(null);
  const pillRef = useRef<HTMLSpanElement>(null);
  const [activeIndex, setActiveIndex] = useState(initialActiveIndex);
  const pillReady = useRef(false);
  // Track whether current route change was initiated by our click
  const isClickNavigation = useRef(false);
  const location = useLocation();
  const navigate = useNavigate();

  const movePill = useCallback((element: HTMLElement, animate: boolean) => {
    const pill = pillRef.current;
    const container = containerRef.current;
    if (!pill || !container) return;

    // Disable animation on first paint or when we want instant positioning
    if (!pillReady.current || !animate) {
      pill.style.transition = 'none';
    }

    const containerRect = container.getBoundingClientRect();
    const pos = element.getBoundingClientRect();

    pill.style.left = `${pos.x - containerRect.x}px`;
    pill.style.top = `${pos.y - containerRect.y}px`;
    pill.style.width = `${pos.width}px`;
    pill.style.height = `${pos.height}px`;

    if (!pillReady.current || !animate) {
      void pill.offsetWidth;
      pill.style.transition = '';
      pillReady.current = true;
    }
  }, []);

  // Route sync — only reposition pill for EXTERNAL navigations (browser back/forward, direct URL)
  useEffect(() => {
    const idx = items.findIndex((item) => {
      if (item.to === '/') return location.pathname === '/';
      return location.pathname.startsWith(item.to);
    });
    if (idx === -1) return;

    setActiveIndex(idx);

    // If this route change was initiated by our click handler,
    // the pill is already in the correct position — skip repositioning
    if (isClickNavigation.current) {
      isClickNavigation.current = false;
      return;
    }

    // External navigation (browser back/forward) — position pill
    requestAnimationFrame(() => {
      const activeLi = navRef.current?.querySelectorAll('li')[idx];
      if (activeLi) movePill(activeLi as HTMLElement, pillReady.current);
    });
  }, [location.pathname, items, movePill]);

  // ResizeObserver — instant (no animation) reposition on size changes
  useEffect(() => {
    if (!containerRef.current) return;

    let rafId: number;
    const resizeObserver = new ResizeObserver(() => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        const idx = items.findIndex((item) => {
          if (item.to === '/') return location.pathname === '/';
          return location.pathname.startsWith(item.to);
        });
        const currentActiveLi = navRef.current?.querySelectorAll('li')[idx];
        if (currentActiveLi) movePill(currentActiveLi as HTMLElement, false);
      });
    });

    resizeObserver.observe(containerRef.current);
    return () => {
      resizeObserver.disconnect();
      cancelAnimationFrame(rafId);
    };
  }, [items, location.pathname, movePill]);

  const handleClick = useCallback(
    (index: number, href: string) => {
      if (activeIndex === index) return;

      // Mark this as click-initiated so route useEffect skips pill repositioning
      isClickNavigation.current = true;
      setActiveIndex(index);
      pillReady.current = true;

      // Move pill with animation immediately
      const activeLi = navRef.current?.querySelectorAll('li')[index];
      if (activeLi) movePill(activeLi as HTMLElement, true);

      navigate(href);
    },
    [activeIndex, movePill, navigate],
  );

  return (
    <div className="gooey-nav-container" ref={containerRef}>
      <span className="gooey-pill" ref={pillRef} />
      <nav>
        <ul ref={navRef}>
          {items.map((item, index) => {
            const Icon = item.icon;
            const isActive = activeIndex === index;
            return (
              <li key={item.to} className={isActive ? 'active' : ''}>
                <button
                  type="button"
                  className="gooey-nav-item-btn"
                  onClick={() => handleClick(index, item.to)}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
};

export default GooeyNav;
