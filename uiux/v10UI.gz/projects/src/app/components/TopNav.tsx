import { useState } from "react";
import { User, Compass, LogOut, Settings, LayoutDashboard, Home } from "lucide-react";
import { Link } from "react-router";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import GooeyNav from "./GooeyNav";
import { ProfileCard } from "./ProfileCard";

const NAV_ITEMS = [
  { to: "/", label: "首页", icon: Home },
  { to: "/discover", label: "发现", icon: Compass },
  { to: "/work/personal", label: "工作台", icon: LayoutDashboard },
] as const;

export function TopNav() {
  const [profileOpen, setProfileOpen] = useState(false);

  return (
    <>
      <header className="h-14 border-b border-vh-border bg-vh-void/80 backdrop-blur-md flex items-center px-4 md:px-6 shrink-0 sticky top-0 z-50">
        {/* Left: Brand */}
        <div className="flex items-center shrink-0">
          <Link
            to="/"
            className="font-display font-bold tracking-tight text-vh-text flex items-center gap-2.5 focus:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal rounded px-1"
          >
            <div className="w-7 h-7 flex items-center justify-center">
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Signal pulse path — a V-shaped wave */}
                <path d="M2 14 L7 7 L12 18 L17 5 L22 14" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="text-vh-signal" />
                {/* Connected node dots */}
                <circle cx="7" cy="7" r="2" className="fill-vh-signal" />
                <circle cx="17" cy="5" r="2" className="fill-vh-signal" />
                {/* Signal echo line */}
                <path d="M24 11 L26 14 L24 17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-vh-signal/40" />
              </svg>
            </div>
            <span className="text-[15px]">VibeHub</span>
          </Link>
        </div>

        {/* Center: GooeyNav */}
        <div className="flex-1 flex items-center justify-center">
          <GooeyNav
            items={NAV_ITEMS.map(({ to, label, icon }) => ({ to, label, icon }))}
            initialActiveIndex={0}
          />
        </div>

        {/* Right: User avatar */}
        <div className="flex items-center shrink-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="w-8 h-8 rounded-full bg-vh-surface border border-vh-border flex items-center justify-center text-vh-text-muted hover:text-vh-text hover:border-vh-border-strong transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal">
                <User className="w-4 h-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-vh-void border-vh-border text-vh-text">
              <DropdownMenuLabel>我的账号</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-vh-border" />
              <DropdownMenuItem
                className="focus:bg-vh-surface focus:text-vh-text cursor-pointer"
                onSelect={() => setProfileOpen(true)}
              >
                <User className="w-4 h-4 mr-2" /> 个人资料
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="focus:bg-vh-surface focus:text-vh-text cursor-pointer">
                <Link to="/settings" className="flex items-center w-full">
                  <Settings className="w-4 h-4 mr-2" /> 设置
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-vh-border" />
              <DropdownMenuItem className="text-vh-red focus:bg-vh-surface focus:text-vh-red cursor-pointer">
                <LogOut className="w-4 h-4 mr-2" /> 退出登录
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* Profile Card Modal */}
      <ProfileCard open={profileOpen} onOpenChange={setProfileOpen} />
    </>
  );
}
