import React, { useState, useEffect } from "react";
import { X, CheckCircle } from "lucide-react";
import { cn } from "../utils";
import { Link } from "react-router";

interface IntentDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  projectName: string;
}

export function IntentDrawer({ isOpen, onClose, projectName }: IntentDrawerProps) {
  const [step, setStep] = useState<"form" | "success">("form");
  const [q1, setQ1] = useState("");
  const [q2, setQ2] = useState("");
  const [q3, setQ3] = useState("");
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setStep("form");
      setQ1("");
      setQ2("");
      setQ3("");
      setHasError(false);
    }
  }, [isOpen]);

  const handleSubmit = () => {
    if (q1.length > 250 || q2.length > 250 || q3.length > 250) {
      setHasError(true);
      return;
    }
    // Simulate submission
    setStep("success");
  };

  const renderTextarea = (
    label: string,
    placeholder: string,
    value: string,
    onChange: (val: string) => void
  ) => {
    const isOver = value.length > 250;
    
    // Basic detection for urls/emails (just simple heuristic to show inline warning)
    const hasContactInfo = /(https?:\/\/[^\s]+)|([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/i.test(value);

    return (
      <div className="flex flex-col gap-2">
        <label className="text-sm font-medium text-vh-text">{label}</label>
        <div className="relative">
          <textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            rows={3}
            className={cn(
              "w-full resize-none rounded-md border bg-vh-bg px-3 py-2 text-sm text-vh-text placeholder:text-vh-text-dark focus:outline-none focus:ring-1 transition-all",
              isOver ? "border-red-500/50 focus:border-red-500 focus:ring-red-500/50" : "border-vh-border focus:border-vh-border-strong focus:ring-vh-border-strong"
            )}
          />
          <div className="flex justify-between items-center mt-1">
            {hasContactInfo ? (
              <span className="text-[10px] text-red-400 font-sans">请勿包含外链或联系方式</span>
            ) : (
              <span />
            )}
            <span className={cn("text-xs font-mono", isOver ? "text-red-400" : "text-vh-text-dark")}>
              {value.length}/250
            </span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className={cn(
          "fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300",
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={onClose}
      />

      {/* Drawer */}
      <div
        className={cn(
          "fixed z-50 flex flex-col bg-vh-surface border-vh-border shadow-2xl transition-transform duration-300 ease-[cubic-bezier(0.32,0.72,0,1)]",
          // Mobile: Bottom sheet
          "inset-x-0 bottom-0 top-16 rounded-t-xl border-t lg:top-0 lg:bottom-0 lg:left-auto lg:right-0 lg:w-[480px] lg:rounded-none lg:border-l lg:border-t-0",
          isOpen ? "translate-y-0 lg:translate-x-0" : "translate-y-full lg:translate-x-full lg:translate-y-0"
        )}
      >
        <div className="flex items-center justify-between border-b border-vh-border px-6 py-4">
          <div className="flex flex-col">
            <h2 className="text-lg font-semibold text-vh-text">发起协作意向</h2>
            <span className="text-xs text-vh-text-muted font-mono">{projectName}</span>
          </div>
          <button 
            onClick={onClose}
            className="rounded p-1 text-vh-text-muted hover:bg-vh-elevated hover:text-vh-text transition-colors focus:outline-none"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {step === "form" ? (
            <div className="flex flex-col gap-6">
              {renderTextarea(
                "我是谁 / 我能做什么",
                "用一句话介绍你自己与你能贡献的能力",
                q1,
                setQ1
              )}
              {renderTextarea(
                "我为什么联系你",
                "说明你选择这个项目的理由",
                q2,
                setQ2
              )}
              {renderTextarea(
                "我希望怎样合作",
                "描述期望的协作形式与节奏",
                q3,
                setQ3
              )}
              {hasError && (
                <div className="p-3 rounded border border-red-500/20 bg-red-500/10 text-sm text-red-400">
                  请确保所有内容的长度不超过限制且未包含外链。
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-center h-full gap-4 mt-12">
              <CheckCircle className="w-12 h-12 text-blue-500" />
              <div className="flex flex-col gap-2">
                <p className="text-vh-text font-medium">已发送。对方可以接受、婉拒、忽略或拉黑并举报。</p>
                <p className="text-vh-text-muted text-sm">30 天未处理将自动过期。</p>
              </div>
              <div className="flex gap-3 mt-6">
                <Link
                  to="/work/intents?tab=sent"
                  onClick={onClose}
                  className="px-4 py-2 rounded-md bg-vh-elevated text-vh-text text-sm font-medium hover:bg-vh-border transition-colors border border-vh-border"
                >
                  查看我的发出记录
                </Link>
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-md bg-vh-bg text-vh-text-muted text-sm font-medium hover:text-vh-text border border-vh-border transition-colors"
                >
                  关闭
                </button>
              </div>
            </div>
          )}
        </div>

        {step === "form" && (
          <div className="border-t border-vh-border px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 bg-vh-bg/50">
            <span className="text-[11px] text-vh-text-dark">每句最长 250 字 · 不支持附件和外链</span>
            <div className="flex gap-3 w-full sm:w-auto">
              <button
                onClick={onClose}
                className="flex-1 sm:flex-none px-4 py-2 rounded-md border border-transparent text-vh-text-muted text-sm font-medium hover:bg-vh-elevated hover:text-vh-text transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleSubmit}
                className="flex-1 sm:flex-none px-4 py-2 rounded-md bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors shadow-[0_0_15px_rgba(37,99,235,0.2)]"
              >
                发起协作意向
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
