import { Search, Bell, ChevronRight, Slash } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface TopBarProps {
  onOpenCommand: () => void;
  breadcrumbs: string[];
}

export function TopBar({ onOpenCommand, breadcrumbs }: TopBarProps) {
  return (
    <header className="h-16 flex items-center justify-between px-6 border-b border-border-default bg-canvas sticky top-0 z-10">
      <div className="flex items-center gap-2 text-secondary text-body-sm font-sans">
        <span className="hover:text-primary cursor-pointer transition-colors">VibeHub</span>
        {breadcrumbs.map((crumb, i) => (
          <div key={i} className="flex items-center gap-2">
            <Slash size={14} className="text-muted" />
            <span className={i === breadcrumbs.length - 1 ? "text-primary font-medium" : "hover:text-primary cursor-pointer transition-colors"}>
              {crumb}
            </span>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <button 
          onClick={onOpenCommand}
          className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-border-default bg-surface hover:bg-surface-hover hover:border-border-strong transition-colors text-muted hover:text-secondary group"
        >
          <Search size={14} className="opacity-70 group-hover:opacity-100" />
          <span className="text-body-sm mx-4">搜索 (Search)</span>
          <kbd className="font-mono text-micro bg-subtle px-1.5 py-0.5 rounded-sm flex items-center gap-0.5">
            <span className="text-[10px]">⌘</span> K
          </kbd>
        </button>
        
        <button className="relative p-2 rounded-md hover:bg-subtle text-secondary hover:text-primary transition-colors">
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-pill bg-accent-violet border-2 border-canvas"></span>
        </button>

        <div className="w-8 h-8 rounded-full border border-border-strong bg-elevated flex items-center justify-center overflow-hidden cursor-pointer hover:border-accent-violet transition-colors">
          <ImageWithFallback 
            src="https://api.dicebear.com/7.x/notionists/svg?seed=geek" 
            alt="User avatar" 
            className="w-full h-full object-cover grayscale"
          />
        </div>
      </div>
    </header>
  );
}