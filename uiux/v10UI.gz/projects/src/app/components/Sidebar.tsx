import { NavLink } from "react-router";
import { 
  LayoutDashboard, 
  FolderKanban, 
  CheckSquare, 
  Users, 
  MessageSquare,
  Plus,
  Settings,
  Palette,
  LayoutPanelLeft,
} from "lucide-react";

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "仪表盘", en: "Dashboard" },
  { to: "/work", icon: LayoutPanelLeft, label: "工作台", en: "Workspace" },
  { to: "/projects", icon: FolderKanban, label: "项目", en: "Projects" },
  { to: "/tasks", icon: CheckSquare, label: "任务", en: "Tasks" },
  { to: "/team", icon: Users, label: "团队", en: "Team" },
  { to: "/discussions", icon: MessageSquare, label: "讨论", en: "Discussions" },
  { to: "/ui", icon: Palette, label: "组件库", en: "UI Library" },
];

export function Sidebar({ onOpenCreate }: { onOpenCreate: () => void }) {
  return (
    <aside className="w-64 h-screen border-r border-border-default bg-surface flex flex-col">
      <div className="h-16 flex items-center px-4 border-b border-border-default">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-accent-violet flex items-center justify-center text-on-accent font-mono text-caption">
            V
          </div>
          <span className="font-sans font-medium text-body-lg text-primary">VibeHub</span>
          <span className="bg-subtle text-muted text-micro px-1.5 py-0.5 rounded-sm font-mono ml-2">
            v10.0
          </span>
        </div>
      </div>

      <div className="p-4 flex-1 overflow-y-auto">
        <button 
          onClick={onOpenCreate}
          className="w-full flex items-center justify-between bg-elevated hover:bg-surface-hover border border-border-default rounded-md px-3 py-2 text-secondary hover:text-primary transition-colors mb-6 shadow-card group"
        >
          <div className="flex items-center gap-2">
            <Plus size={16} className="text-muted group-hover:text-primary transition-colors" />
            <span className="text-body-sm">新建 (Create)</span>
          </div>
          <kbd className="font-mono text-micro text-muted bg-subtle px-1.5 py-0.5 rounded-sm">C</kbd>
        </button>

        <nav className="space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                  isActive 
                    ? "bg-subtle text-primary" 
                    : "text-secondary hover:text-primary hover:bg-subtle"
                }`
              }
            >
              <item.icon size={16} className="opacity-70" />
              <div className="flex flex-col">
                <span className="text-body-sm leading-tight">{item.label}</span>
              </div>
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-border-default">
        <button className="flex items-center gap-3 px-3 py-2 w-full rounded-md text-secondary hover:text-primary hover:bg-subtle transition-colors">
          <Settings size={16} className="opacity-70" />
          <span className="text-body-sm">设置 (Settings)</span>
        </button>
      </div>
    </aside>
  );
}