import React, { useState } from "react";
import { cn } from "../../utils";
import { X, FileText, CheckCircle2, ChevronRight, Activity, AlertCircle, RefreshCw } from "lucide-react";
import { TaskData } from "./TaskCard";

export function TaskDrawer({ isOpen, onClose, task }: { isOpen: boolean, onClose: () => void, task: TaskData }) {
  const [activeTab, setActiveTab] = useState("输出结果");

  return (
    <>
      <div 
        className={cn(
          "fixed inset-0 z-50 bg-black/60 backdrop-blur-sm transition-opacity",
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={onClose}
      />

      <div
        className={cn(
          "fixed z-[60] flex flex-col bg-vh-surface border-l border-vh-border shadow-2xl transition-transform duration-300 ease-[cubic-bezier(0.32,0.72,0,1)] inset-y-0 right-0 w-full sm:w-[480px]",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        <div className="flex items-center justify-between border-b border-vh-border px-6 py-4 bg-vh-bg">
          <div className="flex flex-col">
            <h2 className="text-sm font-mono font-medium text-vh-text truncate max-w-[300px]">{task.verb}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[10px] font-mono text-vh-text-dark bg-vh-elevated px-1.5 py-0.5 rounded border border-vh-border">
                {task.agent}
              </span>
              <span className="text-[10px] font-mono text-vh-text-muted">
                {task.state.toUpperCase()}
              </span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="rounded p-1 text-vh-text-muted hover:bg-vh-elevated hover:text-vh-text transition-colors focus:outline-none"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center gap-4 px-6 border-b border-vh-border bg-vh-bg overflow-x-auto scrollbar-hide shrink-0">
          {["输入上下文", "执行过程", "输出结果", "审计记录", "确认"].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "py-3 text-sm font-medium whitespace-nowrap transition-colors relative focus-visible:outline-none focus-visible:text-vh-text",
                activeTab === tab ? "text-vh-text" : "text-vh-text-muted hover:text-vh-text"
              )}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-t-full" />
              )}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6 bg-vh-bg font-mono text-sm leading-relaxed text-vh-text-muted">
          {activeTab === "输入上下文" && (
            <div className="flex flex-col gap-4">
              <div className="p-3 rounded border border-vh-border bg-vh-surface">
                <span className="text-xs text-vh-text-dark block mb-2">// User Prompt</span>
                <p>请根据已有的 `UserController` 接口代码，自动生成配套的 OpenAPI (Swagger) 文档定义，要求包含完整的入参类型、返回值及 400/500 错误码描述。</p>
              </div>
              <div className="p-3 rounded border border-vh-border bg-vh-surface">
                <span className="text-xs text-vh-text-dark block mb-2">// Source Files Provided</span>
                <ul className="list-disc pl-4 text-vh-text flex flex-col gap-1 text-xs">
                  <li>src/controllers/UserController.ts</li>
                  <li>src/types/user.d.ts</li>
                </ul>
              </div>
            </div>
          )}
          {activeTab === "执行过程" && (
            <div className="flex flex-col gap-3">
              <div className="flex gap-3">
                <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                <span>分析 UserController.ts AST 语法树... [OK 120ms]</span>
              </div>
              <div className="flex gap-3">
                <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                <span>提取接口路由、HTTP Method、请求参数结构... [OK 350ms]</span>
              </div>
              <div className="flex gap-3">
                <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                <span>解析 user.d.ts 以补全模型定义... [OK 210ms]</span>
              </div>
              <div className="flex gap-3">
                <RefreshCw className="w-4 h-4 text-blue-500 shrink-0 mt-0.5 animate-spin" />
                <span>生成 YAML 格式文档...</span>
              </div>
            </div>
          )}
          {activeTab === "输出结果" && (
            <div className="flex flex-col gap-4 h-full">
              <div className="flex items-center justify-between">
                <span className="text-xs text-vh-text-dark">Generated: openapi.yaml</span>
                <button className="text-xs text-vh-accent hover:underline">Copy Code</button>
              </div>
              <div className="flex-1 bg-vh-surface border border-vh-border rounded p-4 overflow-auto">
                <pre className="text-xs text-vh-text">
{`openapi: 3.0.0
info:
  title: User API
  version: 1.0.0
paths:
  /api/users/{id}:
    get:
      summary: 获取用户详情
      parameters:
        - name: id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/User'
        '404':
          description: Not Found`}
                </pre>
              </div>
            </div>
          )}
          {activeTab === "审计记录" && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3 text-xs">
                <span className="w-32 text-vh-text-dark">2026-04-18 14:02:11</span>
                <span className="text-vh-text">Task created by system trigger</span>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="w-32 text-vh-text-dark">2026-04-18 14:02:12</span>
                <span className="text-vh-text">Assigned to Agent [DocsBot-v2]</span>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="w-32 text-vh-text-dark">2026-04-18 14:02:15</span>
                <span className="text-blue-400">Execution completed. Pending confirmation.</span>
              </div>
            </div>
          )}
          {activeTab === "确认" && (
            <div className="flex flex-col gap-4 items-center justify-center h-full text-center">
              <Activity className="w-12 h-12 text-vh-border-strong mb-2" />
              <p className="text-vh-text font-sans">请审阅输出结果并确认采纳。</p>
              <p className="text-xs text-vh-text-muted font-sans max-w-[280px]">一旦确认，生成的文档将自动合并到目标分支中，并触发构建流水线。</p>
            </div>
          )}
        </div>

        {/* Action Row */}
        <div className="p-4 border-t border-vh-border bg-vh-surface flex gap-3 shrink-0">
          <button className="flex-1 py-2.5 rounded border border-vh-border bg-vh-bg text-sm font-medium text-vh-text-muted hover:text-red-400 hover:border-red-900/50 hover:bg-red-900/10 transition-colors">
            驳回
          </button>
          <button className="flex-1 py-2.5 rounded border border-vh-border bg-vh-bg text-sm font-medium text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated transition-colors">
            补充指令
          </button>
          <button className="flex-1 py-2.5 rounded bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors shadow-[0_0_15px_rgba(37,99,235,0.2)]">
            确认采纳
          </button>
        </div>
      </div>
    </>
  );
}
