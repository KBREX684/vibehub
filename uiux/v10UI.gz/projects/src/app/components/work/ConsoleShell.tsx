import React, { useState } from "react";
import { cn } from "../../utils";
import { Menu, X, Terminal, Cpu, Users, Library, Inbox, Bell, Settings as SettingsIcon } from "lucide-react";
import { Link, useLocation } from "react-router";

export interface ConsoleShellProps {
  children: React.ReactNode;
  rightRail?: React.ReactNode;
  isTeam?: boolean;
  mobileBannerText?: string;
}

export function ConsoleShell({ children, rightRail, isTeam, mobileBannerText }: ConsoleShellProps) {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const location = useLocation();

  const NavItem = ({ icon: Icon, label, path, isActive }: { icon: any, label: string, path: string, isActive?: boolean }) => {
    const active = isActive !== undefined ? isActive : location.pathname.startsWith(path);
    return (
      <Link
        to={path}
        className={cn(
          "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal relative box-border",
          active 
            ? "bg-vh-signal-dim text-vh-signal border border-vh-signal/20" 
            : "text-vh-text-muted hover:text-vh-text hover:bg-vh-deep border border-transparent"
        )}
      >
        <Icon className="w-4 h-4 shrink-0" />
        <span>{label}</span>
        {active && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[2px] h-4 bg-vh-signal rounded-full" />}
      </Link>
    );
  };

  const renderNav = () => (
    <nav className="flex flex-col gap-1 p-3 h-full">
      {/* System Status Indicator */}
      <div className="px-3 py-2 mb-2 mt-2 flex items-center gap-2">
        <div className="w-1.5 h-1.5 rounded-full bg-vh-signal vh-breathe" style={{ color: 'var(--color-vh-signal)' }} />
        <span className="text-[10px] font-mono text-vh-signal/60 uppercase tracking-widest">系统正常</span>
      </div>

      <div className="text-[10px] font-mono text-vh-text-dim uppercase tracking-wider px-3 mb-2 mt-4">工作空间</div>
      <NavItem icon={Terminal} label="个人空间" path="/work/personal" isActive={location.pathname === "/work/personal"} />
      <NavItem icon={Users} label="团队实验室" path="/work/team/labs" isActive={location.pathname.startsWith("/work/team")} />
      
      <div className="text-[10px] font-mono text-vh-text-dim uppercase tracking-wider px-3 mb-2 mt-6">管理中心</div>
      <NavItem icon={Library} label="项目库" path="/work/library" />
      <NavItem icon={Inbox} label="协作意向" path="/work/intents" />
      <NavItem icon={Cpu} label="Agent 任务" path="/work/agent-tasks" />
      <NavItem icon={Bell} label="通知中心" path="/work/notifications" />
      
      <div className="text-[10px] font-mono text-vh-text-dim uppercase tracking-wider px-3 mb-2 mt-6">系统</div>
      <NavItem icon={SettingsIcon} label="设置" path="/settings" />
    </nav>
  );

  return (
    <div className="flex flex-1 relative h-[calc(100vh-56px)] overflow-hidden bg-vh-void w-full">
      {/* Mobile Banner (<768px) */}
      <div className="md:hidden flex-1 flex flex-col items-center justify-center p-6 text-center bg-vh-void w-full h-full absolute inset-0 z-50">
        <Terminal className="w-12 h-12 text-vh-text-dim mb-4" />
        <p className="text-vh-text font-medium text-lg leading-relaxed">
          {mobileBannerText ?? (isTeam ? "Workspace 协作建议在桌面端完成。" : "建议在桌面端使用 Workspace Console")}
        </p>
        <p className="text-sm text-vh-text-muted mt-2">
          你可以查看最近活动与通知。
        </p>
      </div>

      {/* Desktop/Tablet Layout (>=768px) */}
      <div className="hidden md:flex flex-1 relative h-full w-full overflow-hidden">
        
        {/* Left Rail (>=1024px) */}
        <aside className="hidden lg:flex flex-col w-[240px] h-full border-r border-vh-border bg-vh-abyss shrink-0 z-10 overflow-y-auto" style={{ scrollbarGutter: 'stable' }}>
          {renderNav()}
        </aside>

        {/* Left Rail Drawer (768px - 1023px) */}
        <div className="lg:hidden flex flex-col absolute top-3 left-3 z-40">
          <button 
            onClick={() => setIsDrawerOpen(true)}
            className="p-2 rounded-md bg-vh-abyss border border-vh-border text-vh-text-muted hover:text-vh-text hover:border-vh-signal/30 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal transition-all shadow-sm"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>

        {/* Overlay for Drawer */}
        {isDrawerOpen && (
          <div 
            className="lg:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-sm transition-opacity"
            onClick={() => setIsDrawerOpen(false)}
          />
        )}

        {/* Drawer itself */}
        <aside 
          className={cn(
            "lg:hidden fixed inset-y-0 left-0 z-50 w-[240px] bg-vh-abyss border-r border-vh-border transform transition-transform duration-300 flex flex-col shadow-2xl",
            isDrawerOpen ? "translate-x-0" : "-translate-x-full"
          )}
      >
          <div className="flex items-center justify-between p-4 border-b border-vh-border">
            <span className="text-sm font-mono font-bold text-vh-text">导航</span>
            <button 
              onClick={() => setIsDrawerOpen(false)}
              className="p-1.5 rounded-md text-vh-text-muted hover:bg-vh-deep hover:text-vh-text transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto" style={{ scrollbarGutter: 'stable' }}>
            {renderNav()}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0 flex flex-col h-full overflow-hidden relative isolate bg-vh-void">
          {children}
        </main>

        {/* Right Rail */}
        {rightRail && (
          <aside className="hidden lg:flex flex-col border-l border-vh-border bg-vh-abyss shrink-0 xl:w-[320px] w-[48px] overflow-hidden transition-all duration-300">
            {/* Collapsed view */}
            <div className="xl:hidden flex flex-col items-center py-4 w-full h-full gap-4">
              <button className="p-2 rounded-md text-vh-text-muted hover:bg-vh-deep hover:text-vh-text tooltip-trigger relative group focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal">
                <Cpu className="w-5 h-5" />
                <div className="absolute right-full mr-2 px-2 py-1 bg-vh-deep border border-vh-border rounded text-[10px] font-mono text-vh-text whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none z-50">
                  Agent Console
                </div>
              </button>
            </div>
            
            {/* Expanded view */}
            <div className="hidden xl:flex flex-col w-full h-full overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b border-vh-border shrink-0">
                <span className="text-xs font-mono text-vh-text-dim uppercase tracking-wider">Agent Console</span>
                <Cpu className="w-4 h-4 text-vh-text-dim" />
              </div>
              <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
                {rightRail}
              </div>
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}
