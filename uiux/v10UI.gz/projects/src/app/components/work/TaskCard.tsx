import React, { useState } from "react";
import { cn } from "../../utils";
import { Bot, User, Check, X, FileText, ChevronRight, CheckCircle2, XCircle, Clock, AlertCircle } from "lucide-react";
import { TaskDrawer } from "./TaskDrawer";

export interface TaskData {
  id: string;
  verb: string;
  state: "in-progress" | "pending" | "completed" | "failed";
  agent: string;
  preview: string;
  actorType: "user" | "agent";
  actorAvatar: string;
}

export function TaskCard({ task }: { task: TaskData }) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const stateConfig = {
    "in-progress": { label: "IN PROGRESS", color: "text-vh-blue bg-vh-blue-dim border-vh-blue/20", icon: Clock },
    "pending": { label: "PENDING CONFIRM", color: "text-vh-orange bg-vh-orange-dim border-vh-orange/20", icon: AlertCircle },
    "completed": { label: "COMPLETED", color: "text-vh-signal bg-vh-signal-dim border-vh-signal/20", icon: CheckCircle2 },
    "failed": { label: "FAILED", color: "text-vh-red bg-vh-red-dim border-vh-red/20", icon: XCircle }
  };

  const config = stateConfig[task.state];
  const Icon = config.icon;

  return (
    <>
      <div 
        onClick={() => setDrawerOpen(true)}
        className="group flex flex-col p-3 rounded-lg border border-vh-border bg-vh-surface hover:bg-vh-elevated hover:border-vh-signal/20 hover:shadow-[0_0_15px_rgba(205,213,227,0.04)] transition-all cursor-pointer shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal vh-card-glow"
        tabIndex={0}
      >
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className={cn(
              "w-6 h-6 flex items-center justify-center rounded border text-xs font-medium",
              task.actorType === "agent" ? "bg-vh-violet-dim text-vh-violet border-vh-violet/20" : "bg-vh-deep text-vh-text border-vh-border"
            )}>
              {task.actorType === "agent" ? <Bot className="w-3.5 h-3.5" /> : task.actorAvatar}
            </div>
            <span className={cn("px-1.5 py-0.5 text-[10px] font-mono rounded-sm border", config.color)}>
              <div className="flex items-center gap-1">
                {config.label}
              </div>
            </span>
          </div>
          <span className="flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-mono rounded-sm border border-vh-border bg-vh-void text-vh-text-dim">
            <Bot className="w-3 h-3" />
            {task.agent}
          </span>
        </div>

        <p className="text-sm text-vh-text font-mono mb-2 line-clamp-2 leading-relaxed">
          {task.verb}
        </p>

        <div className="flex items-center gap-2 p-2 rounded bg-vh-void border border-vh-border mb-3">
          <FileText className="w-3.5 h-3.5 text-vh-text-dim shrink-0" />
          <span className="text-[11px] text-vh-text-muted line-clamp-1 font-mono">{task.preview}</span>
        </div>

        <div className="flex items-center justify-end gap-2 mt-auto pt-2 border-t border-vh-border">
          {task.state === "pending" ? (
            <div className="flex gap-2 w-full">
              <button className="flex-1 py-1.5 flex justify-center items-center gap-1 rounded bg-vh-surface border border-vh-border text-xs text-vh-text-muted hover:text-vh-red hover:border-vh-red/30 transition-colors">
                <X className="w-3.5 h-3.5" /> 驳回
              </button>
              <button className="flex-1 py-1.5 flex justify-center items-center gap-1 rounded bg-vh-signal text-vh-void text-xs font-medium hover:bg-vh-accent-hover transition-colors shadow-[0_0_12px_rgba(205,213,227,0.15)]">
                <Check className="w-3.5 h-3.5" /> 确认
              </button>
            </div>
          ) : (
            <button className="flex items-center gap-1 text-[11px] font-mono text-vh-text-dim hover:text-vh-text transition-colors">
              查看详情 <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
      <TaskDrawer isOpen={drawerOpen} onClose={() => setDrawerOpen(false)} task={task} />
    </>
  );
}
