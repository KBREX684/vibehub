import React, { useState } from "react";
import { cn } from "../../utils";
import { X, Shield, Activity, GitCommit, FileText } from "lucide-react";

export function EventDrawer({ isOpen, onClose, event }: { isOpen: boolean, onClose: () => void, event: any }) {
  if (!event) return null;

  return (
    <>
      <div 
        className={cn(
          "fixed inset-0 z-50 bg-black/60 backdrop-blur-sm transition-opacity",
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={onClose}
      />

      <div
        className={cn(
          "fixed z-[60] flex flex-col bg-vh-surface border-l border-vh-border shadow-2xl transition-transform duration-300 ease-[cubic-bezier(0.32,0.72,0,1)] inset-y-0 right-0 w-full sm:w-[480px]",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        <div className="flex items-center justify-between border-b border-vh-border px-6 py-4 bg-vh-bg">
          <div className="flex flex-col">
            <h2 className="text-sm font-mono font-medium text-vh-text truncate max-w-[300px]">{event.kind} Details</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[10px] font-mono text-vh-text-dark bg-vh-elevated px-1.5 py-0.5 rounded border border-vh-border">
                {event.id}
              </span>
              <span className="text-[10px] font-mono text-vh-text-muted">
                {event.time}
              </span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="rounded p-1 text-vh-text-muted hover:bg-vh-elevated hover:text-vh-text transition-colors focus:outline-none"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 bg-vh-bg font-mono text-sm leading-relaxed text-vh-text-muted">
          <div className="flex flex-col gap-6">
            <div className="flex items-center justify-between p-4 rounded border border-vh-border bg-vh-surface shadow-sm">
               <div className="flex items-center gap-3">
                 <div className="w-8 h-8 rounded border border-vh-border-strong flex items-center justify-center bg-vh-bg text-vh-text font-medium text-xs">
                   {event.avatar}
                 </div>
                 <div className="flex flex-col">
                   <span className="text-vh-text font-bold text-sm">{event.actor}</span>
                   <span className="text-xs text-vh-text-dark">{event.verb} {event.target}</span>
                 </div>
               </div>
               <span className={cn(
                  "px-2 py-0.5 text-[10px] font-mono rounded-full border shrink-0",
                  event.status === "SUCCESS" && "bg-green-900/20 text-green-400 border-green-900/50",
                  event.status === "PENDING" && "bg-orange-900/20 text-orange-400 border-orange-900/50",
                  event.status === "APPROVED" && "bg-blue-900/20 text-blue-400 border-blue-900/50",
                  event.status === "LOCKED" && "bg-vh-surface text-vh-text-muted border-vh-border",
                  event.status === "OPEN" && "bg-vh-bg text-vh-text-muted border-vh-border",
                  event.status === "ACKNOWLEDGED" && "bg-purple-900/20 text-purple-400 border-purple-900/50"
                )}>
                  {event.status}
                </span>
            </div>

            <div className="flex flex-col gap-3">
               <h4 className="text-xs font-mono text-vh-text-dark uppercase border-b border-vh-border pb-1">Audit Envelope</h4>
               <div className="flex items-center gap-3 p-3 rounded bg-vh-surface border border-vh-border-strong/50">
                 <Shield className="w-4 h-4 text-vh-text-dark shrink-0" />
                 <div className="flex flex-col text-[11px] break-all">
                   <span className="text-vh-text-dark">Signature Hash:</span>
                   <span className="text-vh-text-muted">sha256:8f2a1b9d4e5c7f0a3b6c9d2e5f8a1b4c7d0e3f6a9b2c5d8e1f4a7b0c3d6e9f2a</span>
                 </div>
               </div>
            </div>

            <div className="flex flex-col gap-3">
               <h4 className="text-xs font-mono text-vh-text-dark uppercase border-b border-vh-border pb-1">Payload</h4>
               <div className="p-3 rounded bg-vh-surface border border-vh-border-strong/50 overflow-x-auto">
                 <pre className="text-[11px] text-vh-text-muted">
{`{
  "event_type": "${event.kind}",
  "actor_id": "usr_942x11",
  "target_ref": "${event.target}",
  "timestamp": "2026-04-18T14:30:12Z",
  "metadata": {
    "ip": "192.168.1.104",
    "user_agent": "VibeHub Client v10.0"
  }
}`}
                 </pre>
               </div>
            </div>

          </div>
        </div>

        {/* Action Row */}
        <div className="p-4 border-t border-vh-border bg-vh-surface flex gap-3 shrink-0">
          <button onClick={onClose} className="flex-1 py-2.5 rounded border border-vh-border bg-vh-bg text-sm font-medium text-vh-text-muted hover:text-vh-text hover:bg-vh-elevated transition-colors">
            关闭
          </button>
        </div>
      </div>
    </>
  );
}
