import { cn } from "../utils";
import { Users, Activity, Star } from "lucide-react";

import { Link } from "react-router";

export interface ProjectCardProps {
  id: string;
  title: string;
  description: string;
  tags: string[];
  type: string;
  author: { name: string; avatar: string };
  stats: { stars: number; members: number };
  featured?: boolean;
}

export function ProjectCard({ project, featured = false }: { project: ProjectCardProps, featured?: boolean }) {
  return (
    <Link
      to={`/p/${project.id}`}
      className={cn(
        "group relative flex flex-col justify-between overflow-hidden rounded border border-vh-border bg-vh-surface p-4 text-vh-text-muted transition-all hover:border-vh-signal/30 hover:shadow-[0_0_20px_rgba(205,213,227,0.04),0_0_60px_rgba(205,213,227,0.02)] hover:bg-vh-elevated focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal vh-card-glow",
        featured ? "w-[320px] h-[160px] shrink-0 scroll-snap-align-start" : "w-full min-h-[180px]"
      )}
      tabIndex={0}
      role="article"
    >
      <div className="flex flex-col gap-2 relative z-10">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="truncate font-display font-semibold text-vh-text group-hover:text-white transition-colors tracking-[-0.01em]">
              {project.title}
            </span>
            {project.type === "开源" && (
              <span className="inline-flex items-center rounded-sm bg-vh-signal-dim border border-vh-signal/20 px-1.5 py-0.5 text-[10px] font-mono font-medium text-vh-signal">
                OSS
              </span>
            )}
            {project.type === "正在招募协作" && (
              <span className="inline-flex items-center rounded-sm bg-vh-blue-dim border border-vh-blue/20 px-1.5 py-0.5 text-[10px] font-mono font-medium text-vh-blue">
                招募
              </span>
            )}
            {project.type === "高推荐" && (
              <span className="inline-flex items-center rounded-sm bg-vh-orange-dim border border-vh-orange/20 px-1.5 py-0.5 text-[10px] font-mono font-medium text-vh-orange">
                推荐
              </span>
            )}
          </div>
          <button className="text-vh-text-dim hover:text-vh-signal transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-vh-signal rounded p-0.5 shrink-0">
            <Star className="w-4 h-4" />
          </button>
        </div>

        <p className="line-clamp-2 text-sm text-vh-text-muted leading-relaxed">
          {project.description}
        </p>

        <div className="flex flex-wrap items-center gap-1.5 mt-1">
          {project.tags.slice(0, 3).map((tag, i) => (
            <span key={i} className="inline-flex items-center rounded bg-vh-void border border-vh-border px-1.5 py-0.5 text-xs font-mono text-vh-text-dim">
              {tag}
            </span>
          ))}
          {project.tags.length > 3 && (
            <span className="inline-flex items-center rounded bg-vh-void border border-vh-border px-1.5 py-0.5 text-xs font-mono text-vh-text-dim">
              +{project.tags.length - 3}
            </span>
          )}
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-vh-border pt-3 relative z-10">
        <div className="flex items-center gap-2">
          <div className="flex h-5 w-5 items-center justify-center rounded bg-vh-deep text-[10px] font-medium text-vh-signal ring-1 ring-vh-surface select-none font-mono">
            {project.author.name.charAt(0)}
          </div>
          <span className="truncate text-xs text-vh-text-dim max-w-[80px]">
            {project.author.name}
          </span>
        </div>

        <div className="flex items-center gap-3 text-xs text-vh-text-dim">
          <div className="flex items-center gap-1">
            <Activity className="w-3.5 h-3.5" />
            <span className="font-mono">{project.stats.stars}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5" />
            <span className="font-mono">{project.stats.members}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}

export function ProjectCardSkeleton({ featured = false }: { featured?: boolean }) {
  return (
    <div
      className={cn(
        "flex flex-col justify-between overflow-hidden rounded border border-vh-border bg-vh-surface p-4 animate-pulse",
        featured ? "w-[320px] h-[160px] shrink-0" : "w-full min-h-[180px]"
      )}
    >
      <div className="flex flex-col gap-3">
        <div className="h-4 bg-vh-elevated rounded w-3/4" />
        <div className="h-3 bg-vh-elevated rounded w-full" />
        <div className="h-3 bg-vh-elevated rounded w-2/3" />
        <div className="flex gap-2">
          <div className="h-5 w-14 bg-vh-elevated rounded" />
          <div className="h-5 w-14 bg-vh-elevated rounded" />
        </div>
      </div>
      <div className="mt-4 flex items-center justify-between border-t border-vh-border pt-3">
        <div className="h-4 bg-vh-elevated rounded w-20" />
        <div className="flex gap-3">
          <div className="h-4 bg-vh-elevated rounded w-10" />
          <div className="h-4 bg-vh-elevated rounded w-10" />
        </div>
      </div>
    </div>
  );
}
