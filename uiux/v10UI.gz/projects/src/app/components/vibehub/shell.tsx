import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Search, Plus, Settings, PanelRightClose, PanelRightOpen,
  LayoutDashboard, FolderKanban, CheckSquare, Users, MessageSquare,
  Shield, Globe, Server, Clock, X,
} from "lucide-react";
import { IconButton, Kbd, Divider, Input, Tag } from "./primitives";

/* ── Re-export the new comprehensive TopNav ── */
export { TopNav } from "./top-nav";
export type { TopNavProps, NavUser, NavSubscription } from "./top-nav";

function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

/* ═══════════════════════════════════════════════════════
   B-2. LeftRail
   ═══════════════════════════════════════════════════════ */
const navItems = [
  { icon: LayoutDashboard, label: "仪表盘", path: "/" },
  { icon: FolderKanban, label: "项目", path: "/projects" },
  { icon: CheckSquare, label: "任务", path: "/tasks" },
  { icon: Users, label: "团队", path: "/team" },
  { icon: MessageSquare, label: "讨论", path: "/discussions" },
];

interface LeftRailProps {
  activePath?: string;
  onNavigate?: (path: string) => void;
  onCreateOpen?: () => void;
}
export function LeftRail({ activePath = "/", onNavigate, onCreateOpen }: LeftRailProps) {
  return (
    <aside className="w-[220px] h-full border-r border-[var(--border-default)] bg-[var(--surface)] flex flex-col shrink-0">
      <div className="h-12 flex items-center px-4 border-b border-[var(--border-default)]">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-[var(--radius-sm)] bg-[var(--accent-violet)] flex items-center justify-center font-mono text-[var(--text-on-accent)] text-[length:var(--text-micro)]">V</div>
          <span className="font-sans font-medium text-[length:var(--text-body-sm)] text-[var(--text-primary)]">VibeHub</span>
          <Tag>v10</Tag>
        </div>
      </div>

      <div className="p-3 flex-1 overflow-y-auto">
        <button
          onClick={onCreateOpen}
          className="w-full flex items-center justify-between bg-[var(--elevated)] hover:bg-[var(--surface-hover)] border border-[var(--border-default)] rounded-[var(--radius-md)] px-3 py-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors mb-4 cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <Plus size={14} className="text-[var(--text-muted)]" />
            <span className="text-[length:var(--text-caption)]">新建</span>
          </div>
          <Kbd>C</Kbd>
        </button>

        <nav className="space-y-0.5">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => onNavigate?.(item.path)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-1.5 rounded-[var(--radius-md)] text-[length:var(--text-body-sm)] transition-colors cursor-pointer",
                activePath === item.path
                  ? "bg-[var(--subtle)] text-[var(--text-primary)]"
                  : "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)]"
              )}
            >
              <item.icon size={14} className="opacity-70 shrink-0" />
              {item.label}
            </button>
          ))}
        </nav>
      </div>

      <div className="p-3 border-t border-[var(--border-default)]">
        <button className="w-full flex items-center gap-3 px-3 py-1.5 rounded-[var(--radius-md)] text-[length:var(--text-body-sm)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)] transition-colors cursor-pointer">
          <Settings size={14} className="opacity-70" />
          设置
        </button>
      </div>
    </aside>
  );
}

/* ═══════════════════════════════════════════════════════
   B-3. ConsoleShell
   ═══════════════════════════════════════════════════════ */
interface ConsoleShellProps {
  leftRail: React.ReactNode;
  children: React.ReactNode;
  rightRail?: React.ReactNode;
}
export function ConsoleShell({ leftRail, children, rightRail }: ConsoleShellProps) {
  const [rightOpen, setRightOpen] = useState(true);
  return (
    <div className="flex h-full w-full overflow-hidden">
      {leftRail}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">{children}</div>
      {rightRail && (
        <>
          <button
            onClick={() => setRightOpen(!rightOpen)}
            className="absolute top-3 right-3 z-10 text-[var(--text-muted)] hover:text-[var(--text-secondary)] cursor-pointer"
          >
            {rightOpen ? <PanelRightClose size={16} /> : <PanelRightOpen size={16} />}
          </button>
          <AnimatePresence>
            {rightOpen && (
              <motion.aside
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 320, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                className="border-l border-[var(--border-default)] bg-[var(--surface)] overflow-hidden shrink-0"
              >
                <div className="w-[320px] h-full overflow-y-auto p-4">{rightRail}</div>
              </motion.aside>
            )}
          </AnimatePresence>
        </>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   B-4. PageHeader
   ═══════════════════════════════════════════════════════ */
interface PageHeaderProps {
  title: string;
  subtitle?: string;
  filter?: React.ReactNode;
  action?: React.ReactNode;
}
export function PageHeader({ title, subtitle, filter, action }: PageHeaderProps) {
  return (
    <div className="flex items-center justify-between px-6 py-4 border-b border-[var(--border-default)]">
      <div>
        <h1 className="text-[length:var(--text-h3)] text-[var(--text-primary)] font-sans font-medium">{title}</h1>
        {subtitle && <p className="text-[length:var(--text-caption)] text-[var(--text-secondary)] mt-0.5">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3">
        {filter}
        {action}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   B-5. SectionCard
   ═══════════════════════════════════════════════════════ */
interface SectionCardProps {
  children: React.ReactNode;
  className?: string;
}
export function SectionCard({ children, className }: SectionCardProps) {
  return (
    <div className={cn("bg-[var(--surface)] border border-[var(--border-default)] rounded-[var(--radius-lg)] p-4", className)}>
      {children}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   B-6. WorkspaceTopBar
   ═══════════════════════════════════════════════════════ */
interface WorkspaceTopBarProps {
  name: string;
  project: string;
  counts: { label: string; value: number }[];
  actions?: React.ReactNode;
}
export function WorkspaceTopBar({ name, project, counts, actions }: WorkspaceTopBarProps) {
  return (
    <div className="flex items-center justify-between px-4 py-2 border-b border-[var(--border-default)] bg-[var(--surface)]">
      <div className="flex items-center gap-4">
        <span className="text-[length:var(--text-body-sm)] text-[var(--text-primary)] font-medium">{name}</span>
        <span className="text-[length:var(--text-caption)] text-[var(--text-muted)]">/</span>
        <span className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)]">{project}</span>
        <Divider orientation="vertical" />
        <div className="flex items-center gap-3">
          {counts.map((c) => (
            <span key={c.label} className="text-[length:var(--text-caption)] text-[var(--text-muted)]">
              <span className="font-mono text-[var(--text-secondary)]">{c.value}</span> {c.label}
            </span>
          ))}
        </div>
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   B-7. ComplianceStrip
   ═══════════════════════════════════════════════════════ */
interface ComplianceStripProps {
  region: string;
  crossBorder: boolean;
  modelFiling: string;
  auditRetention: string;
}
export function ComplianceStrip({ region, crossBorder, modelFiling, auditRetention }: ComplianceStripProps) {
  return (
    <div className="flex items-center gap-4 px-4 py-1.5 border-b border-[var(--border-subtle)] bg-[var(--subtle)]">
      <div className="flex items-center gap-1.5 text-[length:var(--text-micro)] text-[var(--text-muted)]">
        <Server size={10} />
        <span className="font-mono">{region}</span>
      </div>
      <div className="flex items-center gap-1.5 text-[length:var(--text-micro)] text-[var(--text-muted)]">
        <Globe size={10} />
        <span>跨境: {crossBorder ? "是" : "否"}</span>
      </div>
      <div className="flex items-center gap-1.5 text-[length:var(--text-micro)] text-[var(--text-muted)]">
        <Shield size={10} />
        <span>备案: {modelFiling}</span>
      </div>
      <div className="flex items-center gap-1.5 text-[length:var(--text-micro)] text-[var(--text-muted)]">
        <Clock size={10} />
        <span>审计: {auditRetention}</span>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   B-8. ViewTabs
   ═══════════════════════════════════════════════════════ */
interface ViewTabsProps {
  tabs: { key: string; label: string }[];
  active: string;
  onChange: (key: string) => void;
}
export function ViewTabs({ tabs, active, onChange }: ViewTabsProps) {
  return (
    <div className="flex items-center gap-0 border-b border-[var(--border-default)] px-4">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => onChange(tab.key)}
          className={cn(
            "relative px-3 py-2.5 text-[length:var(--text-body-sm)] font-sans transition-colors cursor-pointer",
            active === tab.key ? "text-[var(--text-primary)]" : "text-[var(--text-muted)] hover:text-[var(--text-secondary)]"
          )}
        >
          {tab.label}
          {active === tab.key && (
            <motion.div
              layoutId="viewtab-underline"
              className="absolute bottom-0 left-0 right-0 h-px bg-[var(--text-primary)]"
            />
          )}
        </button>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   B-9. DrawerSheet
   ═══════════════════════════════════════════════════════ */
interface DrawerSheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}
export function DrawerSheet({ open, onClose, title, children }: DrawerSheetProps) {
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="relative w-[480px] max-w-full h-full bg-[var(--surface)] border-l border-[var(--border-default)] shadow-[var(--shadow-modal)] flex flex-col"
          >
            <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border-default)]">
              <h2 className="text-[length:var(--text-body-lg)] text-[var(--text-primary)] font-medium">{title}</h2>
              <IconButton size="sm" onClick={onClose}>
                <X size={14} />
              </IconButton>
            </div>
            <div className="flex-1 overflow-y-auto p-5">{children}</div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

/* ═══════════════════════════════════════════════════════
   B-10. CommandPaletteShell
   ═══════════════════════════════════════════════════════ */
interface CommandGroup {
  heading: string;
  items: { icon: React.ReactNode; label: string; shortcut?: string }[];
}
interface CommandPaletteShellProps {
  open: boolean;
  onClose: () => void;
  groups: CommandGroup[];
}
export function CommandPaletteShell({ open, onClose, groups }: CommandPaletteShellProps) {
  const [query, setQuery] = useState("");
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[20vh]">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/60"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -8 }}
            className="relative w-[640px] max-w-[90vw] bg-[var(--surface)] border border-[var(--border-default)] rounded-[var(--radius-xl)] shadow-[var(--shadow-modal)] overflow-hidden"
          >
            <div className="flex items-center gap-3 px-4 py-3 border-b border-[var(--border-default)]">
              <Search size={16} className="text-[var(--text-muted)] shrink-0" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="输入命令或搜索..."
                className="flex-1 bg-transparent text-[length:var(--text-body-sm)] text-[var(--text-primary)] placeholder:text-[var(--text-muted)] focus:outline-none font-sans"
                autoFocus
              />
              <Kbd>ESC</Kbd>
            </div>
            <div className="max-h-[360px] overflow-y-auto py-2">
              {groups.map((group) => (
                <div key={group.heading}>
                  <div className="px-4 py-1.5 text-[length:var(--text-micro)] text-[var(--text-muted)] font-sans uppercase tracking-wider">
                    {group.heading}
                  </div>
                  {group.items.map((item, i) => (
                    <button
                      key={i}
                      className="w-full flex items-center gap-3 px-4 py-2 text-[length:var(--text-body-sm)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)] transition-colors cursor-pointer"
                    >
                      <span className="text-[var(--text-muted)]">{item.icon}</span>
                      <span className="flex-1 text-left">{item.label}</span>
                      {item.shortcut && <Kbd>{item.shortcut}</Kbd>}
                    </button>
                  ))}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}