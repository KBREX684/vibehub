import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Home, Users, FolderOpen, Inbox, Bot, Bell, Settings,
  ChevronRight, ChevronDown, Plus, X, CheckSquare, FileText,
  Activity, Package, Zap, ExternalLink, Globe, Server, Clock, Shield,
  MoreHorizontal, Check, UserPlus, Share2, Filter,
  AlertTriangle, FileCode, Image as ImageIcon,
} from "lucide-react";
import {
  Avatar, StatusPill, Tag, Divider,
} from "./primitives";
import {
  AgentBadge, TaskCard, ActivityEvent, SnapshotCard,
} from "./domain-cards";

function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

/* ══════════════════════════════════════════════════════════
   Types
   ══════════════════════════════════════════════════════════ */

type RightMode = "agent" | "tasks" | "files" | "snapshots" | "activity";
type MainTab = "activity" | "tasks" | "files" | "snapshots" | "members" | "agents" | "settings";

const RIGHT_RAIL_MODES: { key: RightMode; icon: React.ElementType; label: string }[] = [
  { key: "agent", icon: Bot, label: "Agent 控制台" },
  { key: "tasks", icon: CheckSquare, label: "运行任务" },
  { key: "files", icon: FileText, label: "文件" },
  { key: "snapshots", icon: Package, label: "快照" },
  { key: "activity", icon: Activity, label: "活动流" },
];

const MAIN_TABS: { key: MainTab; label: string; count: number | null }[] = [
  { key: "activity", label: "活动", count: 24 },
  { key: "tasks", label: "任务", count: 12 },
  { key: "files", label: "文件", count: 86 },
  { key: "snapshots", label: "快照", count: 5 },
  { key: "members", label: "成员", count: 5 },
  { key: "agents", label: "代理", count: 5 },
  { key: "settings", label: "设置", count: null },
];

/* ══════════════════════════════════════════════════════════
   Mock Data
   ══════════════════════════════════════════════════════════ */

const MOCK_AGENTS = [
  { id: "a1", role: "Reviewer" as const, status: "running" as const, task: "审查 PR #89 代码质量", since: "14分前" },
  { id: "a2", role: "Executor" as const, status: "running" as const, task: "部署预发布 v2.3.1", since: "32分前" },
  { id: "a3", role: "Reader" as const, status: "idle" as const, task: null, since: null },
  { id: "a4", role: "Coordinator" as const, status: "idle" as const, task: null, since: null },
  { id: "a5", role: "Reader" as const, status: "idle" as const, task: null, since: null },
];

const MOCK_RUNNING_TASKS = [
  { id: "t1", actor: { name: "AI Reviewer" }, action: "正在审查", target: "PR #89 代码质量", state: "running" as const, time: "14分前" },
  { id: "t2", actor: { name: "AI Executor" }, action: "正在部署", target: "预发布 v2.3.1", state: "running" as const, time: "32分前" },
];

const MOCK_PENDING = [
  { id: "c1", actor: { name: "AI Coordinator" }, action: "请求确认", target: "删除旧快照 snap-v18 至 snap-v20", state: "pending-confirm" as const, time: "5分前" },
  { id: "c2", actor: { name: "AI Executor" }, action: "请求权限", target: "访问生产数据库只读副本", state: "pending-confirm" as const, time: "22分前" },
];

const MOCK_RECENT_OUTPUT = [
  { id: "o1", task: "PR #89 代码审查", summary: "发现 3 处潜在问题，2 处建议优化", href: "#" },
  { id: "o2", task: "依赖版本检查", summary: "react 18.3 → 18.4 可用，无破坏性更改", href: "#" },
  { id: "o3", task: "接口文档生成", summary: "已生成 24 个端点文档，已推送 /docs", href: "#" },
];

const MOCK_ACTIVITY = [
  { actor: "张伟", verb: "提交了快照至", target: "AI 协作引擎 v3", workspaceId: "ws-001", snapshotId: "snap-c23", time: "2026-04-18 10:32" },
  { actor: "AI Reviewer", verb: "审核通过了", target: "接口规范 v2.1", workspaceId: "ws-001", snapshotId: "snap-c22", time: "2026-04-18 09:15" },
  { actor: "李雨桐", verb: "更新了成员权限", target: "team-alpha 工作区", workspaceId: "ws-002", time: "2026-04-17 18:40" },
  { actor: "AI Executor", verb: "完成部署", target: "预发布 v2.3.0", workspaceId: "ws-001", snapshotId: "snap-c21", time: "2026-04-17 16:55" },
  { actor: "王鑫", verb: "发起了协作意向", target: "数据可视化平台", workspaceId: "ws-001", time: "2026-04-17 14:22" },
  { actor: "AI Coordinator", verb: "分配了任务至", target: "代码架构审查", workspaceId: "ws-001", time: "2026-04-17 11:08" },
];

const MOCK_TASK_ITEMS = [
  { id: "tk1", actor: { name: "张伟" }, action: "创建了", target: "数据库性能优化方案", state: "pending" as const, time: "15分前" },
  { id: "tk2", actor: { name: "AI Reviewer" }, action: "完成了", target: "代码审查 #142", state: "done" as const, time: "1小时前" },
  { id: "tk3", actor: { name: "李雨桐" }, action: "更新了", target: "API 接口文档 v2.1", state: "running" as const, time: "2小时前" },
  { id: "tk4", actor: { name: "AI Executor" }, action: "标记失败", target: "自动化测试部署", state: "failed" as const, time: "3小时前" },
  { id: "tk5", actor: { name: "AI Coordinator" }, action: "请求确认", target: "删除 /tmp 临时文件", state: "pending-confirm" as const, time: "5小时前" },
];

const MOCK_SNAPSHOTS = [
  { title: "Sprint 22 交付快照", intent: "完成协作引擎核心 API 和权限模块", previousSnapshot: "snap-v21", artifactCount: 8, deliverableStatus: "done" as const },
  { title: "Sprint 23 进行中", intent: "实现多智能体调度和任务分配", artifactCount: 3, deliverableStatus: "running" as const },
  { title: "Sprint 21 归档", intent: "搭建基础项目结构和 CI/CD", previousSnapshot: "snap-v20", artifactCount: 12, deliverableStatus: "done" as const },
];

const MOCK_MEMBERS = [
  { name: "张伟", email: "zhangwei@vibehub.dev", role: "Owner", status: "online" as const },
  { name: "李雨桐", email: "liyutong@vibehub.dev", role: "Admin", status: "online" as const },
  { name: "王鑫", email: "wangxin@vibehub.dev", role: "Member", status: "away" as const },
  { name: "陈明", email: "chenming@vibehub.dev", role: "Member", status: "offline" as const },
  { name: "赵琳", email: "zhaolin@vibehub.dev", role: "Member", status: "offline" as const },
];

const MOCK_FILES = [
  { name: "产品需求文档.md", size: "24 KB", modified: "2小时前", type: "doc" as const },
  { name: "架构设计图.png", size: "1.2 MB", modified: "昨天", type: "image" as const },
  { name: "API 规范 v2.1.yaml", size: "86 KB", modified: "2天前", type: "code" as const },
  { name: "部署清单.json", size: "12 KB", modified: "3天前", type: "code" as const },
  { name: "团队协作协议.pdf", size: "340 KB", modified: "上周", type: "doc" as const },
  { name: "数据库 ERD.png", size: "2.1 MB", modified: "2周前", type: "image" as const },
];

const FILE_ICON: Record<string, React.ElementType> = {
  doc: FileText,
  image: ImageIcon,
  code: FileCode,
};

const FILE_COLOR: Record<string, string> = {
  doc: "var(--accent-apple)",
  image: "var(--accent-cyan)",
  code: "var(--accent-violet)",
};

/* ══════════════════════════════════════════════════════════
   Left Rail Sub-components
   ══════════════════════════════════════════════════════════ */

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="font-sans uppercase tracking-wider text-[var(--text-muted)]"
      style={{
        fontSize: "var(--text-micro)",
        paddingLeft: "10px",
        marginBottom: "2px",
        marginTop: "14px",
      }}
    >
      {children}
    </div>
  );
}

function TinyAvatar({ seed }: { seed: string }) {
  const palette = [
    "var(--accent-violet)",
    "var(--accent-cyan)",
    "var(--accent-apple)",
    "var(--semantic-success)",
    "var(--semantic-warning)",
  ];
  const color = palette[seed.charCodeAt(0) % palette.length];
  return (
    <div
      className="rounded-full flex items-center justify-center font-mono shrink-0"
      style={{
        width: "16px",
        height: "16px",
        backgroundColor: color,
        fontSize: "8px",
        color: "var(--text-on-accent)",
      }}
    >
      {seed[0]?.toUpperCase()}
    </div>
  );
}

interface NavItemProps {
  icon?: React.ElementType;
  label: string;
  badge?: number | null;
  badgeTone?: "error" | "warning" | "neutral";
  badgeLabel?: string;
  isActive?: boolean;
  onClick?: () => void;
  indent?: number;
  barId?: string;
}

function NavItem({
  icon: Icon,
  label,
  badge,
  badgeTone = "neutral",
  badgeLabel,
  isActive,
  onClick,
  indent = 0,
  barId = "nav-bar-default",
}: NavItemProps) {
  return (
    <div className="relative">
      {isActive && (
        <motion.div
          layoutId={barId}
          className="absolute left-0 top-1/2 -translate-y-1/2 rounded-r-full"
          style={{
            width: "2px",
            height: "20px",
            backgroundColor: "var(--accent-apple)",
            zIndex: 1,
          }}
          transition={{ type: "spring", bounce: 0.2, duration: 0.35 }}
        />
      )}
      <button
        onClick={onClick}
        className={cn(
          "w-full flex items-center gap-2 rounded-[var(--radius-md)] transition-colors duration-150 cursor-pointer select-none focus-visible:outline-none",
          isActive
            ? "bg-[var(--surface)] text-[var(--text-primary)]"
            : "text-[var(--text-secondary)] hover:bg-[var(--subtle)] hover:text-[var(--text-primary)]"
        )}
        style={{
          height: "36px",
          paddingLeft: `${10 + indent}px`,
          paddingRight: "10px",
          fontSize: "var(--text-body-sm)",
        }}
      >
        {Icon && (
          <Icon
            size={16}
            className={cn("shrink-0", isActive ? "opacity-100" : "opacity-60")}
          />
        )}
        <span className="flex-1 text-left truncate">{label}</span>

        {/* Badge */}
        {badge != null && badge > 0 && (
          <span
            className="font-mono rounded shrink-0"
            style={{
              fontSize: "var(--text-micro)",
              padding: badgeLabel ? "2px 5px" : "2px 5px",
              minWidth: "18px",
              textAlign: "center",
              backgroundColor:
                badgeTone === "warning"
                  ? "var(--semantic-warning-subtle)"
                  : badgeTone === "error"
                  ? "var(--semantic-error)"
                  : "var(--elevated)",
              color:
                badgeTone === "error"
                  ? "var(--text-on-accent)"
                  : badgeTone === "warning"
                  ? "var(--semantic-warning)"
                  : "var(--text-secondary)",
              border:
                badgeTone === "neutral"
                  ? "1px solid var(--border-default)"
                  : badgeTone === "warning"
                  ? "1px solid var(--semantic-warning-subtle)"
                  : "none",
              borderRadius: "var(--radius-sm)",
            }}
          >
            {badge}
            {badgeLabel ? ` ${badgeLabel}` : ""}
          </span>
        )}
      </button>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   Left Rail
   ══════════════════════════════════════════════════════════ */

interface WorkspaceLeftRailProps {
  activeNav: string;
  setActiveNav: (k: string) => void;
  activeSpace: string;
  setActiveSpace: (k: string) => void;
  user: { name: string; email: string };
}

function WorkspaceLeftRail({
  activeNav,
  setActiveNav,
  activeSpace,
  setActiveSpace,
  user,
}: WorkspaceLeftRailProps) {
  const [teamExpanded, setTeamExpanded] = useState(true);

  return (
    <aside
      className="flex flex-col shrink-0 border-r border-[var(--border-default)] overflow-hidden"
      style={{ width: "220px", backgroundColor: "var(--canvas)" }}
    >
      {/* ── Top logo (40px) ── */}
      <div
        className="flex items-center gap-2 shrink-0 border-b border-[var(--border-default)]"
        style={{ height: "40px", paddingLeft: "12px", paddingRight: "12px" }}
      >
        <div
          className="flex items-center justify-center shrink-0 rounded-[var(--radius-sm)]"
          style={{
            width: "20px",
            height: "20px",
            backgroundColor: "var(--elevated)",
            border: "1px solid var(--border-default)",
          }}
        >
          <Zap size={11} className="text-[var(--text-primary)]" fill="currentColor" />
        </div>
        <span
          className="font-sans font-semibold text-[var(--text-primary)] tracking-tight"
          style={{ fontSize: "var(--text-body-sm)" }}
        >
          VibeHub
        </span>
        <Tag>工作台</Tag>
      </div>

      {/* ── Scrollable middle ── */}
      <div className="flex-1 overflow-y-auto" style={{ padding: "6px 8px" }}>

        {/* Section 1: Spaces */}
        <SectionLabel>Spaces</SectionLabel>

        {/* Personal Workspace */}
        <NavItem
          icon={Home}
          label="Personal Workspace"
          isActive={activeSpace === "personal"}
          onClick={() => setActiveSpace("personal")}
          barId="space-bar"
        />

        {/* Team Workspace (collapsible header) */}
        <div className="relative">
          {activeSpace.startsWith("team") && (
            <motion.div
              layoutId="space-bar"
              className="absolute left-0 top-1/2 -translate-y-1/2 rounded-r-full"
              style={{
                width: "2px",
                height: "20px",
                backgroundColor: "var(--accent-apple)",
                zIndex: 1,
              }}
              transition={{ type: "spring", bounce: 0.2, duration: 0.35 }}
            />
          )}
          <button
            onClick={() => setTeamExpanded((v) => !v)}
            className={cn(
              "w-full flex items-center gap-2 rounded-[var(--radius-md)] transition-colors duration-150 cursor-pointer select-none",
              activeSpace.startsWith("team")
                ? "bg-[var(--surface)] text-[var(--text-primary)]"
                : "text-[var(--text-secondary)] hover:bg-[var(--subtle)] hover:text-[var(--text-primary)]"
            )}
            style={{
              height: "36px",
              paddingLeft: "10px",
              paddingRight: "10px",
              fontSize: "var(--text-body-sm)",
            }}
          >
            <Users
              size={16}
              className={cn(
                "shrink-0",
                activeSpace.startsWith("team") ? "opacity-100" : "opacity-60"
              )}
            />
            <span className="flex-1 text-left">Team Workspace</span>
            <motion.div
              animate={{ rotate: teamExpanded ? 90 : 0 }}
              transition={{ duration: 0.2 }}
              className="shrink-0"
            >
              <ChevronRight size={12} className="text-[var(--text-muted)]" />
            </motion.div>
          </button>
        </div>

        {/* Team sub-items */}
        <AnimatePresence initial={false}>
          {teamExpanded && (
            <motion.div
              key="team-children"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2, ease: "easeInOut" }}
              className="overflow-hidden"
            >
              {/* team-alpha */}
              <button
                onClick={() => setActiveSpace("team-alpha")}
                className={cn(
                  "w-full flex items-center gap-2 rounded-[var(--radius-md)] transition-colors duration-150 cursor-pointer",
                  activeSpace === "team-alpha"
                    ? "bg-[var(--surface)] text-[var(--text-primary)]"
                    : "text-[var(--text-secondary)] hover:bg-[var(--subtle)] hover:text-[var(--text-primary)]"
                )}
                style={{
                  height: "32px",
                  paddingLeft: "26px",
                  paddingRight: "10px",
                  fontSize: "var(--text-body-sm)",
                }}
              >
                <TinyAvatar seed="alpha" />
                <span className="flex-1 text-left truncate">team-alpha</span>
              </button>

              {/* team-beta */}
              <button
                onClick={() => setActiveSpace("team-beta")}
                className={cn(
                  "w-full flex items-center gap-2 rounded-[var(--radius-md)] transition-colors duration-150 cursor-pointer",
                  activeSpace === "team-beta"
                    ? "bg-[var(--surface)] text-[var(--text-primary)]"
                    : "text-[var(--text-secondary)] hover:bg-[var(--subtle)] hover:text-[var(--text-primary)]"
                )}
                style={{
                  height: "32px",
                  paddingLeft: "26px",
                  paddingRight: "10px",
                  fontSize: "var(--text-body-sm)",
                }}
              >
                <TinyAvatar seed="beta" />
                <span className="flex-1 text-left truncate">team-beta</span>
              </button>

              {/* + 新建 */}
              <button
                className="w-full flex items-center gap-1.5 rounded-[var(--radius-md)] cursor-pointer transition-opacity hover:opacity-80"
                style={{
                  height: "30px",
                  paddingLeft: "26px",
                  paddingRight: "10px",
                  marginTop: "2px",
                  marginBottom: "2px",
                  fontSize: "var(--text-caption)",
                  color: "var(--accent-violet)",
                  backgroundColor: "var(--accent-violet-subtle)",
                  border: "1px dashed var(--accent-violet-hover)",
                }}
              >
                <Plus size={12} />
                <span>新建</span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Divider */}
        <div
          style={{
            height: "1px",
            backgroundColor: "var(--border-subtle)",
            margin: "10px 2px",
          }}
        />

        {/* Section 2: Work */}
        <SectionLabel>Work</SectionLabel>

        <NavItem
          icon={FolderOpen}
          label="项目库"
          isActive={activeNav === "library"}
          onClick={() => setActiveNav("library")}
          barId="work-bar"
        />
        <NavItem
          icon={Inbox}
          label="协作意向"
          badge={3}
          badgeTone="error"
          isActive={activeNav === "intents"}
          onClick={() => setActiveNav("intents")}
          barId="work-bar"
        />
        <NavItem
          icon={Bot}
          label="Agent 任务"
          badge={2}
          badgeTone="warning"
          badgeLabel="待确认"
          isActive={activeNav === "agent-tasks"}
          onClick={() => setActiveNav("agent-tasks")}
          barId="work-bar"
        />
        <NavItem
          icon={Bell}
          label="通知"
          badge={7}
          badgeTone="neutral"
          isActive={activeNav === "notifications"}
          onClick={() => setActiveNav("notifications")}
          barId="work-bar"
        />
      </div>

      {/* ── Bottom: Settings + User chip ── */}
      <div
        className="shrink-0 border-t border-[var(--border-default)]"
        style={{ padding: "6px 8px" }}
      >
        <NavItem icon={Settings} label="设置" onClick={() => {}} />

        {/* User chip */}
        <button
          className="w-full flex items-center gap-2 rounded-[var(--radius-md)] hover:bg-[var(--subtle)] transition-colors cursor-pointer mt-1"
          style={{ height: "36px", paddingLeft: "10px", paddingRight: "10px" }}
        >
          <Avatar name={user.name} size="sm" />
          <div className="flex-1 min-w-0 text-left">
            <div
              className="font-sans text-[var(--text-secondary)] truncate"
              style={{ fontSize: "var(--text-caption)" }}
            >
              {user.name}
            </div>
          </div>
          <ChevronDown size={11} className="text-[var(--text-muted)] shrink-0" />
        </button>
      </div>
    </aside>
  );
}

/* ══════════════════════════════════════════════════════════
   Right Rail — Section wrapper
   ══════════════════════════════════════════════════════════ */

function RailSection({
  title,
  mono,
  tone,
  children,
}: {
  title: string;
  mono?: string;
  tone?: "warning";
  children: React.ReactNode;
}) {
  return (
    <div className="border-b border-[var(--border-subtle)]">
      {/* Section header */}
      <div
        className="flex items-center justify-between sticky top-0 z-10"
        style={{
          paddingLeft: "var(--space-4)",
          paddingRight: "var(--space-4)",
          paddingTop: "var(--space-2)",
          paddingBottom: "var(--space-2)",
          backgroundColor: "var(--canvas)",
          borderBottom: "1px solid var(--border-subtle)",
        }}
      >
        <span
          className="font-sans font-medium"
          style={{
            fontSize: "var(--text-caption)",
            color: tone === "warning" ? "var(--semantic-warning)" : "var(--text-secondary)",
          }}
        >
          {title}
        </span>
        {mono && (
          <span
            className="font-mono"
            style={{ fontSize: "var(--text-micro)", color: "var(--text-muted)" }}
          >
            {mono}
          </span>
        )}
      </div>
      <div style={{ padding: "var(--space-2) 0" }}>{children}</div>
    </div>
  );
}

/* ── Agent row ── */
function AgentRailRow({ agent }: { agent: typeof MOCK_AGENTS[number] }) {
  return (
    <div
      className="flex items-start gap-2"
      style={{
        paddingLeft: "var(--space-4)",
        paddingRight: "var(--space-4)",
        paddingTop: "var(--space-2)",
        paddingBottom: "var(--space-2)",
      }}
    >
      <AgentBadge role={agent.role} />
      <div className="flex-1 min-w-0">
        {agent.status === "running" && agent.task ? (
          <>
            <div
              className="font-sans text-[var(--text-secondary)] truncate"
              style={{ fontSize: "var(--text-micro)" }}
            >
              {agent.task}
            </div>
            <div
              className="font-mono text-[var(--text-muted)] mt-0.5 flex items-center gap-1"
              style={{ fontSize: "var(--text-micro)" }}
            >
              <span
                className="w-1.5 h-1.5 rounded-full animate-pulse shrink-0"
                style={{ backgroundColor: "var(--accent-apple)" }}
              />
              {agent.since}
            </div>
          </>
        ) : (
          <span
            className="font-mono text-[var(--text-muted)]"
            style={{ fontSize: "var(--text-micro)" }}
          >
            空闲
          </span>
        )}
      </div>
    </div>
  );
}

/* ── Recent output row ── */
function RecentOutputRow({ item }: { item: typeof MOCK_RECENT_OUTPUT[number] }) {
  return (
    <a
      href={item.href}
      className="flex items-start gap-2 hover:bg-[var(--subtle)] transition-colors cursor-pointer block"
      style={{
        paddingLeft: "var(--space-4)",
        paddingRight: "var(--space-4)",
        paddingTop: "var(--space-2)",
        paddingBottom: "var(--space-2)",
        textDecoration: "none",
      }}
    >
      <div className="flex-1 min-w-0">
        <div
          className="font-sans text-[var(--text-primary)] truncate"
          style={{ fontSize: "var(--text-caption)" }}
        >
          {item.task}
        </div>
        <div
          className="font-sans text-[var(--text-muted)] mt-0.5 line-clamp-2"
          style={{ fontSize: "var(--text-micro)" }}
        >
          {item.summary}
        </div>
      </div>
      <ExternalLink size={11} className="text-[var(--text-muted)] shrink-0 mt-0.5" />
    </a>
  );
}

/* ══════════════════════════════════════════════════════════
   Right Rail Panels
   ══════════════════════════════════════════════════════════ */

function AgentConsolePanel() {
  const runningCount = MOCK_AGENTS.filter((a) => a.status === "running").length;
  const idleCount = MOCK_AGENTS.filter((a) => a.status === "idle").length;
  const [dismissed, setDismissed] = useState<string[]>([]);
  const pending = MOCK_PENDING.filter((p) => !dismissed.includes(p.id));

  return (
    <div className="flex flex-col h-full">
      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto">
        {/* 1. Agent list */}
        <RailSection
          title="代理"
          mono={`运行 ${runningCount} · 空闲 ${idleCount}`}
        >
          {MOCK_AGENTS.map((agent) => (
            <AgentRailRow key={agent.id} agent={agent} />
          ))}
        </RailSection>

        {/* 2. Running tasks */}
        <RailSection title="运行中">
          {MOCK_RUNNING_TASKS.map((task) => (
            <div
              key={task.id}
              style={{ paddingLeft: "var(--space-2)", paddingRight: "var(--space-2)" }}
            >
              <TaskCard
                actor={task.actor}
                action={task.action}
                target={task.target}
                state={task.state}
                time={task.time}
              />
            </div>
          ))}
        </RailSection>

        {/* 3. Pending confirmations */}
        <RailSection title="待确认" tone="warning">
          <AnimatePresence>
            {pending.map((item) => (
              <motion.div
                key={item.id}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div
                  className="rounded-[var(--radius-md)] mx-2 mb-2 border border-[var(--semantic-warning-subtle)] overflow-hidden"
                  style={{ backgroundColor: "var(--semantic-warning-subtle)" }}
                >
                  <div
                    style={{
                      paddingLeft: "var(--space-3)",
                      paddingRight: "var(--space-3)",
                      paddingTop: "var(--space-2)",
                    }}
                  >
                    <div className="flex items-start gap-2">
                      <AlertTriangle
                        size={13}
                        style={{ color: "var(--semantic-warning)", marginTop: "1px" }}
                        className="shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div
                          className="font-sans text-[var(--text-primary)]"
                          style={{ fontSize: "var(--text-caption)" }}
                        >
                          {item.actor.name} · {item.action}
                        </div>
                        <div
                          className="font-sans text-[var(--text-secondary)] mt-0.5"
                          style={{ fontSize: "var(--text-micro)" }}
                        >
                          {item.target}
                        </div>
                        <div
                          className="font-mono text-[var(--text-muted)] mt-0.5"
                          style={{ fontSize: "var(--text-micro)" }}
                        >
                          {item.time}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    className="flex items-center gap-2"
                    style={{ padding: "var(--space-2) var(--space-3)" }}
                  >
                    <button
                      onClick={() => setDismissed((d) => [...d, item.id])}
                      className="flex items-center gap-1 rounded-[var(--radius-sm)] font-sans cursor-pointer transition-opacity hover:opacity-80"
                      style={{
                        height: "24px",
                        paddingLeft: "var(--space-2)",
                        paddingRight: "var(--space-2)",
                        fontSize: "var(--text-micro)",
                        backgroundColor: "var(--accent-apple)",
                        color: "var(--text-on-accent)",
                      }}
                    >
                      <Check size={10} />
                      批准
                    </button>
                    <button
                      onClick={() => setDismissed((d) => [...d, item.id])}
                      className="flex items-center gap-1 rounded-[var(--radius-sm)] font-sans cursor-pointer transition-colors hover:bg-[var(--subtle)]"
                      style={{
                        height: "24px",
                        paddingLeft: "var(--space-2)",
                        paddingRight: "var(--space-2)",
                        fontSize: "var(--text-micro)",
                        color: "var(--text-secondary)",
                        border: "1px solid var(--border-default)",
                      }}
                    >
                      <X size={10} />
                      拒绝
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
            {pending.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center justify-center py-3"
              >
                <span
                  className="font-mono text-[var(--text-muted)]"
                  style={{ fontSize: "var(--text-micro)" }}
                >
                  无待确认项
                </span>
              </motion.div>
            )}
          </AnimatePresence>
        </RailSection>

        {/* 4. Recent output */}
        <RailSection title="最近输出">
          {MOCK_RECENT_OUTPUT.map((item) => (
            <RecentOutputRow key={item.id} item={item} />
          ))}
        </RailSection>
      </div>

      {/* 5. Sticky bottom: 发起任务 */}
      <div
        className="shrink-0 border-t border-[var(--border-default)]"
        style={{ padding: "var(--space-3)" }}
      >
        <button
          className="w-full flex items-center justify-center gap-2 rounded-[var(--radius-md)] font-sans font-medium cursor-pointer transition-opacity hover:opacity-90 active:opacity-75"
          style={{
            height: "36px",
            fontSize: "var(--text-body-sm)",
            backgroundColor: "var(--accent-apple)",
            color: "var(--text-on-accent)",
          }}
        >
          <Zap size={14} />
          发起任务
        </button>
      </div>
    </div>
  );
}

function SimpleRailPanel({ mode }: { mode: RightMode }) {
  const modeInfo = RIGHT_RAIL_MODES.find((m) => m.key === mode)!;
  const Icon = modeInfo.icon;
  return (
    <div className="flex flex-col items-center justify-center h-full gap-3 opacity-40">
      <Icon size={28} className="text-[var(--text-muted)]" />
      <span
        className="font-mono text-[var(--text-muted)]"
        style={{ fontSize: "var(--text-caption)" }}
      >
        {modeInfo.label}
      </span>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   Right Rail Shell
   ══════════════════════════════════════════════════════════ */

interface WorkspaceRightRailProps {
  mode: RightMode;
  setMode: (m: RightMode) => void;
  expanded: boolean;
  setExpanded: (v: boolean) => void;
}

function WorkspaceRightRail({
  mode,
  setMode,
  expanded,
  setExpanded,
}: WorkspaceRightRailProps) {
  return (
    <motion.aside
      animate={{ width: expanded ? 320 : 48 }}
      transition={{ type: "spring", damping: 30, stiffness: 280, restDelta: 0.5 }}
      className="shrink-0 border-l border-[var(--border-default)] flex flex-col overflow-hidden"
      style={{ backgroundColor: "var(--canvas)" }}
    >
      <AnimatePresence mode="wait">
        {/* ── Collapsed: icon rail ── */}
        {!expanded ? (
          <motion.div
            key="collapsed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.12 }}
            className="flex flex-col items-center pt-2 gap-1"
            style={{ width: "48px" }}
          >
            {RIGHT_RAIL_MODES.map((m) => (
              <button
                key={m.key}
                onClick={() => {
                  setMode(m.key);
                  setExpanded(true);
                }}
                title={m.label}
                className="flex items-center justify-center rounded-[var(--radius-md)] transition-colors cursor-pointer"
                style={{
                  width: "36px",
                  height: "36px",
                  backgroundColor: mode === m.key ? "var(--subtle)" : "transparent",
                  color:
                    mode === m.key ? "var(--text-primary)" : "var(--text-muted)",
                }}
              >
                <m.icon size={16} />
              </button>
            ))}
          </motion.div>
        ) : (
          /* ── Expanded: full panel ── */
          <motion.div
            key="expanded"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15, delay: 0.08 }}
            className="flex flex-col h-full overflow-hidden"
            style={{ width: "320px" }}
          >
            {/* Header */}
            <div
              className="flex items-center gap-2 shrink-0 border-b border-[var(--border-default)]"
              style={{
                height: "48px",
                paddingLeft: "var(--space-4)",
                paddingRight: "var(--space-3)",
              }}
            >
              <span
                className="font-sans font-medium text-[var(--text-primary)] flex-1 truncate"
                style={{ fontSize: "var(--text-body-sm)" }}
              >
                {RIGHT_RAIL_MODES.find((m) => m.key === mode)?.label}
              </span>

              {/* Mode switcher chips */}
              <div className="flex items-center gap-0.5">
                {RIGHT_RAIL_MODES.map((m) => (
                  <button
                    key={m.key}
                    onClick={() => setMode(m.key)}
                    title={m.label}
                    className="flex items-center justify-center rounded-[var(--radius-sm)] transition-colors cursor-pointer"
                    style={{
                      width: "24px",
                      height: "24px",
                      backgroundColor:
                        mode === m.key ? "var(--elevated)" : "transparent",
                      color:
                        mode === m.key ? "var(--text-primary)" : "var(--text-muted)",
                    }}
                  >
                    <m.icon size={12} />
                  </button>
                ))}
                {/* Separator */}
                <div
                  className="mx-1"
                  style={{
                    width: "1px",
                    height: "16px",
                    backgroundColor: "var(--border-default)",
                  }}
                />
                {/* Close */}
                <button
                  onClick={() => setExpanded(false)}
                  className="flex items-center justify-center rounded-[var(--radius-sm)] transition-colors cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    color: "var(--text-muted)",
                  }}
                >
                  <X size={13} />
                </button>
              </div>
            </div>

            {/* Panel content */}
            <div className="flex-1 overflow-hidden flex flex-col">
              {mode === "agent" ? (
                <AgentConsolePanel />
              ) : (
                <SimpleRailPanel mode={mode} />
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.aside>
  );
}

/* ══════════════════════════════════════════════════════════
   Main Tab Content Panels
   ══════════════════════════════════════════════════════════ */

/* Activity */
function ActivityPanel() {
  return (
    <div className="max-w-3xl mx-auto" style={{ padding: "var(--space-6)" }}>
      <div
        className="rounded-[var(--radius-lg)] border border-[var(--border-default)] overflow-hidden"
        style={{ backgroundColor: "var(--surface)" }}
      >
        {MOCK_ACTIVITY.map((item, i) => (
          <React.Fragment key={i}>
            <ActivityEvent
              actor={item.actor}
              verb={item.verb}
              target={item.target}
              workspaceId={item.workspaceId}
              snapshotId={"snapshotId" in item ? String((item as Record<string, unknown>).snapshotId) : undefined}
              time={item.time}
            />
            {i < MOCK_ACTIVITY.length - 1 && <Divider />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

/* Tasks */
function TasksPanel() {
  return (
    <div className="max-w-3xl mx-auto" style={{ padding: "var(--space-6)" }}>
      {/* Filter bar */}
      <div
        className="flex items-center gap-2 mb-4"
        style={{ marginBottom: "var(--space-4)" }}
      >
        <button
          className="flex items-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--border-default)] bg-[var(--subtle)] transition-colors hover:border-[var(--border-strong)] cursor-pointer"
          style={{
            height: "32px",
            paddingLeft: "var(--space-3)",
            paddingRight: "var(--space-3)",
            fontSize: "var(--text-caption)",
            color: "var(--text-secondary)",
          }}
        >
          <Filter size={12} />
          筛选
        </button>
        <div className="flex-1" />
        {["全部", "进行中", "待确认", "已完成"].map((label) => (
          <button
            key={label}
            className={cn(
              "rounded-[var(--radius-sm)] font-sans cursor-pointer transition-colors",
              label === "全部"
                ? "text-[var(--text-primary)]"
                : "text-[var(--text-muted)] hover:text-[var(--text-secondary)]"
            )}
            style={{
              height: "28px",
              paddingLeft: "var(--space-2)",
              paddingRight: "var(--space-2)",
              fontSize: "var(--text-caption)",
              backgroundColor: label === "全部" ? "var(--subtle)" : "transparent",
              border: label === "全部" ? "1px solid var(--border-default)" : "none",
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Task cards */}
      <div className="space-y-2">
        {MOCK_TASK_ITEMS.map((task) => (
          <TaskCard
            key={task.id}
            actor={task.actor}
            action={task.action}
            target={task.target}
            state={task.state}
            time={task.time}
            onConfirm={task.state === "pending-confirm" ? () => {} : undefined}
          />
        ))}
      </div>
    </div>
  );
}

/* Files */
function FilesPanel() {
  return (
    <div className="max-w-3xl mx-auto" style={{ padding: "var(--space-6)" }}>
      <div
        className="rounded-[var(--radius-lg)] border border-[var(--border-default)] overflow-hidden"
        style={{ backgroundColor: "var(--surface)" }}
      >
        {/* Column header */}
        <div
          className="flex items-center border-b border-[var(--border-subtle)]"
          style={{
            height: "36px",
            paddingLeft: "var(--space-4)",
            paddingRight: "var(--space-4)",
          }}
        >
          {["文件名", "大小", "修改时间"].map((col, i) => (
            <span
              key={col}
              className="font-mono text-[var(--text-muted)] uppercase tracking-wider"
              style={{
                fontSize: "var(--text-micro)",
                flex: i === 0 ? 1 : "none",
                width: i > 0 ? "80px" : undefined,
              }}
            >
              {col}
            </span>
          ))}
          <span style={{ width: "36px" }} />
        </div>
        {MOCK_FILES.map((file, i) => {
          const Icon = FILE_ICON[file.type] ?? FileText;
          return (
            <React.Fragment key={i}>
              <div
                className="flex items-center hover:bg-[var(--subtle)] transition-colors group cursor-pointer"
                style={{
                  height: "44px",
                  paddingLeft: "var(--space-4)",
                  paddingRight: "var(--space-4)",
                }}
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <Icon
                    size={15}
                    className="shrink-0"
                    style={{ color: FILE_COLOR[file.type] }}
                  />
                  <span
                    className="font-sans text-[var(--text-primary)] truncate"
                    style={{ fontSize: "var(--text-body-sm)" }}
                  >
                    {file.name}
                  </span>
                </div>
                <span
                  className="font-mono text-[var(--text-muted)] shrink-0"
                  style={{ fontSize: "var(--text-caption)", width: "80px" }}
                >
                  {file.size}
                </span>
                <span
                  className="font-mono text-[var(--text-muted)] shrink-0"
                  style={{ fontSize: "var(--text-caption)", width: "80px" }}
                >
                  {file.modified}
                </span>
                <div className="flex items-center justify-end" style={{ width: "36px" }}>
                  <button className="opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-[var(--text-muted)] hover:text-[var(--text-secondary)]">
                    <MoreHorizontal size={14} />
                  </button>
                </div>
              </div>
              {i < MOCK_FILES.length - 1 && <Divider />}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

/* Snapshots */
function SnapshotsPanel() {
  return (
    <div
      className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4"
      style={{ padding: "var(--space-6)" }}
    >
      {MOCK_SNAPSHOTS.map((snap, i) => (
        <SnapshotCard key={i} {...snap} />
      ))}
    </div>
  );
}

/* Members */
const STATUS_COLOR: Record<string, string> = {
  online: "var(--semantic-success)",
  away: "var(--semantic-warning)",
  offline: "var(--border-strong)",
};

function MembersPanel() {
  return (
    <div className="max-w-3xl mx-auto" style={{ padding: "var(--space-6)" }}>
      {/* Invite bar */}
      <div className="flex items-center justify-between mb-4">
        <span
          className="font-sans text-[var(--text-secondary)]"
          style={{ fontSize: "var(--text-body-sm)" }}
        >
          5 名成员
        </span>
        <button
          className="flex items-center gap-1.5 rounded-[var(--radius-md)] font-sans cursor-pointer transition-opacity hover:opacity-90"
          style={{
            height: "32px",
            paddingLeft: "var(--space-3)",
            paddingRight: "var(--space-3)",
            fontSize: "var(--text-body-sm)",
            backgroundColor: "var(--accent-apple)",
            color: "var(--text-on-accent)",
          }}
        >
          <UserPlus size={13} />
          邀请成员
        </button>
      </div>
      <div
        className="rounded-[var(--radius-lg)] border border-[var(--border-default)] overflow-hidden"
        style={{ backgroundColor: "var(--surface)" }}
      >
        {MOCK_MEMBERS.map((member, i) => (
          <React.Fragment key={i}>
            <div
              className="flex items-center gap-3 hover:bg-[var(--subtle)] transition-colors"
              style={{
                height: "52px",
                paddingLeft: "var(--space-4)",
                paddingRight: "var(--space-4)",
              }}
            >
              <div className="relative shrink-0">
                <Avatar name={member.name} size="md" />
                <span
                  className="absolute bottom-0 right-0 rounded-full border-2 border-[var(--surface)]"
                  style={{
                    width: "9px",
                    height: "9px",
                    backgroundColor: STATUS_COLOR[member.status],
                  }}
                />
              </div>
              <div className="flex-1 min-w-0">
                <div
                  className="font-sans text-[var(--text-primary)]"
                  style={{ fontSize: "var(--text-body-sm)" }}
                >
                  {member.name}
                </div>
                <div
                  className="font-mono text-[var(--text-muted)]"
                  style={{ fontSize: "var(--text-micro)" }}
                >
                  {member.email}
                </div>
              </div>
              <Tag>{member.role}</Tag>
              <button className="cursor-pointer text-[var(--text-muted)] hover:text-[var(--text-secondary)] transition-colors">
                <MoreHorizontal size={14} />
              </button>
            </div>
            {i < MOCK_MEMBERS.length - 1 && <Divider />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

/* Agents */
function AgentsPanel() {
  const running = MOCK_AGENTS.filter((a) => a.status === "running");
  const idle = MOCK_AGENTS.filter((a) => a.status === "idle");
  return (
    <div className="max-w-3xl mx-auto" style={{ padding: "var(--space-6)" }}>
      {/* Running agents */}
      <div style={{ marginBottom: "var(--space-6)" }}>
        <div className="flex items-center gap-2 mb-3">
          <span
            className="font-mono uppercase tracking-wider text-[var(--text-muted)]"
            style={{ fontSize: "var(--text-micro)" }}
          >
            运行中
          </span>
          <span
            className="w-1.5 h-1.5 rounded-full animate-pulse"
            style={{ backgroundColor: "var(--accent-apple)" }}
          />
          <span
            className="font-mono text-[var(--text-muted)]"
            style={{ fontSize: "var(--text-micro)" }}
          >
            {running.length}
          </span>
        </div>
        <div className="space-y-2">
          {running.map((agent) => (
            <div
              key={agent.id}
              className="flex items-center gap-3 rounded-[var(--radius-lg)] border border-[var(--border-default)]"
              style={{
                padding: "var(--space-3) var(--space-4)",
                backgroundColor: "var(--surface)",
              }}
            >
              <AgentBadge role={agent.role} />
              <div className="flex-1 min-w-0">
                <div
                  className="font-sans text-[var(--text-secondary)] truncate"
                  style={{ fontSize: "var(--text-body-sm)" }}
                >
                  {agent.task}
                </div>
                <div
                  className="font-mono text-[var(--text-muted)] mt-0.5"
                  style={{ fontSize: "var(--text-micro)" }}
                >
                  已运行 {agent.since}
                </div>
              </div>
              <StatusPill status="running" />
            </div>
          ))}
        </div>
      </div>

      {/* Idle agents */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <span
            className="font-mono uppercase tracking-wider text-[var(--text-muted)]"
            style={{ fontSize: "var(--text-micro)" }}
          >
            空闲
          </span>
          <span
            className="font-mono text-[var(--text-muted)]"
            style={{ fontSize: "var(--text-micro)" }}
          >
            {idle.length}
          </span>
        </div>
        <div
          className="rounded-[var(--radius-lg)] border border-[var(--border-default)] overflow-hidden"
          style={{ backgroundColor: "var(--surface)" }}
        >
          {idle.map((agent, i) => (
            <React.Fragment key={agent.id}>
              <div
                className="flex items-center gap-3"
                style={{
                  height: "44px",
                  paddingLeft: "var(--space-4)",
                  paddingRight: "var(--space-4)",
                }}
              >
                <AgentBadge role={agent.role} />
                <span
                  className="font-mono text-[var(--text-muted)]"
                  style={{ fontSize: "var(--text-caption)" }}
                >
                  待命
                </span>
                <div className="flex-1" />
                <button
                  className="font-sans cursor-pointer transition-colors text-[var(--text-muted)] hover:text-[var(--text-primary)]"
                  style={{ fontSize: "var(--text-caption)" }}
                >
                  指派任务
                </button>
              </div>
              {i < idle.length - 1 && <Divider />}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

/* Settings */
function SettingsPanel() {
  return (
    <div className="max-w-2xl mx-auto" style={{ padding: "var(--space-6)" }}>
      <div
        className="rounded-[var(--radius-lg)] border border-[var(--border-default)]"
        style={{ backgroundColor: "var(--surface)" }}
      >
        {[
          { label: "工作区名称", value: "Personal Workspace", type: "text" },
          { label: "数据区域", value: "cn-east-1", type: "select" },
          { label: "模型备案号", value: "沪AI-2024-0042", type: "text" },
          { label: "审计留存期限", value: "180 天", type: "select" },
        ].map((field, i, arr) => (
          <React.Fragment key={field.label}>
            <div
              className="flex items-center justify-between"
              style={{
                padding: "var(--space-4)",
                minHeight: "60px",
              }}
            >
              <div>
                <div
                  className="font-sans text-[var(--text-primary)]"
                  style={{ fontSize: "var(--text-body-sm)" }}
                >
                  {field.label}
                </div>
              </div>
              <input
                type="text"
                defaultValue={field.value}
                readOnly={field.type === "select"}
                className="text-right rounded-[var(--radius-md)] border border-[var(--border-default)] font-sans bg-[var(--subtle)] text-[var(--text-secondary)] focus:outline-none focus:border-[var(--border-strong)] focus:text-[var(--text-primary)] transition-colors"
                style={{
                  width: "200px",
                  height: "32px",
                  paddingLeft: "var(--space-3)",
                  paddingRight: "var(--space-3)",
                  fontSize: "var(--text-body-sm)",
                  fontFamily: "var(--font-mono)",
                }}
              />
            </div>
            {i < arr.length - 1 && <Divider />}
          </React.Fragment>
        ))}
      </div>
      <div className="flex justify-end mt-4">
        <button
          className="flex items-center gap-2 rounded-[var(--radius-md)] font-sans cursor-pointer transition-opacity hover:opacity-90"
          style={{
            height: "36px",
            paddingLeft: "var(--space-4)",
            paddingRight: "var(--space-4)",
            fontSize: "var(--text-body-sm)",
            backgroundColor: "var(--text-primary)",
            color: "var(--text-inverse)",
          }}
        >
          保存设置
        </button>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   Workspace Top Bar
   ══════════════════════════════════════════════════════════ */

function WorkspaceTopBar({ spaceName }: { spaceName: string }) {
  const isTeam = spaceName.startsWith("team");
  return (
    <div
      className="flex items-center shrink-0 border-b border-[var(--border-subtle)]"
      style={{
        height: "52px",
        backgroundColor: "var(--canvas)",
        paddingLeft: "var(--space-6)",
        paddingRight: "var(--space-4)",
      }}
    >
      {/* Left */}
      <div className="flex items-center gap-2.5 flex-1 min-w-0">
        <div
          className="flex items-center justify-center rounded-[var(--radius-md)] shrink-0"
          style={{
            width: "28px",
            height: "28px",
            backgroundColor: "var(--elevated)",
            border: "1px solid var(--border-default)",
          }}
        >
          {isTeam ? (
            <Users size={14} className="text-[var(--text-secondary)]" />
          ) : (
            <Home size={14} className="text-[var(--text-secondary)]" />
          )}
        </div>
        <span
          className="font-sans font-medium text-[var(--text-primary)] truncate"
          style={{ fontSize: "var(--text-body-sm)" }}
        >
          {spaceName === "personal"
            ? "Personal Workspace"
            : spaceName === "team"
            ? "Team Workspace"
            : spaceName}
        </span>
        <Tag>{isTeam ? "Team" : "Personal"}</Tag>

        {/* Separator + stats */}
        <div
          className="mx-2 shrink-0"
          style={{
            width: "1px",
            height: "16px",
            backgroundColor: "var(--border-default)",
          }}
        />
        <div className="hidden lg:flex items-center gap-3">
          {[
            { label: "成员", val: "5" },
            { label: "代理运行", val: "2" },
            { label: "任务", val: "12" },
          ].map((s) => (
            <span
              key={s.label}
              className="font-sans text-[var(--text-muted)]"
              style={{ fontSize: "var(--text-caption)" }}
            >
              <span
                className="font-mono text-[var(--text-secondary)]"
                style={{ fontSize: "var(--text-caption)" }}
              >
                {s.val}
              </span>{" "}
              {s.label}
            </span>
          ))}
        </div>
      </div>

      {/* Right: actions */}
      <div className="flex items-center gap-2">
        <button
          className="hidden sm:flex items-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--border-default)] font-sans cursor-pointer transition-colors hover:border-[var(--border-strong)] hover:text-[var(--text-primary)] text-[var(--text-secondary)]"
          style={{
            height: "32px",
            paddingLeft: "var(--space-3)",
            paddingRight: "var(--space-3)",
            fontSize: "var(--text-caption)",
          }}
        >
          <UserPlus size={13} />
          邀请
        </button>
        <button
          className="hidden sm:flex items-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--border-default)] font-sans cursor-pointer transition-colors hover:border-[var(--border-strong)] hover:text-[var(--text-primary)] text-[var(--text-secondary)]"
          style={{
            height: "32px",
            paddingLeft: "var(--space-3)",
            paddingRight: "var(--space-3)",
            fontSize: "var(--text-caption)",
          }}
        >
          <Share2 size={13} />
          分享
        </button>
        <button
          className="flex items-center justify-center rounded-[var(--radius-md)] border border-[var(--border-default)] cursor-pointer transition-colors hover:bg-[var(--subtle)] text-[var(--text-secondary)]"
          style={{ width: "32px", height: "32px" }}
        >
          <MoreHorizontal size={14} />
        </button>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   Compliance Strip (24px)
   ══════════════════════════════════════════════════════════ */

const COMPLIANCE_FIELDS = [
  { icon: Server, label: "数据区域", value: "cn-east-1" },
  { icon: Globe, label: "跨境", value: "否" },
  { icon: Shield, label: "模型备案", value: "沪AI-2024-0042" },
  { icon: Clock, label: "审计留存", value: "180 天" },
];

function WorkspaceComplianceStrip() {
  return (
    <div
      className="flex items-center shrink-0 border-b border-[var(--border-subtle)]"
      style={{
        height: "28px",
        backgroundColor: "var(--subtle)",
        paddingLeft: "var(--space-6)",
        paddingRight: "var(--space-6)",
        gap: "0",
      }}
    >
      {COMPLIANCE_FIELDS.map((field, i) => (
        <React.Fragment key={field.label}>
          <div className="flex items-center gap-1.5">
            <field.icon
              size={10}
              className="text-[var(--text-muted)] shrink-0"
            />
            <span
              className="font-mono text-[var(--text-muted)]"
              style={{ fontSize: "var(--text-micro)" }}
            >
              {field.label}:
            </span>
            <span
              className="font-mono text-[var(--text-secondary)]"
              style={{ fontSize: "var(--text-micro)" }}
            >
              {field.value}
            </span>
          </div>
          {i < COMPLIANCE_FIELDS.length - 1 && (
            <div
              className="mx-3 shrink-0"
              style={{
                width: "1px",
                height: "12px",
                backgroundColor: "var(--border-default)",
              }}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   Workspace View Tabs (48px)
   ══════════════════════════════════════════════════════════ */

function WorkspaceViewTabs({
  active,
  onChange,
}: {
  active: MainTab;
  onChange: (t: MainTab) => void;
}) {
  return (
    <div
      className="flex items-end shrink-0 border-b border-[var(--border-default)] overflow-x-auto"
      style={{
        height: "48px",
        backgroundColor: "var(--canvas)",
        paddingLeft: "var(--space-6)",
        paddingRight: "var(--space-6)",
        gap: "0",
      }}
    >
      {MAIN_TABS.map((tab) => {
        const isActive = active === tab.key;
        return (
          <button
            key={tab.key}
            onClick={() => onChange(tab.key)}
            className={cn(
              "relative flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer font-sans",
              isActive ? "text-[var(--text-primary)]" : "text-[var(--text-muted)] hover:text-[var(--text-secondary)]"
            )}
            style={{
              height: "48px",
              paddingLeft: "var(--space-3)",
              paddingRight: "var(--space-3)",
              fontSize: "var(--text-body-sm)",
            }}
          >
            <span>{tab.label}</span>
            {tab.count != null && (
              <span
                className="font-mono"
                style={{
                  fontSize: "var(--text-micro)",
                  color: isActive ? "var(--text-muted)" : "var(--text-muted)",
                  opacity: isActive ? 1 : 0.6,
                }}
              >
                · {tab.count}
              </span>
            )}
            {/* Underline indicator */}
            {isActive && (
              <motion.div
                layoutId="workspace-tab-underline"
                className="absolute bottom-0 left-0 right-0"
                style={{ height: "1.5px", backgroundColor: "var(--text-primary)" }}
                transition={{ type: "spring", bounce: 0.15, duration: 0.35 }}
              />
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   WorkspaceConsole — Main Export
   ══════════════════════════════════════════════════════════ */

export function WorkspaceConsole() {
  const [activeSpace, setActiveSpace] = useState("personal");
  const [activeNav, setActiveNav] = useState("library");
  const [activeTab, setActiveTab] = useState<MainTab>("activity");
  const [rightMode, setRightMode] = useState<RightMode>("agent");
  const [rightExpanded, setRightExpanded] = useState(true);

  const user = { name: "张伟", email: "zhangwei@vibehub.dev" };

  return (
    <div
      className="flex h-screen overflow-hidden"
      style={{ backgroundColor: "var(--canvas)" }}
    >
      {/* ── Left Rail (220px fixed) ── */}
      <WorkspaceLeftRail
        activeNav={activeNav}
        setActiveNav={setActiveNav}
        activeSpace={activeSpace}
        setActiveSpace={setActiveSpace}
        user={user}
      />

      {/* ── Main (fluid) ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Workspace Top Bar */}
        <WorkspaceTopBar spaceName={activeSpace} />

        {/* Compliance Strip */}
        <WorkspaceComplianceStrip />

        {/* View Tabs */}
        <WorkspaceViewTabs active={activeTab} onChange={setActiveTab} />

        {/* Content (independently scrollable) */}
        <div
          className="flex-1 overflow-y-auto"
          style={{ backgroundColor: "var(--canvas)" }}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15 }}
              className="min-h-full"
            >
              {activeTab === "activity" && <ActivityPanel />}
              {activeTab === "tasks" && <TasksPanel />}
              {activeTab === "files" && <FilesPanel />}
              {activeTab === "snapshots" && <SnapshotsPanel />}
              {activeTab === "members" && <MembersPanel />}
              {activeTab === "agents" && <AgentsPanel />}
              {activeTab === "settings" && <SettingsPanel />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* ── Right Rail (collapsible: 48px ↔ 320px) ── */}
      <WorkspaceRightRail
        mode={rightMode}
        setMode={setRightMode}
        expanded={rightExpanded}
        setExpanded={setRightExpanded}
      />
    </div>
  );
}
