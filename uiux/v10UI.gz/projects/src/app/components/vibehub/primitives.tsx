import React, { forwardRef, useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Check,
  ChevronDown,
  Eye,
  EyeOff,
  Search,
  X,
  AlertTriangle,
  CheckCircle2,
  Info,
  AlertCircle,
  Loader2,
} from "lucide-react";

/* ─── cn helper ─── */
function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

/* ═══════════════════════════════════════════════════════
   A-1. Button
   ═══════════════════════════════════════════════════════ */
type ButtonVariant = "primary" | "secondary" | "ghost" | "destructive" | "apple";
type Size = "sm" | "md" | "lg";

const btnSizeMap: Record<Size, string> = {
  sm: "h-7 px-3 text-[length:var(--text-caption)] gap-1.5 rounded-[var(--radius-sm)]",
  md: "h-8 px-4 text-[length:var(--text-body-sm)] gap-2 rounded-[var(--radius-md)]",
  lg: "h-10 px-5 text-[length:var(--text-body)] gap-2 rounded-[var(--radius-md)]",
};

const btnVariantMap: Record<ButtonVariant, string> = {
  primary:
    "bg-[var(--text-primary)] text-[var(--text-inverse)] hover:opacity-90 active:opacity-80",
  apple:
    "bg-[var(--accent-apple)] text-[var(--text-on-accent)] hover:bg-[var(--accent-apple-hover)] active:opacity-90",
  secondary:
    "bg-transparent border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-strong)] active:bg-[var(--subtle)]",
  ghost:
    "bg-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)] active:bg-[var(--border-default)]",
  destructive:
    "bg-[var(--semantic-error)] text-[var(--text-on-accent)] hover:opacity-90 active:opacity-80",
};

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: Size;
}
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", size = "md", className, disabled, children, ...props }, ref) => (
    <button
      ref={ref}
      disabled={disabled}
      className={cn(
        "inline-flex items-center justify-center font-sans font-medium transition-all duration-150 cursor-pointer select-none whitespace-nowrap",
        "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--border-focus-ring)]",
        "disabled:opacity-40 disabled:pointer-events-none",
        btnSizeMap[size],
        btnVariantMap[variant],
        className
      )}
      {...props}
    >
      {children}
    </button>
  )
);
Button.displayName = "Button";

/* ═══════════════════════════════════════════════════════
   A-2. IconButton
   ═══════════════════════════════════════════════════════ */
const iconBtnSize: Record<Size, string> = {
  sm: "w-7 h-7",
  md: "w-8 h-8",
  lg: "w-10 h-10",
};
interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  size?: Size;
}
export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(
  ({ size = "md", className, children, ...props }, ref) => (
    <button
      ref={ref}
      className={cn(
        "inline-flex items-center justify-center rounded-[var(--radius-md)] transition-colors duration-150 cursor-pointer",
        "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)]",
        "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--border-focus-ring)]",
        "disabled:opacity-40 disabled:pointer-events-none",
        iconBtnSize[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  )
);
IconButton.displayName = "IconButton";

/* ═══════════════════════════════════════════════════════
   A-3. Input
   ═══════════════════════════════════════════════════════ */
interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  size?: Size;
  leftIcon?: React.ReactNode;
  inputType?: "text" | "search" | "password";
}
const inputSizeMap: Record<Size, string> = {
  sm: "h-7 text-[length:var(--text-caption)] px-2",
  md: "h-8 text-[length:var(--text-body-sm)] px-3",
  lg: "h-10 text-[length:var(--text-body)] px-4",
};
export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ size = "md", leftIcon, inputType = "text", className, ...props }, ref) => {
    const [showPw, setShowPw] = useState(false);
    const type = inputType === "password" ? (showPw ? "text" : "password") : inputType;
    return (
      <div className="relative inline-flex items-center w-full">
        {leftIcon && (
          <span className="absolute left-2 text-[var(--text-muted)] pointer-events-none">
            {leftIcon}
          </span>
        )}
        <input
          ref={ref}
          type={type}
          className={cn(
            "w-full bg-transparent border border-[var(--border-default)] rounded-[var(--radius-md)] text-[var(--text-primary)] placeholder:text-[var(--text-muted)] font-sans transition-colors",
            "focus:outline-none focus:ring-1 focus:ring-[var(--border-focus-ring)] focus:border-[var(--border-strong)]",
            "disabled:opacity-40",
            leftIcon ? "pl-8" : "",
            inputType === "password" ? "pr-8" : "",
            inputSizeMap[size],
            className
          )}
          {...props}
        />
        {inputType === "password" && (
          <button
            type="button"
            onClick={() => setShowPw(!showPw)}
            className="absolute right-2 text-[var(--text-muted)] hover:text-[var(--text-secondary)] cursor-pointer"
          >
            {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
          </button>
        )}
      </div>
    );
  }
);
Input.displayName = "Input";

/* ═══════════════════════════════════════════════════════
   A-4. Textarea
   ═══════════════════════════════════════════════════════ */
export const Textarea = forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement>
>(({ className, ...props }, ref) => (
  <textarea
    ref={ref}
    rows={3}
    className={cn(
      "w-full bg-transparent border border-[var(--border-default)] rounded-[var(--radius-md)] px-3 py-2 text-[length:var(--text-body-sm)] text-[var(--text-primary)] placeholder:text-[var(--text-muted)] font-sans transition-colors resize-y",
      "focus:outline-none focus:ring-1 focus:ring-[var(--border-focus-ring)] focus:border-[var(--border-strong)]",
      "disabled:opacity-40",
      className
    )}
    {...props}
  />
));
Textarea.displayName = "Textarea";

/* ═══════════════════════════════════════════════════════
   A-5. Select (Linear-style)
   ═══════════════════════════════════════════════════════ */
interface SelectOption {
  value: string;
  label: string;
}
interface SelectProps {
  options: SelectOption[];
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  size?: Size;
  disabled?: boolean;
}
export function Select({
  options,
  value,
  onChange,
  placeholder = "选择...",
  size = "md",
  disabled,
}: SelectProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const selected = options.find((o) => o.value === value);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative inline-flex w-full">
      <button
        disabled={disabled}
        onClick={() => !disabled && setOpen(!open)}
        className={cn(
          "w-full flex items-center justify-between bg-transparent border border-[var(--border-default)] rounded-[var(--radius-md)] font-sans transition-colors cursor-pointer",
          "hover:border-[var(--border-strong)] focus:outline-none focus:ring-1 focus:ring-[var(--border-focus-ring)]",
          "disabled:opacity-40 disabled:pointer-events-none",
          inputSizeMap[size]
        )}
      >
        <span className={selected ? "text-[var(--text-primary)]" : "text-[var(--text-muted)]"}>
          {selected ? selected.label : placeholder}
        </span>
        <ChevronDown size={14} className="text-[var(--text-muted)] ml-2" />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.12 }}
            className="absolute z-50 top-full left-0 w-full mt-1 bg-[var(--elevated)] border border-[var(--border-default)] rounded-[var(--radius-md)] py-1 shadow-[var(--shadow-modal)]"
          >
            {options.map((opt) => (
              <button
                key={opt.value}
                onClick={() => {
                  onChange?.(opt.value);
                  setOpen(false);
                }}
                className={cn(
                  "w-full text-left px-3 py-1.5 text-[length:var(--text-body-sm)] font-sans cursor-pointer transition-colors",
                  opt.value === value
                    ? "text-[var(--text-primary)] bg-[var(--subtle)]"
                    : "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)]"
                )}
              >
                {opt.label}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   A-6. Checkbox
   ═══════════════════════════════════════════════════════ */
interface CheckboxProps {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  label?: string;
  disabled?: boolean;
}
export function Checkbox({ checked = false, onChange, label, disabled }: CheckboxProps) {
  return (
    <label
      className={cn(
        "inline-flex items-center gap-2 cursor-pointer select-none",
        disabled && "opacity-40 pointer-events-none"
      )}
    >
      <button
        role="checkbox"
        aria-checked={checked}
        onClick={() => onChange?.(!checked)}
        className={cn(
          "w-4 h-4 rounded-[var(--radius-xs)] border transition-all duration-150 flex items-center justify-center",
          checked
            ? "bg-[var(--text-primary)] border-[var(--text-primary)]"
            : "bg-transparent border-[var(--border-strong)] hover:border-[var(--text-secondary)]"
        )}
      >
        {checked && <Check size={10} className="text-[var(--text-inverse)]" />}
      </button>
      {label && <span className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)]">{label}</span>}
    </label>
  );
}

/* ═══════════════════════════════════════════════════════
   A-7. Radio
   ═══════════════════════════════════════════════════════ */
interface RadioProps {
  checked?: boolean;
  onChange?: () => void;
  label?: string;
  disabled?: boolean;
}
export function Radio({ checked = false, onChange, label, disabled }: RadioProps) {
  return (
    <label
      className={cn(
        "inline-flex items-center gap-2 cursor-pointer select-none",
        disabled && "opacity-40 pointer-events-none"
      )}
    >
      <button
        role="radio"
        aria-checked={checked}
        onClick={onChange}
        className={cn(
          "w-4 h-4 rounded-full border transition-all duration-150 flex items-center justify-center",
          checked
            ? "border-[var(--text-primary)]"
            : "border-[var(--border-strong)] hover:border-[var(--text-secondary)]"
        )}
      >
        {checked && <div className="w-2 h-2 rounded-full bg-[var(--text-primary)]" />}
      </button>
      {label && <span className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)]">{label}</span>}
    </label>
  );
}

/* ═══════════════════════════════════════════════════════
   A-8. Toggle
   ═══════════════════════════════════════════════════════ */
interface ToggleProps {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
}
export function Toggle({ checked = false, onChange, disabled }: ToggleProps) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange?.(!checked)}
      className={cn(
        "w-9 h-5 rounded-full border transition-all duration-200 relative cursor-pointer",
        "disabled:opacity-40 disabled:pointer-events-none",
        checked
          ? "bg-[var(--text-primary)] border-[var(--text-primary)]"
          : "bg-transparent border-[var(--border-strong)]"
      )}
    >
      <div
        className={cn(
          "w-3.5 h-3.5 rounded-full absolute top-[2px] transition-all duration-200",
          checked
            ? "left-[18px] bg-[var(--text-inverse)]"
            : "left-[2px] bg-[var(--text-muted)]"
        )}
      />
    </button>
  );
}

/* ═══════════════════════════════════════════════════════
   A-9. Avatar & AvatarStack
   ═══════════════════════════════════════════════════════ */
type AvatarSize = "sm" | "md" | "lg" | "xl";
const avatarSizeMap: Record<AvatarSize, string> = {
  sm: "w-5 h-5 text-[length:var(--text-micro)]",
  md: "w-7 h-7 text-[length:var(--text-caption)]",
  lg: "w-10 h-10 text-[length:var(--text-body-sm)]",
  xl: "w-16 h-16 text-[length:var(--text-body-lg)]",
};
interface AvatarProps {
  src?: string;
  name: string;
  size?: AvatarSize;
  className?: string;
}
export function Avatar({ src, name, size = "md", className }: AvatarProps) {
  const initials = name
    .split(" ")
    .map((s) => s[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
  return (
    <div
      className={cn(
        "rounded-full bg-[var(--elevated)] border border-[var(--border-default)] flex items-center justify-center font-mono text-[var(--text-secondary)] overflow-hidden shrink-0",
        avatarSizeMap[size],
        className
      )}
    >
      {src ? (
        <img src={src} alt={name} className="w-full h-full object-cover" />
      ) : (
        initials
      )}
    </div>
  );
}

interface AvatarStackProps {
  avatars: { name: string; src?: string }[];
  size?: AvatarSize;
  max?: number;
}
export function AvatarStack({ avatars, size = "md", max = 4 }: AvatarStackProps) {
  const visible = avatars.slice(0, max);
  const overflow = avatars.length - max;
  return (
    <div className="flex -space-x-1.5">
      {visible.map((a, i) => (
        <Avatar key={i} {...a} size={size} className="ring-2 ring-[var(--canvas)]" />
      ))}
      {overflow > 0 && (
        <div
          className={cn(
            "rounded-full bg-[var(--elevated)] border border-[var(--border-default)] flex items-center justify-center font-mono text-[var(--text-muted)] ring-2 ring-[var(--canvas)]",
            avatarSizeMap[size]
          )}
        >
          +{overflow}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   A-10. Badge
   ═══════════════════════════════════════════════════════ */
type Tone = "neutral" | "apple" | "violet" | "cyan" | "success" | "warning" | "error";
type BadgeStyle = "solid" | "subtle";

const toneColors: Record<Tone, { solid: string; subtle: string }> = {
  neutral: {
    solid: "bg-[var(--text-secondary)] text-[var(--text-inverse)]",
    subtle: "bg-[var(--subtle)] text-[var(--text-secondary)] border border-[var(--border-default)]",
  },
  apple: {
    solid: "bg-[var(--accent-apple)] text-[var(--text-on-accent)]",
    subtle: "bg-[var(--accent-apple-subtle)] text-[var(--accent-apple)] border border-[var(--accent-apple-subtle)]",
  },
  violet: {
    solid: "bg-[var(--accent-violet)] text-[var(--text-inverse)]",
    subtle: "bg-[var(--accent-violet-subtle)] text-[var(--accent-violet)] border border-[var(--accent-violet-subtle)]",
  },
  cyan: {
    solid: "bg-[var(--accent-cyan)] text-[var(--text-inverse)]",
    subtle: "bg-[var(--accent-cyan-subtle)] text-[var(--accent-cyan)] border border-[var(--accent-cyan-subtle)]",
  },
  success: {
    solid: "bg-[var(--semantic-success)] text-[var(--text-inverse)]",
    subtle: "bg-[var(--semantic-success-subtle)] text-[var(--semantic-success)] border border-[var(--semantic-success-subtle)]",
  },
  warning: {
    solid: "bg-[var(--semantic-warning)] text-[var(--text-inverse)]",
    subtle: "bg-[var(--semantic-warning-subtle)] text-[var(--semantic-warning)] border border-[var(--semantic-warning-subtle)]",
  },
  error: {
    solid: "bg-[var(--semantic-error)] text-[var(--text-inverse)]",
    subtle: "bg-[var(--semantic-error-subtle)] text-[var(--semantic-error)] border border-[var(--semantic-error-subtle)]",
  },
};

interface BadgeProps {
  children: React.ReactNode;
  tone?: Tone;
  style?: BadgeStyle;
}
export function Badge({ children, tone = "neutral", style = "subtle" }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center px-2 py-0.5 rounded-[var(--radius-pill)] text-[length:var(--text-micro)] font-medium font-sans whitespace-nowrap",
        toneColors[tone][style]
      )}
    >
      {children}
    </span>
  );
}

/* ═══════════════════════════════════════════════════════
   A-11. StatusPill
   ═══════════════════════════════════════════════════════ */
type StatusKey =
  | "draft" | "public" | "private" | "open-source" | "archived"
  | "open" | "accepted" | "declined" | "expired" | "blocked"
  | "pending" | "running" | "pending-confirm" | "done" | "failed";

const statusConfig: Record<StatusKey, { label: string; tone: Tone }> = {
  draft: { label: "草稿", tone: "neutral" },
  public: { label: "公开", tone: "success" },
  private: { label: "私密", tone: "violet" },
  "open-source": { label: "开源", tone: "cyan" },
  archived: { label: "归档", tone: "neutral" },
  open: { label: "开放", tone: "apple" },
  accepted: { label: "已接受", tone: "success" },
  declined: { label: "已婉拒", tone: "error" },
  expired: { label: "已过期", tone: "warning" },
  blocked: { label: "已屏蔽", tone: "error" },
  pending: { label: "待处理", tone: "warning" },
  running: { label: "运行中", tone: "apple" },
  "pending-confirm": { label: "待确认", tone: "warning" },
  done: { label: "已完成", tone: "success" },
  failed: { label: "失败", tone: "error" },
};

interface StatusPillProps {
  status: StatusKey;
}
export function StatusPill({ status }: StatusPillProps) {
  const config = statusConfig[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-[var(--radius-pill)] text-[length:var(--text-micro)] font-medium font-sans whitespace-nowrap",
        toneColors[config.tone].subtle
      )}
    >
      <span
        className={cn(
          "w-1.5 h-1.5 rounded-full",
          status === "running" && "animate-pulse",
          toneColors[config.tone].solid.split(" ")[0]
        )}
      />
      {config.label}
    </span>
  );
}

/* ═══════════════════════════════════════════════════════
   A-12. Tag
   ═══════════════════════════════════════════════════════ */
interface TagProps {
  children: React.ReactNode;
}
export function Tag({ children }: TagProps) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded-[var(--radius-pill)] text-[length:var(--text-micro)] font-mono text-[var(--text-secondary)] bg-[var(--subtle)] border border-[var(--border-default)] whitespace-nowrap">
      {children}
    </span>
  );
}

/* ═══════════════════════════════════════════════════════
   A-13. Tooltip
   ═══════════════════════════════════════════════════════ */
interface TooltipProps {
  content: string;
  children: React.ReactNode;
}
export function Tooltip({ content, children }: TooltipProps) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative inline-flex" onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      {children}
      <AnimatePresence>
        {show && (
          <motion.div
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 4 }}
            transition={{ duration: 0.1 }}
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2 py-1 bg-[var(--elevated)] border border-[var(--border-default)] rounded-[var(--radius-md)] text-[length:var(--text-micro)] text-[var(--text-secondary)] whitespace-nowrap z-50 pointer-events-none"
          >
            {content}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   A-14. Kbd
   ═══════════════════════════════════════════════════════ */
export function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="inline-flex items-center px-1.5 py-0.5 rounded-[var(--radius-sm)] border border-[var(--border-default)] bg-[var(--subtle)] font-mono text-[11px] text-[var(--text-muted)] leading-none">
      {children}
    </kbd>
  );
}

/* ═════════════════════════════���═════════════════════════
   A-15. Divider
   ═══════════════════════════════════════════════════════ */
interface DividerProps {
  orientation?: "horizontal" | "vertical";
}
export function Divider({ orientation = "horizontal" }: DividerProps) {
  return orientation === "horizontal" ? (
    <div className="w-full h-px bg-[var(--border-subtle)]" />
  ) : (
    <div className="h-full w-px bg-[var(--border-subtle)]" />
  );
}

/* ═══════════════════════════════════════════════════════
   A-16. Skeleton
   ═══════════════════════════════════════════════════════ */
interface SkeletonProps {
  className?: string;
}
export function Skeleton({ className }: SkeletonProps) {
  return (
    <div
      className={cn(
        "rounded-[var(--radius-md)] bg-[var(--border-default)] animate-[shimmer_1.4s_linear_infinite]",
        className
      )}
      style={{
        backgroundSize: "200% 100%",
        backgroundImage:
          "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.04) 50%, transparent 100%)",
      }}
    />
  );
}

/* ═══════════════════════════════════════════════════════
   A-17. EmptyState
   ═══════════════════════════════════════════════════════ */
interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  action?: React.ReactNode;
}
export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
      <div className="text-[var(--text-muted)]">{icon}</div>
      <h4 className="text-[length:var(--text-h4)] text-[var(--text-primary)] font-sans font-medium">{title}</h4>
      <p className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)] max-w-[280px]">{description}</p>
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   A-18. Toast
   ═══════════════════════════════════════════════════════ */
type ToastType = "success" | "info" | "warning" | "error";
const toastIcons: Record<ToastType, React.ReactNode> = {
  success: <CheckCircle2 size={16} />,
  info: <Info size={16} />,
  warning: <AlertTriangle size={16} />,
  error: <AlertCircle size={16} />,
};
const toastTone: Record<ToastType, string> = {
  success: "text-[var(--semantic-success)]",
  info: "text-[var(--semantic-info)]",
  warning: "text-[var(--semantic-warning)]",
  error: "text-[var(--semantic-error)]",
};
const toastBarTone: Record<ToastType, string> = {
  success: "bg-[var(--semantic-success)]",
  info: "bg-[var(--semantic-info)]",
  warning: "bg-[var(--semantic-warning)]",
  error: "bg-[var(--semantic-error)]",
};

interface ToastItemProps {
  type: ToastType;
  message: string;
  onDismiss: () => void;
}
export function ToastItem({ type, message, onDismiss }: ToastItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 8, scale: 0.96 }}
      className="relative bg-[var(--elevated)] border border-[var(--border-default)] rounded-[var(--radius-lg)] px-4 py-3 flex items-center gap-3 min-w-[300px] max-w-[420px] shadow-[var(--shadow-modal)] overflow-hidden"
    >
      <span className={toastTone[type]}>{toastIcons[type]}</span>
      <span className="text-[length:var(--text-body-sm)] text-[var(--text-primary)] font-sans flex-1">{message}</span>
      <button onClick={onDismiss} className="text-[var(--text-muted)] hover:text-[var(--text-secondary)] cursor-pointer">
        <X size={14} />
      </button>
      <motion.div
        initial={{ scaleX: 1 }}
        animate={{ scaleX: 0 }}
        transition={{ duration: 4, ease: "linear" }}
        className={cn("absolute bottom-0 left-0 right-0 h-0.5 origin-left", toastBarTone[type])}
      />
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════
   A-19. ConfirmDialog
   ═══════════════════════════════════════════════════════ */
interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  body: string;
  confirmText?: string;
  confirmValue?: string;
}
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  body,
  confirmText = "确认删除",
  confirmValue,
}: ConfirmDialogProps) {
  const [typed, setTyped] = useState("");
  const canConfirm = confirmValue ? typed === confirmValue : true;

  useEffect(() => {
    if (!open) setTyped("");
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/60"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.96 }}
            className="relative bg-[var(--surface)] border border-[var(--border-default)] rounded-[var(--radius-xl)] p-6 w-[420px] max-w-[90vw] shadow-[var(--shadow-modal)]"
          >
            <h3 className="text-[length:var(--text-body-lg)] text-[var(--text-primary)] font-sans font-medium mb-2">
              {title}
            </h3>
            <p className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)] mb-4">{body}</p>
            {confirmValue && (
              <div className="mb-4">
                <p className="text-[length:var(--text-caption)] text-[var(--text-muted)] mb-2">
                  请输入 <span className="font-mono text-[var(--text-primary)]">{confirmValue}</span> 以确认
                </p>
                <Input
                  value={typed}
                  onChange={(e) => setTyped(e.target.value)}
                  placeholder={confirmValue}
                  size="sm"
                />
              </div>
            )}
            <div className="flex items-center justify-end gap-2">
              <Button variant="ghost" size="sm" onClick={onClose}>
                取消
              </Button>
              <Button variant="destructive" size="sm" disabled={!canConfirm} onClick={onConfirm}>
                {confirmText}
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export type { Size, Tone, ButtonVariant, AvatarSize, StatusKey, ToastType, SelectOption };
