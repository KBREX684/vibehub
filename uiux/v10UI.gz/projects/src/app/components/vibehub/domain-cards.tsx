import React from "react";
import {
  Eye, GitFork, Star, MessageSquare, Clock, FileText,
  Link2, Bot, BookOpen, Zap, Shield, Hash,
  ThumbsUp, ThumbsDown, EyeOff, Ban,
} from "lucide-react";
import { Button, Avatar, AvatarStack, Badge, StatusPill, Tag, Divider, Kbd } from "./primitives";
import type { StatusKey, Tone } from "./primitives";

function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

/* ═══════════════════════════════════════════════════════
   C-1. ProjectCard v2
   ═══════════════════════════════════════════════════════ */
interface ProjectCardProps {
  coverUrl?: string;
  title: string;
  author: { name: string; avatar?: string };
  type: string;
  visibility: StatusKey;
  license?: string;
  collabStatus: StatusKey;
  recommendationScore?: number;
  description: string;
  onView?: () => void;
  onCollab?: () => void;
}
export function ProjectCard({
  coverUrl,
  title,
  author,
  type,
  visibility,
  license,
  collabStatus,
  recommendationScore = 0,
  description,
  onView,
  onCollab,
}: ProjectCardProps) {
  return (
    <div className="bg-[var(--surface)] border border-[var(--border-default)] rounded-[var(--radius-lg)] overflow-hidden hover:border-[var(--border-strong)] transition-colors group">
      {coverUrl && (
        <div className="aspect-video bg-[var(--elevated)] overflow-hidden">
          <img src={coverUrl} alt={title} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
        </div>
      )}
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-[length:var(--text-body)] text-[var(--text-primary)] font-sans font-medium leading-snug">{title}</h3>
          <StatusPill status={visibility} />
        </div>

        <div className="flex items-center gap-2">
          <Avatar name={author.name} src={author.avatar} size="sm" />
          <span className="text-[length:var(--text-caption)] text-[var(--text-secondary)]">{author.name}</span>
          <Tag>{type}</Tag>
          {license && <Tag>{license}</Tag>}
        </div>

        <div className="flex items-center gap-2">
          <StatusPill status={collabStatus} />
          {recommendationScore > 0 && (
            <div className="flex items-center gap-1 ml-auto">
              <div className="flex gap-px">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div
                    key={i}
                    className={cn(
                      "w-1 h-3 rounded-full",
                      i <= recommendationScore
                        ? "bg-[var(--accent-apple)]"
                        : "bg-[var(--border-default)]"
                    )}
                  />
                ))}
              </div>
              <span className="text-[length:var(--text-micro)] text-[var(--text-muted)] font-mono">{recommendationScore}/5</span>
            </div>
          )}
        </div>

        <p className="text-[length:var(--text-caption)] text-[var(--text-secondary)] line-clamp-2">{description}</p>

        <div className="flex items-center gap-2 pt-1">
          <Button variant="secondary" size="sm" onClick={onView} className="flex-1">
            查看详情
          </Button>
          <Button variant="apple" size="sm" onClick={onCollab} className="flex-1">
            协作意向
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   C-2. IntentCard
   ═══════════════════════════════════════════════════════ */
interface IntentCardProps {
  pitch: string;
  whyYou: string;
  howCollab: string;
  status: StatusKey;
  createdAt: string;
  updatedAt: string;
  onAccept?: () => void;
  onDecline?: () => void;
  onIgnore?: () => void;
  onBlock?: () => void;
}
export function IntentCard({
  pitch,
  whyYou,
  howCollab,
  status,
  createdAt,
  updatedAt,
  onAccept,
  onDecline,
  onIgnore,
  onBlock,
}: IntentCardProps) {
  return (
    <div className="bg-[var(--surface)] border border-[var(--border-default)] rounded-[var(--radius-lg)] p-4 space-y-3">
      <div className="flex items-center justify-between">
        <StatusPill status={status} />
        <div className="flex items-center gap-3 text-[length:var(--text-micro)] text-[var(--text-muted)] font-mono">
          <span>创建: {createdAt}</span>
          <span>更新: {updatedAt}</span>
        </div>
      </div>

      <div className="space-y-2">
        <div>
          <span className="text-[length:var(--text-micro)] text-[var(--text-muted)] font-sans uppercase tracking-wider">项目简介</span>
          <p className="text-[length:var(--text-body-sm)] text-[var(--text-primary)] mt-1">{pitch}</p>
        </div>
        <Divider />
        <div>
          <span className="text-[length:var(--text-micro)] text-[var(--text-muted)] font-sans uppercase tracking-wider">为什么选你</span>
          <p className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)] mt-1">{whyYou}</p>
        </div>
        <Divider />
        <div>
          <span className="text-[length:var(--text-micro)] text-[var(--text-muted)] font-sans uppercase tracking-wider">协作方式</span>
          <p className="text-[length:var(--text-body-sm)] text-[var(--text-secondary)] mt-1">{howCollab}</p>
        </div>
      </div>

      <div className="flex items-center gap-2 pt-1">
        <Button variant="apple" size="sm" onClick={onAccept}>
          <ThumbsUp size={12} /> 接受
        </Button>
        <Button variant="secondary" size="sm" onClick={onDecline}>
          <ThumbsDown size={12} /> 婉拒
        </Button>
        <Button variant="ghost" size="sm" onClick={onIgnore}>
          <EyeOff size={12} /> 忽略
        </Button>
        <Button variant="destructive" size="sm" onClick={onBlock}>
          <Ban size={12} /> 拉黑并举报
        </Button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   C-3. TaskCard
   ═══════════════════════════════════════════════════════ */
interface TaskCardProps {
  actor: { name: string; avatar?: string };
  action: string;
  target: string;
  state: StatusKey;
  time: string;
  onConfirm?: () => void;
}
export function TaskCard({ actor, action, target, state, time, onConfirm }: TaskCardProps) {
  return (
    <div className="flex items-center gap-3 bg-[var(--surface)] border border-[var(--border-default)] rounded-[var(--radius-md)] px-4 py-3 hover:border-[var(--border-strong)] transition-colors">
      <Avatar name={actor.name} src={actor.avatar} size="md" />
      <div className="flex-1 min-w-0">
        <p className="text-[length:var(--text-body-sm)] text-[var(--text-primary)] truncate">
          <span className="font-medium">{actor.name}</span>
          <span className="text-[var(--text-secondary)]"> {action} </span>
          <span className="text-[var(--text-primary)]">{target}</span>
        </p>
        <span className="text-[length:var(--text-micro)] text-[var(--text-muted)] font-mono">{time}</span>
      </div>
      <StatusPill status={state} />
      {onConfirm && (
        <Button variant="secondary" size="sm" onClick={onConfirm}>
          确认
        </Button>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   C-4. ActivityEvent
   ═══════════════════════════════════════════════════════ */
interface ActivityEventProps {
  actor: string;
  verb: string;
  target: string;
  workspaceId?: string;
  snapshotId?: string;
  agentBindingId?: string;
  time: string;
}
export function ActivityEvent({ actor, verb, target, workspaceId, snapshotId, agentBindingId, time }: ActivityEventProps) {
  return (
    <div className="flex items-start gap-3 py-2">
      <Avatar name={actor} size="sm" />
      <div className="flex-1 min-w-0">
        <p className="text-[length:var(--text-caption)] text-[var(--text-secondary)]">
          <span className="text-[var(--text-primary)] font-medium">{actor}</span> {verb}{" "}
          <span className="text-[var(--text-primary)]">{target}</span>
        </p>
        <div className="flex items-center gap-1.5 mt-1 flex-wrap">
          {workspaceId && <Tag>ws:{workspaceId}</Tag>}
          {snapshotId && <Tag>snap:{snapshotId}</Tag>}
          {agentBindingId && <Tag>agent:{agentBindingId}</Tag>}
          <span className="text-[length:var(--text-micro)] text-[var(--text-muted)] font-mono ml-auto">{time}</span>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   C-5. SnapshotCard
   ═══════════════════════════════════════════════════════ */
interface SnapshotCardProps {
  title: string;
  intent: string;
  previousSnapshot?: string;
  artifactCount: number;
  deliverableStatus: StatusKey;
}
export function SnapshotCard({ title, intent, previousSnapshot, artifactCount, deliverableStatus }: SnapshotCardProps) {
  return (
    <div className="bg-[var(--surface)] border border-[var(--border-default)] rounded-[var(--radius-md)] p-4 space-y-2">
      <div className="flex items-center justify-between">
        <h4 className="text-[length:var(--text-body-sm)] text-[var(--text-primary)] font-medium">{title}</h4>
        <StatusPill status={deliverableStatus} />
      </div>
      <p className="text-[length:var(--text-caption)] text-[var(--text-secondary)] line-clamp-1">{intent}</p>
      <div className="flex items-center gap-3">
        {previousSnapshot && (
          <div className="flex items-center gap-1 text-[length:var(--text-micro)] text-[var(--text-muted)]">
            <Link2 size={10} />
            <span className="font-mono">{previousSnapshot}</span>
          </div>
        )}
        <Badge tone="neutral" style="subtle">
          <FileText size={10} className="mr-1" />{artifactCount} 产出物
        </Badge>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   C-6. AgentBadge
   ═══════════════════════════════════════════════════════ */
type AgentRole = "Reader" | "Executor" | "Reviewer" | "Coordinator";
const roleIcons: Record<AgentRole, React.ReactNode> = {
  Reader: <BookOpen size={12} />,
  Executor: <Zap size={12} />,
  Reviewer: <Eye size={12} />,
  Coordinator: <Shield size={12} />,
};
const roleTone: Record<AgentRole, Tone> = {
  Reader: "neutral",
  Executor: "apple",
  Reviewer: "violet",
  Coordinator: "cyan",
};

interface AgentBadgeProps {
  role: AgentRole;
}
export function AgentBadge({ role }: AgentBadgeProps) {
  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-[var(--radius-pill)] text-[length:var(--text-micro)] font-mono whitespace-nowrap border",
      role === "Reader" && "bg-[var(--subtle)] text-[var(--text-secondary)] border-[var(--border-default)]",
      role === "Executor" && "bg-[var(--accent-apple-subtle)] text-[var(--accent-apple)] border-[var(--accent-apple-subtle)]",
      role === "Reviewer" && "bg-[var(--accent-violet-subtle)] text-[var(--accent-violet)] border-[var(--accent-violet-subtle)]",
      role === "Coordinator" && "bg-[var(--accent-cyan-subtle)] text-[var(--accent-cyan)] border-[var(--accent-cyan-subtle)]",
    )}>
      {roleIcons[role]}
      {role}
    </span>
  );
}

/* ═══════════════════════════════════════════════════════
   C-7. NotificationRow
   ═══════════════════════════════════════════════════════ */
interface NotificationRowProps {
  icon: React.ReactNode;
  message: string;
  time: string;
  href?: string;
}
export function NotificationRow({ icon, message, time, href }: NotificationRowProps) {
  return (
    <div className="flex items-center gap-3 px-4 py-2.5 hover:bg-[var(--subtle)] transition-colors cursor-pointer rounded-[var(--radius-md)]">
      <span className="text-[var(--text-muted)] shrink-0">{icon}</span>
      <span className="flex-1 text-[length:var(--text-caption)] text-[var(--text-secondary)] truncate">{message}</span>
      <span className="text-[length:var(--text-micro)] text-[var(--text-muted)] font-mono shrink-0">{time}</span>
    </div>
  );
}
