import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Zap,
  Search,
  ChevronDown,
  Bell,
  FolderPlus,
  Users,
  Download,
  Bot,
  Menu,
  X,
  LogOut,
  CreditCard,
  User,
  BookOpen,
  Settings,
  TrendingUp,
} from "lucide-react";
import { Button, IconButton, Avatar, Kbd } from "./primitives";

/* ─── cn helper ─── */
function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

/* ─── Hook: click outside ─── */
function useClickOutside(
  ref: React.RefObject<HTMLElement | null>,
  handler: () => void
) {
  useEffect(() => {
    const listener = (e: MouseEvent) => {
      if (!ref.current || ref.current.contains(e.target as Node)) return;
      handler();
    };
    document.addEventListener("mousedown", listener);
    return () => document.removeEventListener("mousedown", listener);
  }, [ref, handler]);
}

/* ══════════════════════════════════════════════════════════
   Types
   ══════════════════════════════════════════════════════════ */

export interface NavUser {
  name: string;
  email: string;
  avatarSrc?: string;
  isAdmin?: boolean;
}

export interface NavSubscription {
  tier: "free" | "pro" | "team";
}

export interface TopNavProps {
  mode: "guest" | "authed";
  user?: NavUser;
  subscription?: NavSubscription;
  unreadCount?: number;
  activeNavKey?: string;
  onNavChange?: (key: string) => void;
  onCommandOpen?: () => void;
  onLogin?: () => void;
  onRegister?: () => void;
  onLogout?: () => void;
  onUpgrade?: () => void;
  onCreateSelect?: (key: string) => void;
  /* Legacy compat */
  breadcrumbs?: string[];
}

/* ─── Nav data ─── */
const GUEST_NAV = [
  { key: "home", label: "首页" },
  { key: "discover", label: "发现" },
  { key: "pricing", label: "定价" },
];

const AUTHED_NAV = [
  { key: "discover", label: "发现" },
  { key: "workspace", label: "工作台" },
  { key: "projects", label: "项目库" },
];

const CREATE_ITEMS = [
  {
    key: "new-project",
    icon: FolderPlus,
    label: "新建项目",
    desc: "创建草稿/已公开项目",
  },
  {
    key: "new-workspace",
    icon: Users,
    label: "新建 Team Workspace",
    desc: "邀请 2-10 人协作",
  },
  {
    key: "import-project",
    icon: Download,
    label: "导入项目",
    desc: "从 GitHub 链接导入只读镜像",
  },
];

const AGENT_ITEM = {
  key: "agent-task",
  icon: Bot,
  label: "发起 Agent 任务",
  desc: "跨空间单次 Agent 任务",
};

const AVATAR_MENU_ITEMS = [
  { key: "profile", icon: User, label: "个人主页" },
  { key: "projects", icon: BookOpen, label: "项目库" },
  { key: "billing", icon: CreditCard, label: "订阅与账单" },
];

/* ══════════════════════════════════════════════════════════
   Sub-components
   ══════════════════════════════════════════════════════════ */

/* ── Logo ── */
function Logo() {
  return (
    <div className="flex items-center gap-2 shrink-0">
      <div
        className="w-7 h-7 rounded-[var(--radius-md)] bg-[var(--elevated)] border border-[var(--border-default)] flex items-center justify-center shrink-0"
      >
        <Zap size={14} className="text-[var(--text-primary)]" fill="currentColor" />
      </div>
      <span className="font-sans font-semibold text-[length:var(--text-body-sm)] text-[var(--text-primary)] tracking-tight select-none">
        VibeHub
      </span>
    </div>
  );
}

/* ── Pill Nav ── */
interface PillNavItem {
  key: string;
  label: string;
}
interface PillNavProps {
  items: PillNavItem[];
  activeKey: string;
  onChange: (key: string) => void;
}
function PillNav({ items, activeKey, onChange }: PillNavProps) {
  return (
    <div
      className="flex items-center rounded-[var(--radius-pill)] bg-[var(--surface)] border border-[var(--border-default)]"
      style={{ padding: "var(--space-1)", gap: "2px" }}
    >
      {items.map((item) => {
        const isActive = activeKey === item.key;
        return (
          <button
            key={item.key}
            onClick={() => onChange(item.key)}
            className="relative flex items-center justify-center rounded-[var(--radius-pill)] font-sans cursor-pointer transition-colors duration-150 select-none whitespace-nowrap"
            style={{
              minWidth: "108px",
              paddingLeft: "var(--space-4)",
              paddingRight: "var(--space-4)",
              paddingTop: "6px",
              paddingBottom: "6px",
              fontSize: "var(--text-body-sm)",
              color: isActive ? "var(--text-primary)" : "var(--text-secondary)",
            }}
          >
            {isActive && (
              <motion.div
                layoutId="topnav-active-pill"
                className="absolute inset-0 rounded-[var(--radius-pill)] bg-[var(--elevated)] border border-[var(--border-strong)]"
                transition={{ type: "spring", bounce: 0.18, duration: 0.38 }}
              />
            )}
            <span className="relative z-10">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ── Search Bar ── */
interface SearchBarProps {
  onClick?: () => void;
}
function SearchBar({ onClick }: SearchBarProps) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 h-8 rounded-[var(--radius-md)] bg-[var(--subtle)] border border-[var(--border-default)] hover:border-[var(--border-strong)] transition-colors duration-150 cursor-pointer shrink-0"
      style={{
        width: "240px",
        paddingLeft: "var(--space-3)",
        paddingRight: "var(--space-2)",
      }}
    >
      <Search size={12} className="text-[var(--text-muted)] shrink-0" />
      <span
        className="flex-1 text-left font-sans text-[var(--text-muted)]"
        style={{ fontSize: "var(--text-caption)" }}
      >
        搜索...
      </span>
      <Kbd>⌘K</Kbd>
    </button>
  );
}

/* ── Language Toggle ── */
interface LangToggleProps {
  lang: "en" | "zh";
  onChange: (lang: "en" | "zh") => void;
}
function LangToggle({ lang, onChange }: LangToggleProps) {
  return (
    <div
      className="flex items-center rounded-[var(--radius-pill)] bg-[var(--subtle)] border border-[var(--border-default)] shrink-0"
      style={{ padding: "2px" }}
    >
      {(["zh", "en"] as const).map((l) => {
        const isActive = lang === l;
        return (
          <button
            key={l}
            onClick={() => onChange(l)}
            className="relative flex items-center justify-center rounded-[var(--radius-pill)] font-mono cursor-pointer transition-colors duration-150 select-none"
            style={{
              fontSize: "var(--text-micro)",
              width: "34px",
              height: "24px",
              color: isActive ? "var(--text-primary)" : "var(--text-muted)",
            }}
          >
            {isActive && (
              <motion.div
                layoutId="lang-pill"
                className="absolute inset-0 rounded-[var(--radius-pill)] bg-[var(--elevated)] border border-[var(--border-strong)]"
                transition={{ type: "spring", bounce: 0.15, duration: 0.28 }}
              />
            )}
            <span className="relative z-10">{l === "en" ? "EN" : "中"}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ── Create Dropdown ── */
interface CreateDropdownProps {
  onSelect?: (key: string) => void;
}
function CreateDropdown({ onSelect }: CreateDropdownProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useClickOutside(ref as React.RefObject<HTMLElement>, () => setOpen(false));

  return (
    <div ref={ref} className="relative shrink-0">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 h-8 rounded-[var(--radius-md)] font-sans font-medium cursor-pointer transition-all duration-150 select-none hover:opacity-90 active:opacity-75 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--border-focus-ring)]"
        style={{
          paddingLeft: "var(--space-3)",
          paddingRight: "var(--space-3)",
          fontSize: "var(--text-body-sm)",
          backgroundColor: "var(--text-primary)",
          color: "var(--text-inverse)",
        }}
      >
        <span
          className="leading-none"
          style={{ fontSize: "var(--text-body-sm)", marginTop: "-1px" }}
        >
          +
        </span>
        <span>创建</span>
        <ChevronDown
          size={11}
          style={{
            transform: open ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 200ms",
          }}
        />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.14, ease: "easeOut" }}
            className="absolute right-0 mt-1.5 bg-[var(--elevated)] border border-[var(--border-default)] rounded-[var(--radius-lg)] py-1 shadow-[var(--shadow-modal)] z-50 overflow-hidden"
            style={{ width: "256px", top: "100%" }}
          >
            {CREATE_ITEMS.map((item) => (
              <button
                key={item.key}
                onClick={() => {
                  onSelect?.(item.key);
                  setOpen(false);
                }}
                className="w-full flex items-start gap-3 hover:bg-[var(--subtle)] transition-colors duration-100 cursor-pointer text-left"
                style={{
                  paddingLeft: "var(--space-4)",
                  paddingRight: "var(--space-4)",
                  paddingTop: "var(--space-3)",
                  paddingBottom: "var(--space-3)",
                }}
              >
                <item.icon
                  size={15}
                  className="text-[var(--text-secondary)] shrink-0 mt-0.5"
                />
                <div className="min-w-0">
                  <div
                    className="font-sans text-[var(--text-primary)] leading-snug"
                    style={{ fontSize: "var(--text-body-sm)" }}
                  >
                    {item.label}
                  </div>
                  <div
                    className="font-sans text-[var(--text-muted)] mt-0.5"
                    style={{ fontSize: "var(--text-micro)" }}
                  >
                    {item.desc}
                  </div>
                </div>
              </button>
            ))}

            {/* Divider */}
            <div
              className="mx-3 my-1 bg-[var(--border-subtle)]"
              style={{ height: "1px" }}
            />

            {/* Agent item */}
            <button
              onClick={() => {
                onSelect?.(AGENT_ITEM.key);
                setOpen(false);
              }}
              className="w-full flex items-start gap-3 hover:bg-[var(--subtle)] transition-colors duration-100 cursor-pointer text-left"
              style={{
                paddingLeft: "var(--space-4)",
                paddingRight: "var(--space-4)",
                paddingTop: "var(--space-3)",
                paddingBottom: "var(--space-3)",
              }}
            >
              <AGENT_ITEM.icon
                size={15}
                className="text-[var(--text-secondary)] shrink-0 mt-0.5"
              />
              <div className="min-w-0">
                <div
                  className="font-sans text-[var(--text-primary)] leading-snug"
                  style={{ fontSize: "var(--text-body-sm)" }}
                >
                  {AGENT_ITEM.label}
                </div>
                <div
                  className="font-sans text-[var(--text-muted)] mt-0.5"
                  style={{ fontSize: "var(--text-micro)" }}
                >
                  {AGENT_ITEM.desc}
                </div>
              </div>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── Upgrade Button ── */
interface UpgradeButtonProps {
  onClick?: () => void;
}
function UpgradeButton({ onClick }: UpgradeButtonProps) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 h-8 rounded-[var(--radius-md)] font-sans font-medium cursor-pointer transition-colors duration-150 select-none hover:bg-[var(--subtle)] shrink-0"
      style={{
        paddingLeft: "var(--space-3)",
        paddingRight: "var(--space-3)",
        fontSize: "var(--text-body-sm)",
        color: "var(--semantic-warning)",
        border: "1px solid var(--border-subtle)",
        backgroundColor: "transparent",
      }}
    >
      <TrendingUp size={13} />
      升级
    </button>
  );
}

/* ── Bell Button ── */
interface BellButtonProps {
  unreadCount?: number;
  onClick?: () => void;
}
function BellButton({ unreadCount = 0, onClick }: BellButtonProps) {
  return (
    <div className="relative shrink-0">
      <IconButton size="md" onClick={onClick}>
        <Bell size={16} />
      </IconButton>
      <AnimatePresence>
        {unreadCount > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            transition={{ type: "spring", bounce: 0.4, duration: 0.3 }}
            className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-[var(--semantic-error)] border-2 border-[var(--canvas)] pointer-events-none"
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── Avatar Dropdown ── */
interface AvatarDropdownProps {
  user: NavUser;
  onLogout?: () => void;
}
function AvatarDropdown({ user, onLogout }: AvatarDropdownProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useClickOutside(ref as React.RefObject<HTMLElement>, () => setOpen(false));

  return (
    <div ref={ref} className="relative shrink-0">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 rounded-[var(--radius-md)] hover:bg-[var(--subtle)] transition-colors cursor-pointer p-1 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--border-focus-ring)]"
      >
        <Avatar name={user.name} src={user.avatarSrc} size="sm" />
        <ChevronDown
          size={11}
          className="text-[var(--text-muted)]"
          style={{
            transform: open ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 200ms",
          }}
        />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.14, ease: "easeOut" }}
            className="absolute right-0 mt-1.5 bg-[var(--elevated)] border border-[var(--border-default)] rounded-[var(--radius-lg)] shadow-[var(--shadow-modal)] z-50 overflow-hidden"
            style={{ width: "224px", top: "100%" }}
          >
            {/* Header */}
            <div
              className="border-b border-[var(--border-subtle)]"
              style={{
                paddingLeft: "var(--space-4)",
                paddingRight: "var(--space-4)",
                paddingTop: "var(--space-3)",
                paddingBottom: "var(--space-3)",
              }}
            >
              <div className="flex items-center gap-2.5">
                <Avatar name={user.name} src={user.avatarSrc} size="md" />
                <div className="min-w-0">
                  <div
                    className="font-sans font-medium text-[var(--text-primary)] leading-snug truncate"
                    style={{ fontSize: "var(--text-body-sm)" }}
                  >
                    {user.name}
                  </div>
                  <div
                    className="font-mono text-[var(--text-muted)] mt-0.5 truncate"
                    style={{ fontSize: "var(--text-micro)" }}
                  >
                    {user.email}
                  </div>
                </div>
              </div>
            </div>

            {/* Menu items */}
            <div className="py-1">
              {AVATAR_MENU_ITEMS.map((item) => (
                <button
                  key={item.key}
                  onClick={() => setOpen(false)}
                  className="w-full flex items-center gap-3 text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)] transition-colors cursor-pointer font-sans"
                  style={{
                    paddingLeft: "var(--space-4)",
                    paddingRight: "var(--space-4)",
                    paddingTop: "var(--space-2)",
                    paddingBottom: "var(--space-2)",
                    fontSize: "var(--text-body-sm)",
                  }}
                >
                  <item.icon size={14} className="text-[var(--text-muted)] shrink-0" />
                  {item.label}
                </button>
              ))}

              {user.isAdmin && (
                <button
                  onClick={() => setOpen(false)}
                  className="w-full flex items-center gap-3 text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)] transition-colors cursor-pointer font-sans"
                  style={{
                    paddingLeft: "var(--space-4)",
                    paddingRight: "var(--space-4)",
                    paddingTop: "var(--space-2)",
                    paddingBottom: "var(--space-2)",
                    fontSize: "var(--text-body-sm)",
                  }}
                >
                  <Settings size={14} className="text-[var(--text-muted)] shrink-0" />
                  管理后台
                </button>
              )}
            </div>

            {/* Divider */}
            <div
              className="mx-3 bg-[var(--border-subtle)]"
              style={{ height: "1px" }}
            />

            {/* Logout */}
            <div className="py-1">
              <button
                onClick={() => {
                  onLogout?.();
                  setOpen(false);
                }}
                className="w-full flex items-center gap-3 text-[var(--semantic-error)] hover:bg-[var(--semantic-error-subtle)] transition-colors cursor-pointer font-sans"
                style={{
                  paddingLeft: "var(--space-4)",
                  paddingRight: "var(--space-4)",
                  paddingTop: "var(--space-2)",
                  paddingBottom: "var(--space-2)",
                  fontSize: "var(--text-body-sm)",
                }}
              >
                <LogOut size={14} className="shrink-0" />
                退出
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── Mobile Side Drawer ── */
interface MobileDrawerProps {
  mode: "guest" | "authed";
  open: boolean;
  onClose: () => void;
  navItems: PillNavItem[];
  activeKey: string;
  onNavChange: (key: string) => void;
  lang: "en" | "zh";
  onLangChange: (l: "en" | "zh") => void;
  user?: NavUser;
  subscription?: NavSubscription;
  onLogin?: () => void;
  onRegister?: () => void;
  onLogout?: () => void;
  onUpgrade?: () => void;
  onCreateSelect?: (key: string) => void;
  onCommandOpen?: () => void;
}

function MobileDrawer({
  mode,
  open,
  onClose,
  navItems,
  activeKey,
  onNavChange,
  lang,
  onLangChange,
  user,
  subscription,
  onLogin,
  onRegister,
  onLogout,
  onUpgrade,
  onCreateSelect,
  onCommandOpen,
}: MobileDrawerProps) {
  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-black/50"
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            key="drawer"
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 280 }}
            className="fixed top-0 left-0 bottom-0 z-50 bg-[var(--surface)] border-r border-[var(--border-default)] flex flex-col overflow-hidden"
            style={{ width: "280px" }}
          >
            {/* Header */}
            <div
              className="flex items-center justify-between border-b border-[var(--border-default)] shrink-0"
              style={{ height: "56px", paddingLeft: "var(--space-4)", paddingRight: "var(--space-3)" }}
            >
              <Logo />
              <IconButton size="sm" onClick={onClose}>
                <X size={16} />
              </IconButton>
            </div>

            {/* Search (mobile) */}
            <div
              className="shrink-0 border-b border-[var(--border-subtle)]"
              style={{ padding: "var(--space-3)" }}
            >
              <button
                onClick={() => { onCommandOpen?.(); onClose(); }}
                className="w-full flex items-center gap-2 h-8 rounded-[var(--radius-md)] bg-[var(--subtle)] border border-[var(--border-default)] cursor-pointer"
                style={{ paddingLeft: "var(--space-3)", paddingRight: "var(--space-2)" }}
              >
                <Search size={12} className="text-[var(--text-muted)] shrink-0" />
                <span
                  className="flex-1 text-left font-sans text-[var(--text-muted)]"
                  style={{ fontSize: "var(--text-caption)" }}
                >
                  搜索...
                </span>
                <Kbd>⌘K</Kbd>
              </button>
            </div>

            {/* Nav items */}
            <div className="flex-1 overflow-y-auto" style={{ padding: "var(--space-3)" }}>
              <nav className="space-y-0.5">
                {navItems.map((item) => (
                  <button
                    key={item.key}
                    onClick={() => { onNavChange(item.key); onClose(); }}
                    className={cn(
                      "w-full flex items-center rounded-[var(--radius-md)] font-sans transition-colors cursor-pointer text-left",
                      activeKey === item.key
                        ? "bg-[var(--elevated)] text-[var(--text-primary)]"
                        : "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--subtle)]"
                    )}
                    style={{
                      paddingLeft: "var(--space-3)",
                      paddingRight: "var(--space-3)",
                      paddingTop: "var(--space-2)",
                      paddingBottom: "var(--space-2)",
                      fontSize: "var(--text-body-sm)",
                    }}
                  >
                    {item.label}
                  </button>
                ))}
              </nav>

              {/* Create section (authed) */}
              {mode === "authed" && (
                <>
                  <div
                    className="bg-[var(--border-subtle)]"
                    style={{ height: "1px", marginTop: "var(--space-3)", marginBottom: "var(--space-3)" }}
                  />
                  <div
                    className="font-mono text-[var(--text-muted)] uppercase tracking-wider"
                    style={{ fontSize: "var(--text-micro)", marginBottom: "var(--space-2)", paddingLeft: "var(--space-3)" }}
                  >
                    快捷操作
                  </div>
                  {[...CREATE_ITEMS, AGENT_ITEM].map((item) => (
                    <button
                      key={item.key}
                      onClick={() => { onCreateSelect?.(item.key); onClose(); }}
                      className="w-full flex items-start gap-3 rounded-[var(--radius-md)] hover:bg-[var(--subtle)] transition-colors cursor-pointer text-left"
                      style={{
                        paddingLeft: "var(--space-3)",
                        paddingRight: "var(--space-3)",
                        paddingTop: "var(--space-2)",
                        paddingBottom: "var(--space-2)",
                      }}
                    >
                      <item.icon size={14} className="text-[var(--text-secondary)] shrink-0 mt-0.5" />
                      <div>
                        <div
                          className="font-sans text-[var(--text-primary)]"
                          style={{ fontSize: "var(--text-body-sm)" }}
                        >
                          {item.label}
                        </div>
                        <div
                          className="font-sans text-[var(--text-muted)] mt-0.5"
                          style={{ fontSize: "var(--text-micro)" }}
                        >
                          {item.desc}
                        </div>
                      </div>
                    </button>
                  ))}
                </>
              )}
            </div>

            {/* Footer */}
            <div
              className="shrink-0 border-t border-[var(--border-default)]"
              style={{ padding: "var(--space-3)" }}
            >
              {mode === "guest" ? (
                <div className="space-y-2">
                  {/* Language toggle */}
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className="font-sans text-[var(--text-muted)]"
                      style={{ fontSize: "var(--text-caption)" }}
                    >
                      语言 / Language
                    </span>
                    <LangToggle lang={lang} onChange={onLangChange} />
                  </div>
                  <Button
                    variant="ghost"
                    className="w-full justify-center"
                    onClick={() => { onLogin?.(); onClose(); }}
                  >
                    登录
                  </Button>
                  <Button
                    variant="apple"
                    className="w-full justify-center"
                    onClick={() => { onRegister?.(); onClose(); }}
                  >
                    免费注册
                  </Button>
                </div>
              ) : (
                user && (
                  <div className="space-y-2">
                    {subscription?.tier === "free" && (
                      <button
                        onClick={() => { onUpgrade?.(); onClose(); }}
                        className="w-full flex items-center justify-center gap-1.5 rounded-[var(--radius-md)] font-sans font-medium cursor-pointer transition-colors hover:bg-[var(--subtle)]"
                        style={{
                          height: "32px",
                          fontSize: "var(--text-body-sm)",
                          color: "var(--semantic-warning)",
                          border: "1px solid var(--border-subtle)",
                          backgroundColor: "transparent",
                          marginBottom: "var(--space-2)",
                        }}
                      >
                        <TrendingUp size={13} />
                        升级到 Pro
                      </button>
                    )}
                    <div
                      className="flex items-center gap-3 rounded-[var(--radius-md)]"
                      style={{ padding: "var(--space-2)" }}
                    >
                      <Avatar name={user.name} src={user.avatarSrc} size="md" />
                      <div className="min-w-0 flex-1">
                        <div
                          className="font-sans font-medium text-[var(--text-primary)] truncate"
                          style={{ fontSize: "var(--text-body-sm)" }}
                        >
                          {user.name}
                        </div>
                        <div
                          className="font-mono text-[var(--text-muted)] truncate mt-0.5"
                          style={{ fontSize: "var(--text-micro)" }}
                        >
                          {user.email}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => { onLogout?.(); onClose(); }}
                      className="w-full flex items-center gap-2 rounded-[var(--radius-md)] font-sans text-[var(--semantic-error)] hover:bg-[var(--subtle)] transition-colors cursor-pointer"
                      style={{
                        paddingLeft: "var(--space-3)",
                        paddingRight: "var(--space-3)",
                        paddingTop: "var(--space-2)",
                        paddingBottom: "var(--space-2)",
                        fontSize: "var(--text-body-sm)",
                      }}
                    >
                      <LogOut size={14} />
                      退出登录
                    </button>
                  </div>
                )
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/* ══════════════════════════════════════════════════════════
   TopNav — Main Export
   ══════════════════════════════════════════════════════════ */

export function TopNav({
  mode,
  user,
  subscription,
  unreadCount = 0,
  activeNavKey: controlledKey,
  onNavChange,
  onCommandOpen,
  onLogin,
  onRegister,
  onLogout,
  onUpgrade,
  onCreateSelect,
}: TopNavProps) {
  const navItems = mode === "guest" ? GUEST_NAV : AUTHED_NAV;
  const defaultKey = navItems[0].key;

  const [internalKey, setInternalKey] = useState(controlledKey ?? defaultKey);
  const [lang, setLang] = useState<"en" | "zh">("zh");
  const [mobileOpen, setMobileOpen] = useState(false);

  const activeKey = controlledKey ?? internalKey;

  const handleNavChange = (key: string) => {
    setInternalKey(key);
    onNavChange?.(key);
  };

  return (
    <>
      {/* ── Header ── */}
      <header
        className="sticky top-0 z-40 w-full border-b border-[var(--border-default)] bg-[var(--surface)]"
        style={{
          height: "56px",
          backdropFilter: "blur(8px)",
          WebkitBackdropFilter: "blur(8px)",
        }}
      >
        <div
          className="h-full flex items-center relative"
          style={{ paddingLeft: "var(--space-4)", paddingRight: "var(--space-4)" }}
        >
          {/* Left: Logo */}
          <div className="flex items-center" style={{ minWidth: "140px" }}>
            <Logo />
          </div>

          {/* Center: Pill Nav — desktop only */}
          <div className="hidden md:flex absolute left-1/2 -translate-x-1/2">
            <PillNav
              items={navItems}
              activeKey={activeKey}
              onChange={handleNavChange}
            />
          </div>

          {/* Right: Controls */}
          <div className="flex items-center gap-2 ml-auto">
            {/* Desktop right zone */}
            <div className="hidden md:flex items-center gap-2">
              <SearchBar onClick={onCommandOpen} />

              {mode === "guest" ? (
                <>
                  <LangToggle lang={lang} onChange={setLang} />
                  <div style={{ marginLeft: "var(--space-1)" }}>
                    <Button variant="ghost" size="sm" onClick={onLogin}>
                      登录
                    </Button>
                  </div>
                  <Button variant="apple" size="sm" onClick={onRegister}>
                    免费注册
                  </Button>
                </>
              ) : (
                <>
                  <CreateDropdown onSelect={onCreateSelect} />
                  {subscription?.tier === "free" && (
                    <UpgradeButton onClick={onUpgrade} />
                  )}
                  <BellButton unreadCount={unreadCount} />
                  {user && <AvatarDropdown user={user} onLogout={onLogout} />}
                </>
              )}
            </div>

            {/* Mobile right zone: bell + avatar (authed) + hamburger */}
            <div className="flex md:hidden items-center gap-1">
              {mode === "authed" && (
                <>
                  <BellButton unreadCount={unreadCount} />
                  {user && <AvatarDropdown user={user} onLogout={onLogout} />}
                </>
              )}
              <IconButton size="md" onClick={() => setMobileOpen(true)}>
                <Menu size={18} />
              </IconButton>
            </div>
          </div>
        </div>

        {/* Hairline decorative bottom gradient */}
        <div
          className="absolute bottom-0 left-0 right-0 pointer-events-none"
          style={{
            height: "1px",
            background:
              "linear-gradient(to right, transparent, var(--border-default) 20%, var(--border-default) 80%, transparent)",
          }}
        />
      </header>

      {/* Mobile drawer */}
      <MobileDrawer
        mode={mode}
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        navItems={navItems}
        activeKey={activeKey}
        onNavChange={handleNavChange}
        lang={lang}
        onLangChange={setLang}
        user={user}
        subscription={subscription}
        onLogin={onLogin}
        onRegister={onRegister}
        onLogout={onLogout}
        onUpgrade={onUpgrade}
        onCreateSelect={onCreateSelect}
        onCommandOpen={onCommandOpen}
      />
    </>
  );
}