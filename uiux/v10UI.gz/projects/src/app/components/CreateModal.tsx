import { CheckSquare, FolderKanban, MessageSquare, X } from "lucide-react";

export function CreateModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-canvas/90 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-md bg-surface border border-border-strong rounded-2xl shadow-modal overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border-default">
          <h2 className="text-body-lg font-sans font-medium text-primary">新建 (Create New)</h2>
          <button 
            onClick={onClose}
            className="text-muted hover:text-primary transition-colors p-1 rounded-md hover:bg-subtle"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-4 grid grid-cols-2 gap-4">
          <CreateOption 
            icon={CheckSquare}
            title="任务 (Task)"
            description="Track a new piece of work"
            color="text-accent-violet"
            bg="bg-accent-violet-subtle"
          />
          <CreateOption 
            icon={FolderKanban}
            title="项目 (Project)"
            description="Start a new initiative"
            color="text-accent-apple"
            bg="bg-accent-apple-subtle"
          />
          <CreateOption 
            icon={MessageSquare}
            title="讨论 (Discussion)"
            description="Share an idea with the team"
            color="text-accent-cyan"
            bg="bg-accent-cyan-subtle"
            className="col-span-2 flex-row text-left items-center justify-start gap-4"
          />
        </div>
      </div>
    </div>
  );
}

function CreateOption({ 
  icon: Icon, title, description, color, bg, className = "" 
}: { 
  icon: React.ElementType, title: string, description: string, color: string, bg: string, className?: string 
}) {
  return (
    <button className={`flex flex-col items-center justify-center p-6 rounded-xl border border-border-default hover:border-border-strong hover:bg-elevated transition-all group ${className}`}>
      <div className={`p-3 rounded-full ${bg} mb-4 group-hover:scale-110 transition-transform`}>
        <Icon size={24} className={color} />
      </div>
      <div>
        <h3 className="text-body font-medium text-primary mb-1">{title}</h3>
        <p className="text-caption text-muted">{description}</p>
      </div>
    </button>
  );
}