import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { Discover } from "./pages/Discover";
import { ProjectDetail } from "./pages/ProjectDetail";
import { PersonalWorkspace } from "./pages/work/PersonalWorkspace";
import { TeamWorkspace } from "./pages/work/TeamWorkspace";
import { ProjectLibrary } from "./pages/work/ProjectLibrary";
import { Intents } from "./pages/work/Intents";
import { Notifications } from "./pages/work/Notifications";
import { AgentTasks } from "./pages/work/AgentTasks";
import { Settings } from "./pages/work/Settings";
import { UILibrary } from "./pages/UILibrary";
import { Team } from "./pages/Team";
import { Signup } from "./pages/Signup";
import { Layout } from "./components/Layout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "discover", Component: Discover },
      { path: "p/:slug", Component: ProjectDetail },
      { path: "work/personal", Component: PersonalWorkspace },
      { path: "work/team/:slug", Component: TeamWorkspace },
      { path: "work/library", Component: ProjectLibrary },
      { path: "work/intents", Component: Intents },
      { path: "work/notifications", Component: Notifications },
      { path: "work/agent-tasks", Component: AgentTasks },
      { path: "settings", Component: Settings },
      { path: "ui", Component: UILibrary },
      { path: "team", Component: Team },
      { path: "signup", Component: Signup },
    ],
  },
]);
