// VibeHub v10.0 — Mock Data Layer

export type ProjectStatus = 'active' | 'planning' | 'in-review' | 'done' | 'archived';
export type TaskStatus = 'todo' | 'in-progress' | 'in-review' | 'done' | 'cancelled';
export type Priority = 'urgent' | 'high' | 'medium' | 'low' | 'none';
export type MemberType = 'human' | 'ai';
export type DiscussionStatus = 'open' | 'resolved' | 'draft' | 'closed';

export interface TeamMember {
  id: string;
  name: string;
  nameEn: string;
  role: string;
  type: MemberType;
  status: 'online' | 'offline' | 'busy' | 'active' | 'idle';
  initials?: string;
  model?: string;
  capabilities?: string[];
  tasksCompleted: number;
  tasksActive: number;
  joinedAt: string;
}

export interface Project {
  id: string;
  name: string;
  slug: string;
  description: string;
  status: ProjectStatus;
  members: number;
  agents: number;
  tasks: { total: number; done: number; inProgress: number };
  stack: string[];
  lastActivity: string;
  createdAt: string;
}

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  priority: Priority;
  assignee: { id: string; name: string; type: MemberType } | null;
  labels: string[];
  projectId: string;
  projectName: string;
  createdAt: string;
  updatedAt: string;
  comments: number;
  estimate?: string;
}

export interface ActivityItem {
  id: string;
  actor: { id: string; name: string; type: MemberType; initials?: string };
  action: string;
  target: { type: 'task' | 'project' | 'discussion' | 'member'; id: string; label: string };
  timestamp: string;
  projectId?: string;
}

export interface Discussion {
  id: string;
  title: string;
  status: DiscussionStatus;
  projectId: string;
  projectName: string;
  author: { name: string; initials: string; type: MemberType };
  participants: number;
  replies: number;
  lastReply: string;
  createdAt: string;
  pinned: boolean;
  tags: string[];
}

// ─── Team Members ───────────────────────────────────────────────────────────
export const teamMembers: TeamMember[] = [
  {
    id: 'u1',
    name: '张伟',
    nameEn: 'Zhang Wei',
    role: '后端工程师',
    type: 'human',
    status: 'online',
    initials: 'ZW',
    tasksCompleted: 47,
    tasksActive: 3,
    joinedAt: '2024-03-12',
  },
  {
    id: 'u2',
    name: '李明',
    nameEn: 'Li Ming',
    role: '产品经理',
    type: 'human',
    status: 'busy',
    initials: 'LM',
    tasksCompleted: 31,
    tasksActive: 5,
    joinedAt: '2024-04-01',
  },
  {
    id: 'u3',
    name: '陈晓',
    nameEn: 'Chen Xiao',
    role: '全栈工程师',
    type: 'human',
    status: 'online',
    initials: 'CX',
    tasksCompleted: 58,
    tasksActive: 2,
    joinedAt: '2024-02-20',
  },
  {
    id: 'u4',
    name: '王芳',
    nameEn: 'Wang Fang',
    role: '前端工程师',
    type: 'human',
    status: 'offline',
    initials: 'WF',
    tasksCompleted: 39,
    tasksActive: 1,
    joinedAt: '2024-05-15',
  },
  {
    id: 'a1',
    name: 'Aria',
    nameEn: 'Aria',
    role: 'AI 代码助手',
    type: 'ai',
    status: 'active',
    model: 'claude-sonnet-4',
    capabilities: ['代码审查', '重构建议', '文档生成', '测试用例'],
    tasksCompleted: 124,
    tasksActive: 4,
    joinedAt: '2024-11-01',
  },
  {
    id: 'a2',
    name: 'ByteBot',
    nameEn: 'ByteBot',
    role: 'AI 测试工程师',
    type: 'ai',
    status: 'active',
    model: 'gpt-4o',
    capabilities: ['单元测试', '集成测试', '回归测试', 'E2E 测试'],
    tasksCompleted: 89,
    tasksActive: 6,
    joinedAt: '2024-11-15',
  },
  {
    id: 'a3',
    name: 'CodeScan',
    nameEn: 'CodeScan',
    role: 'AI 安全分析',
    type: 'ai',
    status: 'idle',
    model: 'custom-sec-v2',
    capabilities: ['漏洞扫描', 'OWASP 检测', '依赖审计', '合规检查'],
    tasksCompleted: 203,
    tasksActive: 0,
    joinedAt: '2024-10-01',
  },
];

// ─── Projects ────────────────────────────────────────────────────────────────
export const projects: Project[] = [
  {
    id: 'PRJ-001',
    name: '核心 API 重构',
    slug: 'core-api-refactor',
    description: '重构认证与数据层接口，提升系统稳定性',
    status: 'active',
    members: 4,
    agents: 2,
    tasks: { total: 24, done: 9, inProgress: 6 },
    stack: ['Go', 'PostgreSQL', 'gRPC'],
    lastActivity: '2分钟前',
    createdAt: '2024-11-01',
  },
  {
    id: 'PRJ-002',
    name: '前端组件库',
    slug: 'ui-components',
    description: '统一设计语言与组件规范，支持多产品复用',
    status: 'active',
    members: 2,
    agents: 1,
    tasks: { total: 18, done: 14, inProgress: 2 },
    stack: ['React', 'TypeScript', 'Storybook'],
    lastActivity: '34分钟前',
    createdAt: '2024-10-15',
  },
  {
    id: 'PRJ-003',
    name: '数据管道优化',
    slug: 'data-pipeline',
    description: '实时数据处理链路性能提升，目标 P99 < 10ms',
    status: 'in-review',
    members: 1,
    agents: 3,
    tasks: { total: 11, done: 8, inProgress: 2 },
    stack: ['Rust', 'Kafka', 'ClickHouse'],
    lastActivity: '1小时前',
    createdAt: '2024-09-20',
  },
  {
    id: 'PRJ-004',
    name: '移动端适配',
    slug: 'mobile-adapt',
    description: 'iOS/Android 跨平台响应式适配',
    status: 'planning',
    members: 3,
    agents: 0,
    tasks: { total: 6, done: 0, inProgress: 0 },
    stack: ['React Native', 'Expo'],
    lastActivity: '昨天',
    createdAt: '2024-11-10',
  },
  {
    id: 'PRJ-005',
    name: '安全审计',
    slug: 'security-audit',
    description: '全栈安全漏洞扫描与修复，通过 SOC2 合规',
    status: 'done',
    members: 4,
    agents: 1,
    tasks: { total: 31, done: 31, inProgress: 0 },
    stack: ['Python', 'OWASP', 'Trivy'],
    lastActivity: '3天前',
    createdAt: '2024-08-01',
  },
];

// ─── Tasks ───────────────────────────────────────────────────────────────────
export const tasks: Task[] = [
  {
    id: 'VH-001',
    title: '修复用户认证中间件竞态条件',
    status: 'in-progress',
    priority: 'urgent',
    assignee: { id: 'a1', name: 'Aria', type: 'ai' },
    labels: ['bug', 'auth', 'P0'],
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    createdAt: '2024-11-14',
    updatedAt: '2小时前',
    comments: 7,
    estimate: '2d',
  },
  {
    id: 'VH-002',
    title: 'gRPC 连接池内存泄漏排查',
    status: 'in-progress',
    priority: 'urgent',
    assignee: { id: 'u1', name: '张伟', type: 'human' },
    labels: ['bug', 'memory', 'grpc'],
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    createdAt: '2024-11-13',
    updatedAt: '45分钟前',
    comments: 4,
    estimate: '3d',
  },
  {
    id: 'VH-003',
    title: '设计 Token 刷新机制 v2',
    status: 'in-progress',
    priority: 'high',
    assignee: { id: 'u3', name: '陈晓', type: 'human' },
    labels: ['feature', 'auth'],
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    createdAt: '2024-11-12',
    updatedAt: '3小时前',
    comments: 12,
    estimate: '5d',
  },
  {
    id: 'VH-004',
    title: 'Button 组件无障碍访问支持',
    status: 'in-review',
    priority: 'medium',
    assignee: { id: 'u4', name: '王芳', type: 'human' },
    labels: ['a11y', 'component'],
    projectId: 'PRJ-002',
    projectName: '前端组件库',
    createdAt: '2024-11-11',
    updatedAt: '1小时前',
    comments: 3,
    estimate: '1d',
  },
  {
    id: 'VH-005',
    title: '编写 DataTable 组件单元测试',
    status: 'in-review',
    priority: 'medium',
    assignee: { id: 'a2', name: 'ByteBot', type: 'ai' },
    labels: ['test', 'component'],
    projectId: 'PRJ-002',
    projectName: '前端组件库',
    createdAt: '2024-11-10',
    updatedAt: '2小时前',
    comments: 1,
    estimate: '2d',
  },
  {
    id: 'VH-006',
    title: 'Kafka 消费者分区重平衡优化',
    status: 'in-review',
    priority: 'high',
    assignee: { id: 'a1', name: 'Aria', type: 'ai' },
    labels: ['performance', 'kafka'],
    projectId: 'PRJ-003',
    projectName: '数据管道优化',
    createdAt: '2024-11-09',
    updatedAt: '4小时前',
    comments: 8,
    estimate: '4d',
  },
  {
    id: 'VH-007',
    title: '用户资料页 API 接口对接',
    status: 'todo',
    priority: 'medium',
    assignee: { id: 'u3', name: '陈晓', type: 'human' },
    labels: ['feature', 'api'],
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    createdAt: '2024-11-08',
    updatedAt: '昨天',
    comments: 0,
    estimate: '2d',
  },
  {
    id: 'VH-008',
    title: '迁移旧版日志格式至结构化 JSON',
    status: 'todo',
    priority: 'low',
    assignee: null,
    labels: ['infra', 'logging'],
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    createdAt: '2024-11-07',
    updatedAt: '2天前',
    comments: 2,
    estimate: '1d',
  },
  {
    id: 'VH-009',
    title: '移动端首页原型评审',
    status: 'todo',
    priority: 'high',
    assignee: { id: 'u2', name: '李明', type: 'human' },
    labels: ['design', 'mobile'],
    projectId: 'PRJ-004',
    projectName: '移动端适配',
    createdAt: '2024-11-06',
    updatedAt: '2天前',
    comments: 5,
    estimate: '?',
  },
  {
    id: 'VH-010',
    title: '依赖注入框架升级至 v3',
    status: 'todo',
    priority: 'low',
    assignee: null,
    labels: ['refactor', 'deps'],
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    createdAt: '2024-11-05',
    updatedAt: '3天前',
    comments: 0,
    estimate: '3d',
  },
  {
    id: 'VH-011',
    title: '修复 CI 流水线 Docker 层缓存失效',
    status: 'done',
    priority: 'medium',
    assignee: { id: 'a2', name: 'ByteBot', type: 'ai' },
    labels: ['ci', 'devops'],
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    createdAt: '2024-11-04',
    updatedAt: '4天前',
    comments: 3,
    estimate: '0.5d',
  },
  {
    id: 'VH-012',
    title: '用户邮箱验证功能已下线',
    status: 'cancelled',
    priority: 'none',
    assignee: null,
    labels: ['auth'],
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    createdAt: '2024-10-30',
    updatedAt: '7天前',
    comments: 6,
  },
];

// ─── Activity Stream ─────────────────────────────────────────────────────────
export const activityFeed: ActivityItem[] = [
  {
    id: 'act-001',
    actor: { id: 'a1', name: 'Aria', type: 'ai', initials: 'AI' },
    action: '完成了代码审查并提交修复建议',
    target: { type: 'task', id: 'VH-001', label: '修复用户认证中间件竞态条件' },
    timestamp: '3分钟前',
    projectId: 'PRJ-001',
  },
  {
    id: 'act-002',
    actor: { id: 'u1', name: '张伟', type: 'human', initials: 'ZW' },
    action: '将优先级设置为紧急',
    target: { type: 'task', id: 'VH-002', label: 'gRPC 连接池内存泄漏排查' },
    timestamp: '18分钟前',
    projectId: 'PRJ-001',
  },
  {
    id: 'act-003',
    actor: { id: 'a2', name: 'ByteBot', type: 'ai', initials: 'AI' },
    action: '检测到 3 个测试用例失败，已创建子任务',
    target: { type: 'task', id: 'VH-005', label: '编写 DataTable 组件单元测试' },
    timestamp: '32分钟前',
    projectId: 'PRJ-002',
  },
  {
    id: 'act-004',
    actor: { id: 'u3', name: '陈晓', type: 'human', initials: 'CX' },
    action: '创建了新讨论',
    target: { type: 'discussion', id: 'VHD-003', label: 'Token 刷新机制架构设计 RFC' },
    timestamp: '1小时前',
    projectId: 'PRJ-001',
  },
  {
    id: 'act-005',
    actor: { id: 'u4', name: '王芳', type: 'human', initials: 'WF' },
    action: '提交了 PR 并请求审查',
    target: { type: 'task', id: 'VH-004', label: 'Button 组件无障碍访问支持' },
    timestamp: '2小时前',
    projectId: 'PRJ-002',
  },
  {
    id: 'act-006',
    actor: { id: 'a1', name: 'Aria', type: 'ai', initials: 'AI' },
    action: '生成了性能优化方案文档',
    target: { type: 'task', id: 'VH-006', label: 'Kafka 消费者分区重平衡优化' },
    timestamp: '3小时前',
    projectId: 'PRJ-003',
  },
  {
    id: 'act-007',
    actor: { id: 'u2', name: '李明', type: 'human', initials: 'LM' },
    action: '创建了项目并分配初始成员',
    target: { type: 'project', id: 'PRJ-004', label: '移动端适配' },
    timestamp: '昨天 16:42',
    projectId: 'PRJ-004',
  },
  {
    id: 'act-008',
    actor: { id: 'a3', name: 'CodeScan', type: 'ai', initials: 'AI' },
    action: '完成全仓库安全扫描，发现 0 个高危漏洞',
    target: { type: 'project', id: 'PRJ-005', label: '安全审计' },
    timestamp: '昨天 09:15',
    projectId: 'PRJ-005',
  },
  {
    id: 'act-009',
    actor: { id: 'u1', name: '张伟', type: 'human', initials: 'ZW' },
    action: '关闭了任务',
    target: { type: 'task', id: 'VH-012', label: '用户邮箱验证功能已下线' },
    timestamp: '2天前',
    projectId: 'PRJ-001',
  },
  {
    id: 'act-010',
    actor: { id: 'a2', name: 'ByteBot', type: 'ai', initials: 'AI' },
    action: '修复了 CI 流水线 Docker 层缓存失效',
    target: { type: 'task', id: 'VH-011', label: '修复 CI 流水线 Docker 层缓存失效' },
    timestamp: '3天前',
    projectId: 'PRJ-001',
  },
];

// ─── Discussions ─────────────────────────────────────────────────────────────
export const discussions: Discussion[] = [
  {
    id: 'VHD-001',
    title: 'API 版本控制策略 RFC',
    status: 'open',
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    author: { name: '张伟', initials: 'ZW', type: 'human' },
    participants: 5,
    replies: 14,
    lastReply: '2小时前',
    createdAt: '2024-11-10',
    pinned: true,
    tags: ['RFC', 'API', '架构'],
  },
  {
    id: 'VHD-002',
    title: '前端状态管理方案选型',
    status: 'open',
    projectId: 'PRJ-002',
    projectName: '前端组件库',
    author: { name: '王芳', initials: 'WF', type: 'human' },
    participants: 3,
    replies: 8,
    lastReply: '5小时前',
    createdAt: '2024-11-09',
    pinned: false,
    tags: ['设计', 'React'],
  },
  {
    id: 'VHD-003',
    title: 'Token 刷新机制架构设计 RFC',
    status: 'open',
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    author: { name: '陈晓', initials: 'CX', type: 'human' },
    participants: 4,
    replies: 2,
    lastReply: '1小时前',
    createdAt: '2024-11-14',
    pinned: false,
    tags: ['RFC', 'auth', '安全'],
  },
  {
    id: 'VHD-004',
    title: 'AI 代理协作规范 v1.0',
    status: 'open',
    projectId: 'PRJ-001',
    projectName: '核心 API 重构',
    author: { name: 'Aria', initials: 'AI', type: 'ai' },
    participants: 7,
    replies: 21,
    lastReply: '昨天',
    createdAt: '2024-11-05',
    pinned: true,
    tags: ['AI', '协作', '规范'],
  },
  {
    id: 'VHD-005',
    title: 'ClickHouse 数据保留策略',
    status: 'resolved',
    projectId: 'PRJ-003',
    projectName: '数据管道优化',
    author: { name: '陈晓', initials: 'CX', type: 'human' },
    participants: 2,
    replies: 11,
    lastReply: '3天前',
    createdAt: '2024-10-28',
    pinned: false,
    tags: ['数据', 'ClickHouse'],
  },
  {
    id: 'VHD-006',
    title: '移动端导航架构草案',
    status: 'draft',
    projectId: 'PRJ-004',
    projectName: '移动端适配',
    author: { name: '李明', initials: 'LM', type: 'human' },
    participants: 1,
    replies: 0,
    lastReply: '—',
    createdAt: '2024-11-13',
    pinned: false,
    tags: ['移动端', '导航'],
  },
];

// ─── Metrics ─────────────────────────────────────────────────────────────────
export const metrics = {
  activeTasks: 6,
  tasksDoneThisWeek: 8,
  teamMembers: 4,
  aiAgents: 3,
  activeAgentRuns: 10,
  openDiscussions: 4,
  projectsActive: 2,
  codeReviewsPending: 3,
};
