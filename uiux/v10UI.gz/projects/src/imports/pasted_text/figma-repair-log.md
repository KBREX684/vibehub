Continue in the same Figma file.

Use ALL previously provided content from docs/ui-v10-figma-prompts.md as the single source of truth.
That means you must enforce the FULL specification already provided in this conversation, including:
- §0 Design DNA
- §1 Design Tokens / Variables logic
- §2 Component Library requirements
- §3 TopNav requirements
- §4 Workspace Console Shell requirements
- §5.1–§5.11 all page-level requirements
- §6 Responsive strategy
- §7 Deliverables and consistency requirements
- §8 Negative constraints
- §9 Reference-company precedence rules
- §10 implementation-oriented usage constraints

You are not auditing loosely.
You are repairing the current Figma file to fully conform to the complete VibeHub v10.0 specification already given.

Your role:
Act as a principal product designer, design systems lead, UI QA lead, and implementation-minded repair agent.

Mission:
Review the entire current Figma file and directly FIX everything that does not fully conform to the complete docs/ui-v10-figma-prompts.md specification already provided.

Important behavior rules:
- Do NOT classify issues by Blocker / High / Medium / Low.
- Do NOT output a problem list first.
- Do NOT ask for permission before fixing.
- Do NOT redesign the product from scratch.
- Preserve all valid work.
- Directly repair invalid, incomplete, inconsistent, unstable, or drifting parts.
- If something is missing, create it.
- If something is duplicated or conflicting, normalize it.
- If a page is partially correct, keep the correct parts and repair the wrong parts.

Primary source of truth:
Everything already provided from docs/ui-v10-figma-prompts.md overrides local guesswork.
If any current frame conflicts with the earlier provided spec, fix the frame to match the spec.
If any component or page visually looks nice but violates the spec, correct it to the spec.

Repair scope:
Repair the entire file across all of the following dimensions:

1) Design DNA compliance
- Must remain Monochrome Geek Dark
- Must remain a dense developer-tool product
- Must NOT drift into forum / GitHub / IDE / chat-app / generic SaaS marketing style

2) Token compliance
- Normalize color usage, text hierarchy, spacing, radius, border strength, shadows, density, and typography to the VibeHub v10.0 token logic already provided
- Remove one-off visual styling that breaks token discipline
- Eliminate ad hoc stylistic drift

3) Component-library compliance
- Normalize all buttons, inputs, pills, badges, tags, tooltips, skeletons, dialogs, cards, tabs, drawers, nav items, table rows, and status treatments to the VibeHub/UI v10 system
- Ensure reusable component behavior instead of page-specific visual hacks
- Repair inconsistent variants or missing variants

4) TopNav compliance
- Ensure the top navigation matches the previously provided guest/authed structure
- Fix incorrect item order, button hierarchy, menu contents, search treatment, language toggle stability, and mobile collapse behavior
- Eliminate nav jitter and pill instability

5) ConsoleShell compliance
- Ensure all /work/** pages correctly inherit the shared shell logic already specified
- Normalize LeftRail, Main region, ComplianceStrip, ViewTabs, RightRail, and expand/collapse behavior
- Eliminate shell inconsistency across work pages

6) Full page compliance
Check and directly repair all page frames to match the previously provided requirements for:
- Home "/"
- Discover "/discover"
- Project Detail "/p/[slug]"
- IntentDrawer
- Personal Workspace "/work/personal"
- Team Workspace "/work/team/[slug]"
- Project Library "/work/library"
- Collaboration Requests "/work/intents"
- Agent Task Center "/work/agent-tasks"
- Notifications "/work/notifications"
- Settings "/settings"

For each of the above:
- fix missing required sections
- fix wrong hierarchy
- fix wrong layout structure
- fix wrong CTA ordering
- fix missing states
- fix missing rails / drawers / tabs / cards / table structures
- fix anything violating the intended page role

7) Responsive compliance
Enforce the responsive rules already provided:
- desktop 1440
- tablet 1024
- mobile 375
- correct collapse behavior
- no broken stacking
- no impossible density on mobile
- no unstable sticky behavior
- no overflow-caused breakage

8) Deliverable compliance
Repair all frames so they are implementation-ready:
- auto layout everywhere
- clear reusable component logic
- no decorative-only fake UI
- realistic Chinese developer copy
- include appropriate hover / active / focus / disabled / loading / empty / error / success states where required

9) Negative-constraint compliance
Directly remove or correct anything that violates the negative list already provided, including but not limited to:
- light mode output
- gradient-heavy hero/cards
- excessive glassmorphism
- social reaction bars
- chat bubbles with tails
- repo/branch/PR/CI visuals
- PM-heavy Gantt / sprint dashboards
- KPI tile dashboards
- marketing bento-grid layouts
- any forum/chat/community drift

10) Reference precedence compliance
When visual decisions are ambiguous, resolve them using the previously provided precedence:
- Linear for app density, activity rhythm, tabs, command surfaces
- Vercel for restrained marketing typography and footer/pricing surfaces
- Raycast for command palette, drawer behavior, keyboard UI
- Supabase Studio for data tables, status pills, empty states, audit-timeline feel
- GitHub Primer for governance/admin surfaces

Stability requirements:
Directly repair all visual instability, including:
- top-nav label jitter
- language-switch width jumping
- button resizing between states
- badge/count width instability
- tab-pill movement that causes reflow
- hover states that change layout size
- borders that alter overall component dimensions without compensation
- icon/text baseline drift
- sticky headers/rails that feel misaligned
- row-action reveals that cause table reflow
- zh-CN / en-US switching that breaks alignment

Interaction requirements:
Directly repair all interaction-quality issues:
- ambiguous CTA hierarchy
- weak ghost buttons where action should be clearer
- destructive actions not sufficiently separated
- icon-only controls with poor clarity
- fake-clickable elements
- clickable elements without sufficient affordance
- missing confirmation patterns
- empty states without useful next action
- drawers / modals / dropdowns with poor footer hierarchy

What to do while repairing:
- keep correct frames
- normalize incorrect ones
- merge conflicting styles into the proper system
- create any missing required state or missing required section
- repair page-to-page consistency
- preserve one coherent product feeling across public layer and workspace layer

What NOT to do:
- do not give me a theoretical review
- do not give me severity grading
- do not produce a long list before acting
- do not drift away from the provided docs
- do not invent a new style system
- do not simplify away required product complexity

Final output:
After repairing, output only a concise repair summary with:
- frames repaired
- missing sections added
- components normalized
- unstable interactions stabilized
- responsive issues corrected
- remaining gaps, only if something could not be confidently repaired