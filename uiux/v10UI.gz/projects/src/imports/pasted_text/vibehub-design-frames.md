Continue in the same Figma file.
Keep the existing VibeHub v10 design DNA, existing TopNav, and existing ConsoleShell unchanged.

Create 4 separate frames in the same file:

FRAME A — Project Library "/work/library"
Design the Project Library as a management table, inspired by Linear's Projects page and Supabase Studio's table views.

Top toolbar (sticky):
- Title "项目库" h2
- Right: [新建项目] apple-accent + [导入项目] ghost + search input + filter
- Status tabs: 草稿 · 已公开 · 私有 · 开源 · 已归档 (query: ?status=)

DataTable columns (sortable, mono column headers uppercase 11):
名称 | 状态 | 可见性 | 许可证 | 绑定 Workspace | 最近更新 | 协作意向数 | 操作

Row:
- 名称 cell: small cover thumbnail 32×32 + project name + mono slug
- 状态: StatusPill
- 可见性: icon (eye/lock/globe) + label
- 许可证: mono tag
- 绑定 Workspace: avatar + workspace name + type pill
- 最近更新: mono relative time
- 协作意向数: mono number; click → /work/intents?tab=received&project=slug
- 操作: kebab menu (编辑 / 预览 / 发布 / 下线 / 进入 Workspace)

Bulk selection:
- checkbox column
- bulk actions = 归档 / 下线 / 批量标签

Empty state per status:
- 草稿: "还没有草稿。新建一个项目开始。" + [新建项目]
- 已公开: "你还没有公开任何项目。" + [发布首个项目]

Mobile:
- DataTable degrades to stacked cards
- each card shows name + status + last updated + kebab
- other columns fold into expandable details


FRAME B — Collaboration Requests "/work/intents"
Design the global Collaboration Intent inbox.

Top:
- Tabs: 收到的 · 发出的 · 已接受 · 已拒绝 · 已过期 (mono counts)
- Filter: 项目 dropdown, 时间范围 dropdown, 关键词搜索

List:
- 1-column stream of IntentCard (desktop 840 max, single column)

IntentCard (300–360 tall):
- Header row:
  申请人 avatar + name + mono "→ @project-name"
  StatusPill (open / accepted / declined / ignored / expired / blocked)
  mono timestamp
- Body:
  3 paragraphs stacked, each with a mono label prefix
  我是谁·我能做什么 / 我为什么联系你 / 我希望怎样合作
  Each paragraph truncated to 4 lines with "展开"
- Footer actions (only on 收到的 tab & status=open):
  [接受] apple-accent
  [婉拒] ghost
  [忽略] ghost
  [拉黑并举报] error-tinted ghost
- Footer meta:
  "过期时间: 2026-05-17 (剩 12 天)" mono caption

Empty states:
- 收到的: "暂无收到的协作意向。"
- 已过期: "30 天内未处理将自动过期。" + link 设置通知偏好

Detail drawer:
- same three paragraphs full-length
- conversation log (ONLY after accept)
- action history audit

Block-and-report:
- submits to admin-moderation
- use ConfirmDialog requiring typed confirmation "拉黑并举报"


FRAME C — Notifications "/work/notifications"
Design the categorized notification center.

Left rail (secondary, 200 wide, inside Main area, not replacing LeftRail):
类别导航：
- 协作意向 [3]
- 留言与纠错 [1]
- 团队邀请 [0]
- Agent 完成任务 [5]
- 快照确认 [2]
- Deliverable 状态 [0]
- 订阅与系统 [1]
- "全部已读" ghost button at bottom

Main list:
Each NotificationRow (72 tall):
- category icon + colored left 2px bar
- one-sentence subject (body-sm)
- meta row: actor + mono timestamp + target link
- right: "前往" ghost button → category-specific deep link

Read vs unread:
- unread = color/bg/subtle highlight + bold subject

Per-category empty state:
- explain what triggers this category

Mobile:
- category nav becomes horizontal scrollable chip row

Notifications should NEVER carry content payload themselves:
- they are pointers only
- do not render full intent paragraphs here
- link to /work/intents when relevant


FRAME D — Settings "/settings"
Design Settings with left nav + right form area, similar to Vercel/Supabase settings pages but darker and denser.

Left nav (240 wide):
- 个人资料        /settings/profile
- 账户安全        /settings/account
- 订阅与账单      /settings/subscription
- ──────────────
- Agent 接入      /settings/agents
- API Key         /settings/api-keys
- API / MCP       /settings/developers
- ──────────────
- 通知设置        /settings/notifications
- 隐私与权限      /settings/privacy
- 数据导出        /settings/data-export

Each page:
- SectionCard with clear h3 + body-sm + form fields
- form controls use primitives from the existing component library

Danger zone:
- separate danger card with error-subtle border
- ConfirmDialog gating for delete account / revoke all keys

订阅与账单 page:
- Current tier card (Free/Pro) + 升级 CTA
- Team Workspace 扩展包 add-ons table
- 账单历史 DataTable
- 支付方式 (Alipay / WeChat Pay / corporate invoice)

Do NOT put "我的 Agent" in the top-right avatar menu.
It lives here.

Responsive strategy (v10.0):
- ≥1280: full three-column ConsoleShell
- 1024–1279: RightRail collapses to 48px icon rail by default
- 768–1023: LeftRail becomes a drawer opened via a top-left hamburger
- <768: Workspace Console shows a banner
  "Workspace 协作建议在桌面端完成。你可以查看最近活动与通知。"

Touch targets ≥ 44px.
Avoid hover-only affordances below 1024.

Deliverables per frame:
- Desktop 1440, tablet 1024, mobile 375
- Dark mode only
- All layers use Auto Layout
- All colors/radii/spacing bound to Figma Variables
- Components consumed from "VibeHub/UI v10" library
- Copy uses zh-CN in the primary frame; provide an en-US variant frame
- Every interactive element has default / hover / active / focus / disabled
- Empty states, loading states, and error states included
- Never use placeholder lorem ipsum; use realistic Chinese developer copy

Absolutely forbid:
- Light-mode output
- Gradient backgrounds on hero or cards (except 1px accent border)
- Glassmorphism blur > 8px
- Emoji-as-icon except for user-generated content
- Social-style like/share reaction bars
- Chat bubbles with tails
- Repo / branch / commit / PR / CI visuals
- Calendar / Gantt / sprint burndown visuals
- KPI dashboard tiles
- Marketing bento grid layouts